---
name: generated-pictures-and-strip-margin
description: "locally generated pictures are mandatory without asking (animals faceless too); text in torn strips always has white margin, never below 26px; verse inside speech = card not full screen"
metadata:
  node_type: memory
  type: feedback
  originSessionId: aba39428-7633-4071-b2ff-2715a418d7ed
  modified: 2026-11-03T01:15:52.441Z
---

Generated pictures (`comfy_still`) for anything mentioned that can be drawn are made and placed without asking; the B-roll question is only about downloaded Pixabay video (yes/no). Animals get no eyes/nose/mouth either — draw from behind (the ram came out with eyes until regenerated as a rear view).

**Why:** user corrected twice on 2026-11-02/03 («هذه لا أحتاج أن أخبرك»، «حتى وجوه الحيوانات ما لها عيون»).

Text inside a torn strip/rectangle always keeps a white margin; `grid_plan` rejects fonts under 26px (shorten the phrase). A verse he recites inside his talk is a `VerseWords` card in the writing area (picture visible), `full:true` only for a lone recitation.

**How to apply:** check generated stills by eye before use; shorten torn phrases instead of shrinking; see [[feedback_user_pictures_not_cropped]].

**Superseded in part 2026-11-11 (newest wins):** never GENERATE a picture of anything with a real shape (person, god, place, book, animal, event) — the generated «Hanuman» looked like Rama. Real photos/paintings/statues only; local generation only for what he explicitly orders drawn («إلستريتور»، «رسم») or an abstract concept.
