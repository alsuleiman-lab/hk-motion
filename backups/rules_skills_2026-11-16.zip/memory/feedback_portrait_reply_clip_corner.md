---
name: portrait-reply-clip-corner
description: "Reels (portrait) — the replied-to clip is a tilted card at his right shoulder (frame-left), partly behind head and shoulder via a QUICK isolation of that window only (the one allowed isolation); landscape keeps side-by-side polaroids"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 7f584406-3221-4cc2-8971-86400a5f9aad
  modified: 2026-10-28T14:44:39.022Z
---

User 2026-10-27/28: side-by-side polaroids are landscape only. In portrait the replied-to clip is a tilted card in the corner at his right shoulder (frame-left), partly behind his head and partly behind his shoulder. «إلغاء العزل لم أقصد به الريلز»: the abolished isolation ([[no-background-isolation]]) does NOT cover this window. Isolate only the split window(s), QUICK: RVM `--ratio 0.5`, no matte_strong, no fixes — holes/halo are accepted, never spend time on them.

**How to apply:** `splits[].iso` = webm of him for 0..end of the last split window (crop 608 around cam cx → 1080×1920, matte_rvm 0.5, alphamerge, vp9 yuva420p); `PortraitClipCard` draws the card (left −20, top 300, rot −7, innerH 500) and his iso over it. Every other part of every video: no isolation. Cover still needs the replied-to person ([[cover-always-has-replied-to-person]]).
