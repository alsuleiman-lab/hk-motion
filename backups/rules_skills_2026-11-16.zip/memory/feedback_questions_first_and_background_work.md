---
name: questions-first-and-background-work
description: "Ask the AskUserQuestion questions as the very first action on a new request, and while waiting for an answer start other work in the background"
metadata:
  node_type: memory
  type: feedback
  originSessionId: f5560fed-77b9-4413-a58c-01a21768438a
  modified: 2026-11-03T08:06:51.345Z
---

الأسئلة بالنقر دائماً أول فعل عند وصول رسالة المستخدم (قبل القراءة الطويلة والتفريغ والبناء)، ومتى تأخّر الجواب أعمل شيئاً آخر في الخلفية (تفريغ، تجهيز، قراءة قواعد، فحص) ولا أنتظر خاملاً.

**Why:** أمر المستخدم 2026-11-03 في جلسة كرتون «التيكتوكر»: سألتُ عن العنوان متأخراً بعد ساعة عمل فتعطّل الجواب.
**How to apply:** أول رسالة لي في أي طلب = `AskUserQuestion` (عنوان، صيغ…) في نفس الرسالة مع أمر خلفي (`run_in_background`) مثل `stage.mjs prep`؛ ثم أتابع المراحل التي لا تحتاج الجواب. يكمّل [[feedback_ask_with_clickable_options]] و«السرعة» في MONTAGE_BRIEF.md.
