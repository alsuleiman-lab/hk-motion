---
name: feedback-render-progress-visible-in-claude
description: during every render the user must SEE progress inside Claude (preview pane on http://localhost:3105 with the Arabic title); verify it each time (2026-11-08)
metadata:
  node_type: memory
  type: feedback
  originSessionId: 19435a74-d517-459c-9572-b7693d09ee81
  modified: 2026-11-08T18:49:18.012Z
---

Before/while any render runs, open the progress page in the Claude preview pane (`mcp__Claude_Browser__navigate` to http://localhost:3105 then `mcp__ccd_view__show_pane` pane "preview") and confirm the running render appears with its Arabic title; also give the LAN link.

**Why:** the user works remotely and could not tell whether I was rendering (2026-11-08). render_final used to log to .tmp/render_final.log which the page never read; now it logs to render_work/progress_chunked_<id>.log with a `TITLE <arabic>` first line, and monitor.mjs auto-starts the page server.

**How to apply:** start of each render batch: open the pane, check `/api` shows the running item with Arabic title and rising %. Related: [[reference_render_progress_page]].
