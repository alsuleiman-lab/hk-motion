---
name: hadith-card-stays-after-typing
description: Hadith note card must stay >=1 s after its last typed char; typing ends with his last word (2026-11-13)
metadata:
  type: feedback
---
Hadith `note` card must never vanish while its last word is still typing; it stays at least 1 s after typing ends.

**Why:** user saw the card disappear during the last word (dafe_hasad). Typing starts at `at+0.25`, every char incl. «» counts.
**How to apply:** cps = chars/(speech end − at − 0.25); until ≥ typeEnd+1; delay the next writing item (slot margin 0.15). `writing_sync` now checks it. See [[reference-preferences-file]].
