---
name: feedback-two-countries-map-nasrallah-x-missing-pictures
description: "Permanent rules the user repeated 2026-11-10: two countries → atlas map behind him; حزابلة/حسن نصر الله → his photo with a red X every time; hunt missing pictures (events + press news)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: b5ff9b15-7354-4b98-ac3c-e2b1c730e1f0
  modified: 2026-11-10T15:15:45.837Z
---

User corrections during the FadlShaker video (all «في كل الفيديوهات»):
1. **Two countries in one context (Syria + Lebanon…) → full-frame map behind him**, isolated mini sheikh, **with borders and an excellent look** (PaperMap `atlas: true`: sea, borders, country names). The old paper map was judged bad.
2. **«حزابلة» / «حسن نصر الله» (ASR «نصليرة/صليرة») / «حزب اللات» → Nasrallah's photo with a red BrushX on it, every mention** (search all spellings in cut_words, not the lexicon).
3. **Missing pictures:** go through the whole transcript (people, places, events, bodies); an event like Ahmad al-Assir's sit-in needs real photos and newspaper clippings (`news` item), found by Google Images (SerpAPI via a small script) — «هذا أمر مهم جداً».
4. **Never put cards in front of his face** (`arc` needs `landA/landB`), and baked-split clips must be measured: `source_crop --write` made the Al-Jadeed clip a 99×48 strip → «الفيديو غير واضح».

**Why:** he had told me before and I had not recorded it; now in `video-montage/critical-rules.md` 71–74 and MONTAGE_BRIEF §8.

**How to apply:** after the spec build, run a mention pass for these three, view frames of every map/arc/split in Studio before reporting. See [[project_fadlshaker_video]] [[feedback_hadith_notecard_gallery_only]].
