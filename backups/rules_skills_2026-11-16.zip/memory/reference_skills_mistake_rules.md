---
name: skills-hold-the-mistake-rules
description: preventive rules from the Yahudiya video are written into the skills (video-montage, video-cutting, hook, *-source-display, thumbnail-design)
metadata:
  type: reference
---

On 2026-10-20 the user asked to record in the skills what prevents repeating my mistakes: plan order, scenes system, topic background, source recomposition, word-by-word reveal, beard heights, names from transcript, echo, restart cues/asides, disk cleanup. Read the "أخطاء سابقة" sections at the end of those skills before any montage. See [[montage-full-plan-order]].
