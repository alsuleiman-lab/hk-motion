---
name: feedback-baked-split-in-source
description: "Source recordings may have a clip|him split baked in; never show it raw — landscape = two polaroid cards on decorated base, portrait = tilted clip card"
metadata:
  node_type: memory
  type: feedback
  originSessionId: db596978-7c36-4ab0-ae67-f4cb5cc8a22f
  modified: 2026-10-28T09:44:43.392Z
---

When the user's source video has a baked-in split (clip on the left, him on the right, black bar at far left), detect the window (black-bar scan of the first 100 px column) in the first look at the frames and handle it before showing any preview. Landscape: two polaroid cards (clip + him) on the decorated base with a curtain at the exit; portrait: his slice via `cams` plus the clip as a tilted card at his right shoulder. Spec field `splits` in `MontageSpec.tsx` does both.

**Why:** the user reacted angrily (2026-10-27, daraa project) when the raw split with black bar showed in the landscape preview; it is a known rule (PREFERENCES §7, video-source-display).
**Portrait placement (user 2026-10-28, after approving daraa):** the clip/footage shown in portrait goes in the writing area (lower part, where texts live) even if it covers part of the beard; the tilted card at his shoulder was not liked. Next time place it there and propose the change as a rule update.
**How to apply:** open frames across the first 2 minutes before building the spec and before sending any preview link; check landscape AND portrait on a split frame. Related: [[feedback-judder-probe-before-full-render]].
