---
name: judder-root-cause
description: render judder on Siraj came from EuKit Pic's one-shot delayRender (stale frames), not from the source; judder_check gate now guards it
metadata:
  type: feedback
---

When the user says "الفيديو يرتجف" after a fast render with extracted JPEG frames, the cause was `EuKit.Pic`: it called `delayRender` once at mount, so changing `src` every frame was not awaited and the render captured stale/skipped frames (output matched the source only ~90%). Fixed: `Pic` now waits per `src`; frame loaders use remotion `<Img>`.

**Why:** the user saw the original as smooth and my render as very jittery; I first blamed duplicate frames in the source (true but invisible to him) and wasted time. He asked for the root cause and a permanent prevention.

**How to apply:** after every render run `node tools/judder_check.mjs <out> --src <smoothed cut> --offset <frame> --name <p> --avoid <curtains/zooms/shakes>` (>=96% agreement); `final_review.mjs` refuses without `.tmp/gates/<p>.judder.ok`. `stage.mjs cut` now also runs `smooth_dups.py` automatically (`<p>_cut_s.mp4`). Related: [[feedback_always_fast_render]], [[feedback_edit_is_one_block]].
