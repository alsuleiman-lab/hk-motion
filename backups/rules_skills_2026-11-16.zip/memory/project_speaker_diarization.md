---
name: project-speaker-diarization
description: I use speaker diarization myself on every montage (stage.mjs prep → speakers.txt); the user never runs it
metadata:
  node_type: memory
  type: project
  originSessionId: 1762cead-42e1-4053-88d4-0c910a4e6bc4
  modified: 2026-10-28T09:58:42.829Z
---

Since 2026-10-28 `stage.mjs prep` runs `tools/diarize.py` (WhisperX + pyannote) and writes `.tmp/<p>/speakers.txt` (+ speakers.json). Turns not named `sheikh` = the clip he replies to (show it on screen at that time; never cut it as his speech) or the other side in a debate (fixed name/colour per speaker; `--ref NAME=voice.wav`). Sheikh voice ref: `data/voices/sheikh.wav`. Manual: `node tools/diarize.mjs <p>`.

**Why:** user (2026-10-28): «أنا لا أستعمل شيء، أنت الذي ستستعمل» — the tool is for me; to know when to show the speech he replies to and to edit debates.
**How to apply:** read speakers.txt in the context stage of every montage, unprompted; never tell the user to run it. Install quirks in rules_registry/proposals/speaker_diarization_2026-10-28.md. Related: [[project-montage-skill]], [[feedback-baked-split-in-source]].
