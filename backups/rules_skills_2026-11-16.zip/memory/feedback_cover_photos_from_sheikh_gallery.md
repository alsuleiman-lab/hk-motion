---
name: cover-photos-from-sheikh-gallery
description: "Sheikh's photo for every cover always comes from public/sheikh_gallery/<robe colour>/, never cropped from the video unless the colour is missing"
metadata:
  node_type: memory
  type: feedback
  originSessionId: f3346621-4118-4993-a9ba-566a55dce1a5
  modified: 2026-11-06T00:22:37.752Z
---

His photo for covers is always taken from `public/sheikh_gallery/<robe colour>/` (user 2026-11-06: «دائماً»).

**Why:** he shoots dedicated cover photos himself; random video crops are weaker.
**How to apply:** pick the robe colour of the current video via `tools/sheikh_gallery.mjs list|sheet`; crop from the video only if that colour folder is empty. Already in PREFERENCES.md line 91, MONTAGE_BRIEF.md and thumbnail-design/SKILL.md. See [[reference_channel_thumbnail_style]].
