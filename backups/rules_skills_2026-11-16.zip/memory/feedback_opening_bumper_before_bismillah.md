---
name: feedback-opening-bumper-before-bismillah
description: "Bumper position — landscape AND full-length portrait get the 5-s paper bumper at the START before bismillah; reels, silent-reaction clips, streams and lessons get it at the END (user 2026-11-15)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 78156cad-cde7-4e13-990e-3c3ba8d49c52
  modified: 2026-11-15T16:45:55.605Z
---

**الحالي (أمر المستخدم 2026-11-15 وتصحيحه):** الفاصل الورقي 5ث العشوائي من `public/fawasel/` يوضع **في أول العرضي والطولي الكامل** (نسخة الحلقة كاملة بالاتجاه الطولي) قبل «بسم الله»، و**في آخر الريلز والتعليق الصامت والبثوث والدروس** — وضعه في أول الريل أو التعليق الصامت «مصيبة، يخرب الهوك». المقصود بكلامه «الطولية» = الريل والتعليق الصامت، **لا** الطولي الكامل (أخطأتُ أولاً فعممتُ على كل ملف طولي).

**التنفيذ:** `tools/prepend_bumper.mjs` يضع الفاصل في الآخر إذا (`--end` أو `BUMPER_POSITION=end`) أو (ملف طولي و`data/specs/<name>.json` فيه `kind: reel` أو `public/silent/<name>/config.json` موجود)؛ `--start` للاستثناء. `render_job.sh` يمرّر end للريل فقط (R وkind reel). `render_silent.mjs` يمرّر `BUMPER_POSITION=end` ولم يعد `--no-bumper`. القواعد في CLAUDE/AGENTS/PREFERENCES/MONTAGE_BRIEF/critical-rules/video-montage SKILL.

**Why:** the bumper at the start of a silent-reaction clip ruins its hook; I put it there on «تكفير الأشعرية للمسلمين 25» and re-rendered; then I over-generalised to all portrait files and the user corrected me.
**How to apply:** silent reaction / reel → bumper LAST 5 s (final_review gate `position: end`); landscape and full portrait → start. Never decide by orientation alone.

سجل قديم: 11-11 الفاصل في أول كل فيديو والاستثناء للبثوث والدروس فقط. See [[project_fasel_bumper_five_models]].
