---
name: reference-mg-catalog-quickref
description: "Quick reference for montage: .claude/skills/video-montage/MG_CATALOG.md (auto-generated list of all 57 MG.tsx components with exact props) — read it INSTEAD of the long motion-graphics skills; regenerate with node tools/gen_quickref.mjs"
metadata:
  type: reference
---

بطلب المستخدم (2026-10-22): نسخة مرجعية سهلة القراءة توفّر وقت القراءة والتعلم في كل مونتاج. `MG_CATALOG.md` يُولَّد آلياً من `src/MG.tsx` (الاسم، الوصف، الخصائص الدقيقة) فلا يتقادم؛ **أعد توليده بعد إضافة أو تعديل أي قطعة**. نقطة البدء: `critical-rules.md` + `MG_CATALOG.md`، ولا أقرأ مهارة الموشن المفصلة إلا لضوابط قطعة بعينها.
