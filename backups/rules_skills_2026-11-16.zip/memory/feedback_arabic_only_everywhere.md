---
name: feedback-arabic-only-everywhere
description: STRICT — every word the user sees is Arabic, not one Latin letter (2026-11-13): replies, mid-work status lines, wrap_up recap, questions and options (2026-11-11)
metadata:
  type: feedback
---
The user: «ممنوع تكلمني بالانجليزي، كلمني عربي حصرا، سجل ذلك في تعليماتك» — after my mid-work status lines and the wrap_up recap came out in English.

**Why:** he reads everything; English text anywhere breaks the standing order (2026-10-25) to speak Arabic only.

**How to apply:** write every user-visible string in Arabic — replies, the short "what I'm doing" lines between tool calls, the wrap_up recap/ask/labels, AskUserQuestion headers/options, update_plan step names too. No tool or command names. Recorded in PREFERENCES.md §0 التخاطب, MONTAGE_BRIEF §0, CLAUDE.md. Related: [[feedback_plain_arabic_no_tool_names]], [[feedback_arabic_short_and_fix_into_skill]].

**2026-11-13 (repeated, stricter):** «لا تكتب لي أي حرف غير عربي، سجلها في تعليماتك، لا أقرأ غير العربية» — after a whole turn of my status lines and the final report came out in English. Not one Latin letter: no English word, no file/tool/path names (name things in Arabic: «مجلد جاهز ← بثوث ← طولي»); only the clickable preview link may stay, alone on its line. Re-read every reply for Latin letters before sending. Recorded in CLAUDE.md line 3, PREFERENCES.md §0, MONTAGE_BRIEF §00-9.

2026-11-13: an English reply slipped out right after a context summary (the summary is English). Now enforced: the Stop hook in tools/hooks/guard.mjs sends back any reply whose prose is mostly Latin letters.
