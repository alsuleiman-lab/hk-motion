---
name: feedback-streams-lessons-upload-drive-and-okru
description: after approval, streams and lessons are uploaded to Drive AND ok.ru/video/manager, then local files go to Recycle Bin (2026-11-09)
metadata:
  type: feedback
---

After the user approves, every stream/lesson video is uploaded to Google Drive and to https://ok.ru/video/manager, then deleted locally to the Recycle Bin.

**Why:** user order 2026-11-09.

**How to apply:** upload via Chrome (see [[reference_drive_upload_via_chrome]]); ok.ru needs the user's signed-in Chrome; only trash after both uploads verified. Part of [[feedback_streams_never_stop_queue_workflow]].

**Update 2026-11-12:** ok.ru items must be PUBLISHED by me automatically after upload (user published the drafts himself once and ordered: "في المستقبل انت انشر تلقائيا"). Overrides the earlier "leave as drafts" habit.
