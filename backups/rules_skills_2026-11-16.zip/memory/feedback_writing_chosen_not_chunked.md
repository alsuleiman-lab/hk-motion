---
name: feedback-writing-chosen-not-chunked
description: STRICT — torn notes/scraps are chosen by reading the accurate transcript (summaries / his important words verbatim, complete), never mechanical chunks (2026-11-11)
metadata:
  type: feedback
---
User: «تكتب عبارات غير مفهومة وغير مكتملة… تنقص كلمات، تأتي بكلمات من السياق لا تكتبها… هذا الخطأ الشنيع… دمرت قواعد المونتاج الجيدة». My build chunked his speech every ~4 s into 6-word pieces (every 3rd a torn note) from the weaker transcript.

**Why:** the torn note is for important statements/conclusions and the scraps are a caption of his important speech — fragments mean nothing and misquote him.

**How to apply:** read the full large-model transcript of the final cut audio (drift_fresh.json), write .tmp/<p>/writing.json (torn = a complete summarizing sentence; scraps = his important words verbatim, complete meaning, ≤ 7; fix map for mishearings), then writing_place.mjs --write → scraps_times → writing_sync --fix → writing_place --hold. Gaps are filled with another phrase from that moment or a push-in, never filler. Related: [[feedback_reel_text_pictures_sources]], [[feedback_times_mmss_and_torn_overuse]].
