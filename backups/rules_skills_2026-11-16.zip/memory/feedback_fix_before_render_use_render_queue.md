---
name: fix-before-render-use-render-queue
description: "all gates must pass before the render; renders go through tools/render_queue.mjs; spec failures are my build mistakes, never blame the queue (2026-11-11)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 19435a74-d517-459c-9572-b7693d09ee81
  modified: 2026-11-11T17:18:12.112Z
---

After the 7-hour qa2 stream the user corrected my diagnosis: «السبب الأول غلط منك» (I blamed three concurrent queues), and the repeated check failures (scraps text not in the speech, first-minute gaps, nameTag with other items, missing element kinds) are «أخطاء ضبط عندك، لازم تحسبها».

**Why:** I built specs from templates and let the check-and-retry loop find the defects, which wasted hours. The user wants everything checked BEFORE the render, and the render handled by a queue program that I just feed.

**How to apply:** build the spec → `node tools/spec_normalize.mjs data/specs/<id>.json --o port|land` until clean (it fixes what I fixed by hand that day) → `node tools/render_queue.mjs add …` per clip → one `render_queue.mjs run` worker in the background while I keep preparing. Never loop a failing check without changing the spec; never run more than one queue/worker. Skips (mention without picture, missing required element) are listed and only written with `--allow-skips`, then disclosed. Related: [[stream-queue-pitfalls-qa2]], [[streams-never-stop-queue-workflow]].
