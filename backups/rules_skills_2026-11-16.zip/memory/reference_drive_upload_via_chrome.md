---
name: reference-drive-upload-via-chrome
description: "how to put a rendered video into Google Drive (connector cannot: inline base64 only) — local CORS server + Claude in Chrome input interception; folder ids جاهز/طولي/الكل"
metadata:
  node_type: memory
  type: reference
  originSessionId: 7f584406-3221-4cc2-8971-86400a5f9aad
  modified: 2026-11-06T10:32:46.386Z
---

Drive connector (`mcp__fee43ca5…`): `create_file` takes only inline `base64Content`/`textContent` → useless for 60–130 MB reels; use it only to **search folders and verify** (`search_files parentId=…`). Claude in Chrome `file_upload` is limited to 10 MB. The way that worked (2026-11-06, ≈4 min for two reels):

1. Serve the files on localhost with CORS + `Access-Control-Allow-Private-Network: true` (tiny python `ThreadingTCPServer` reading `C:\Users\mshms\Videos\جاهز\<name>`; `/a.mp4`, `/b.mp4`), run in background.
2. Chrome (the user's signed-in profile, account `u/2` = the connector's account): navigate to the folder URL. In the page run `fetch('http://127.0.0.1:8765/a.mp4')` WITHOUT awaiting (store `new File([blob], name, {type:'video/mp4'})` on `window`); Chrome shows a «local network access» permission bubble the user must click «سماح» once (ask with AskUserQuestion; I cannot see it).
3. Patch `HTMLInputElement.prototype.click` so a file input's `.click()` sets `this.files` to the queued File and fires `input`+`change`; then click «جديد» (≈1500,88) and «تحميل الملف» (≈1485,127). Synthetic drag-drop events are ignored by Drive. One file per round; wait for «اكتملت عملية تحميل».
4. Verify with the connector (`fileSize` equal to the local size), close the tab, kill the server.

Folder ids (owner internetarchiveservice@gmail.com): جاهز `1gsxxE1iAQ0lQQ-9YRhuKZJrZOXoEPp9u` → طولي `1vFQ9GGFlAuLslOxnAAJWMNH9nNZHLIgr` → الكل `1AA8EuSK9GyR8bc9kkdRBtznx-R_8-tMm` (also عرضي `1jKMaA1bt4qRwLCzrsCiBFankl1h37Rk0`, دروس `1-Uym_4A6rFN0BKJTxqr_Jo8LpgH_4UsV`). Earlier approved videos live in طولي/الكل — that is why they are no longer in the local جاهز folder.

**Update 2026-11-12 (upload_server):** full GET of a clip from Chrome failed (Failed to fetch) while explicit `Range: bytes=a-b` chunks (8 MB, retried) worked, so read files in ranged chunks and rebuild a File; ok.ru: the helper popup stays open, re-post `{cmd:'send',have:[…]}` to resume after a failed chunk; set `input[type=file].files` per batch. Drive folders: طولي/بثوث = 1s7lvur8ZY-Z4rNkAwoFmaGCXEuu6AXlr, عرضي/بثوث = 17zZ4ESICHP0_n_yvoMbwhj7BCoBQaFbM. Navigate to the folder URL and confirm the tab title/URL before uploading (once Drive redirected to home). ok.ru items stay unpublished drafts.
