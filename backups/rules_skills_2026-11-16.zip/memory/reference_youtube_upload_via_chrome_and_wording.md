---
name: reference-youtube-upload-via-chrome-and-wording
description: "YouTube Studio upload of a big local file via Chrome (chunked file_upload + File assembly), switch channel first, upload only/private; never say «جهازي» — say «كمبيوترك» (2026-11-08)"
metadata:
  node_type: memory
  type: reference
  originSessionId: c55085ef-1d7c-433b-9e41-f4d4c4bacfd1
  modified: 2026-11-08T18:52:03.647Z
---

Uploading a ~1 GB render to YouTube Studio from Chrome while the user is away: `fetch('http://127.0.0.1…')` from the https page hangs on Chrome's local-network permission prompt (needs a click at the PC). Workaround: split the file into ~8 MB chunks, send each with parallel single `file_upload` calls (max 10 MB per bridge message, batches count cumulatively), assemble a `File` in the page, inject a hidden file input and patch `HTMLInputElement.prototype.click` so Studio's «اختيار الملفات» uses it. Check/switch the channel first (Account → تبديل الحساب); the upload dialog auto-saves a private draft, so "upload only, don't publish" = close the dialog without publishing. Delete the chunks and close the tab afterwards.

**Why:** user said «ارفع… ولا تعمل في وضع النشر» and the channel was the wrong one («الردود العلمية») at first.
**How to apply:** any YouTube upload request. Wording: the user got confused by «جهازي»; always say «كمبيوترك» / «جهازك» for the local PC and state that everything runs on it. See [[reference_drive_upload_via_chrome]].
