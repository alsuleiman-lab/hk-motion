---
name: feedback-studio-deep-links
description: "When pointing at a moment in a video, give a Studio link that jumps there: /<CompId>?m.ss for minute:second, /<CompId>?<frame> for a frame (user order 2026-11-09)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: be6dff2a-c908-46d6-bb2f-477031ad8aae
  modified: 2026-11-09T17:24:35.920Z
---

The user wants a clickable Studio link whenever I point at a place in a video (a verse, an element, a defect), instead of just a time in words.

Formats (user's examples): `http://localhost:3100/KashfHadith?1.10` = minute 1:10 (min.sec); `http://localhost:3100/KashfHadith?123` = frame 123.

**Why:** saves the user from scrubbing the timeline to find what I mention.

**How to apply:** in any reply that names a time or frame, add the link with the composition id (e.g. `Mufti-Iraq-L`); use the LAN IP instead of localhost when the preview link is sent for the phone/other device (see [[feedback_preview_link_current_ip]]). Convert seconds to m.ss (e.g. 312 s → `?5.12`).

**Repeated 2026-11-12 (I wrote «عند 11:26» as plain text):** EVERY time or frame I mention gets a clickable Studio link http://<LAN IP>:3100/<Comp>?<frame> — never a bare number. Now item 9 of the constitution (MONTAGE_BRIEF §00).
