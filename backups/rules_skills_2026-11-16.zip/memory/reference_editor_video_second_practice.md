---
name: reference-editor-video-second-practice
description: "2026-10-22: the user re-sent the already-studied «مونتاج الدحيح في كلود» video (720x1280, 35.8 s) to practice; gap analysis vs MotionLab found missing tail pieces → RewriteWindow/TiltNote/ColorWash; original deleted afterwards on his order"
metadata:
  type: project
---

الفيديو المرسَل (`772ببب465384_fb.mp4`) هو نفسه مرجع الدحيح المدروس سابقاً. المقارنة مع `MotionLab` (12ث فقط) كشفت الناقص: ثلث المرجع الأخير (نافذة تحسين شطب+سهم+تظليل، ملاحظة برتقالية، غسل أخضر). بُنيت `RewriteWindow`/`TiltNote`/`ColorWash` وتجربتها `Lamp-Demo`. حُذف الأصل بأمره. **خطأ وقعتُ فيه:** اخترتُ الملف بـ`ls | head -1` فأخذتُ ملفاً آخر من المجلد قبل أن ألاحظ؛ **الصحيح: طابق الاسم/الحجم بالضبط (الاسم عربي) ولا تعتمد ترتيب القائمة**. وملحوظة: `yh_cut.mp4` حُذف من جهة أخرى، فالاختبارات الآن على `public/kit_sample_sheikh.mp4` (20ث). انظر [[project-kit-real-footage-test]].
