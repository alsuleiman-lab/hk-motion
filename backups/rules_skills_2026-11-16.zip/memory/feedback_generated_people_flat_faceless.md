---
name: feedback-generated-people-flat-faceless
description: "comfy_still ignores \"no face\" in realistic style; use flat vector/paper-cut prompt and state roles exactly (who lies, who massages) (2026-11-06)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: c55085ef-1d7c-433b-9e41-f4d4c4bacfd1
  modified: 2026-11-06T12:33:14.151Z
---

Realistic prompts to `comfy_still.mjs` ignore «no eyes/nose/mouth» (faces came out detailed). A **flat vector illustration with faceless paper-cut figures** gave blank faces; even then a small eye mark on a lying figure needed a PIL blur patch.

**Why:** for «مساج رباعي» the user wanted a picture of the man lying on the bed with 4 hijabi women massaging him; my first versions had a standing man / the man as the masseur and he corrected me («غلط ادخلت رجلا واقفا… هناك مستلقي و4 نساء محجبات يعملن المساج»).

**How to apply:** write the roles literally in the prompt («exactly ONE man lies on his back on the bed… FOUR women stand around and massage him… no other man, nobody else standing»), check the still by eye, soften any leftover face detail with PIL, save as public/<p>/gen_*.png. See [[feedback_generated_pictures_and_strip_margin]].
