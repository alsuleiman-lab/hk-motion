---
name: feedback-hybrid-no-chrome-video-decode
description: "Hybrid render speed — no video decoded in Chrome; isolation cut on the GPU (masked VSlot + veil fx), every window incl. maps (under layer, --under); seek passthrough fix; 3 browsers max (2026-11-12)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 8aad214f-24e6-49f3-8c41-890ac93a0ba4
  modified: 2026-11-12T11:06:20.299Z
---

The user stopped a 14-min render at 5 fps («غير مقبول… وعدك لي أن الرندر أسرع بكثير»). Cause: in isolation windows Chrome seeked three videos per frame (bg clip, cut, matte) → 2.6 fps while plain spans ran 15.4 fps and the CPU sat half idle. Fix (user: «نقل العزل كله إلى كرت الشاشة»): `BgClip` = VSlot with `fx.veil`; `MaskedVideo gpu` = masked VSlot, the compositor decodes the matte and applies alpha + floor → 12 fps in isolation spans. Every window is on the GPU (user: «لا اريد التفادي»): graphics under him go in a second "under" layer for their frames only (UnderHim, window_frames.mjs under L|R → hybrid_any --under). Also fixed: ffmpeg readers need `-fps_mode passthrough` or every mid-file stream start is one frame early (partial/patch renders, clip cards). Graphics layer is CPU-bound at ~17–20 fps; 92–97 % of calm-span frames repeat (frame-reuse is the next lever, not built). 5 or 7 browsers measured slower than 3.

**Why:** the user expects render time well under the video length; a slow render is my build mistake.
**How to apply:** any new video component in a hybrid composition must be a VSlot; on slowness, benchmark a plain span and an isolated span with `hybrid_any --start/--end` first. Rules in remotion-render SKILL.md + PREFERENCES render section. Related: [[feedback-hybrid-slow-with-many-layers-and-patch-rerender]], [[project-hybrid-render-adopted]].
