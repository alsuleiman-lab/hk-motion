---
name: feedback-cover-photos-poses-folder-and-title-only
description: Cover photo only from public/cov/sheikh_poses (his own folder), never change face/body pose, title only on the cover (2026-11-09)
metadata:
  type: feedback
---

For ChatGPT covers the sheikh photo comes **only** from `public/cov/sheikh_poses/` (= `S:\AI_Tools\covers\sheikh_poses`, 10 poses; I used `07_sheikh_brown_hands_clasped.png` for a serious topic). The user was furious («الصور يا غبي حصراً من مجلد الصور») after I pulled `sheikh_gallery/black_white/cover_sheikh.png` and then `sheikh_cov.png`.

**Why:** the prompt template asked for «hand on chin, thinking pose» so ChatGPT redrew his face (frown, looking down) and the user said changing his features/body pose is forbidden; he also said «العنوان لا تزد عليه» = only the title on the cover, no red hook strip/signature; and the guillemets «» around the title were rendered as a stray » (write the title without quotes).

**How to apply:** strict prompt: photo pasted as-is, same expression/gaze/pose/hands, no new pose; ONLY one banner with the title. Template fixed in `.claude/skills/thumbnail-design/refs/chatgpt_cover_prompt.md`. Supersedes the gallery rule in [[feedback_cover_photos_from_sheikh_gallery]] for ChatGPT covers; see [[feedback_cover_via_chatgpt]]. Also: Chrome blocks local-network fetch to 127.0.0.1 from studio.youtube.com after a dismissed prompt and the user does NOT want to be asked to press «سماح» — give him the file picker himself instead (see [[reference_youtube_upload_via_chrome_and_wording]]).
