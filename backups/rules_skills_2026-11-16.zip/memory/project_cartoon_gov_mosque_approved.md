---
name: project-cartoon-gov-mosque-approved
description: "Dodo «ما دور الحكومة؟» and Abu Khatt «آداب المسجد» cartoons approved 2026-11-15 and delivered to جاهز\كرتون; what stayed in the kit"
metadata:
  type: project
---

Two cartoons rebuilt from source clips (original voice), approved and copied to `C:\Users\mshms\Videos\جاهز\كرتون` (files «ما دور الحكومة.mp4» 34 s with bumper, «آداب المسجد.mp4» 96 s). Source clips went to the Recycle Bin; composition code, spec data, titles purged by `montage_guard end`.

**Why it matters:** the user rejected the first Abu Khatt mosque versions repeatedly (unnatural, glasses, mixed generated pictures, wrong left/right, onion drawn as a purple circle, yellow collar on the mouth, ankle blocks) before accepting; the lessons are in the cartoon-animation skill section dated 2026-11-15.

**How to apply:** kept in the kit — `src/cartoon/StickPray.tsx` (prayer poses with the rig option `part`), `FilmKit` `path`/`timeMap`, `MosqueKit` (hall, onion, puffs, scroll), `EnvsOffice`. See [[project-film-engine-six-films]] and [[feedback-study-source-video-before-cartoon]].
