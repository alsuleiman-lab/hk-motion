---
name: project-verse-hadith-ways-random
description: "Landscape verse/hadith = approved gallery ways picked at random per item (VerseNoor/VerseBigWord, HadithQuote/HadithBooks, HadithIsnad for recited isnad) — 2026-11-12"
metadata:
  node_type: memory
  type: project
  originSessionId: f3346621-4118-4993-a9ba-566a55dce1a5
  modified: 2026-11-12T19:19:13.843Z
---

User 2026-11-12 picked from two choice pages (scratch/choose_page, served at /choose/ by gallery_serve; picks → data/choice_pick.json): verse ways VerseNoor + VerseBigWord, hadith ways HadithQuote + HadithBooks + HadithIsnad. Order: «اجعله هو الأصلي والأساسي… كل ما تمر آية أو حديث يختار واحد عشوائي… دائماً عشوائي».

Engine (src/MontageSpec.tsx `withHalfWays`): landscape `verse` without `way` → random noor|bigword; `note` with `phrases` → random quote|books, `chain` → isnad always. Draw = hash of spec.cut + item second (differs per item and episode, stable Studio↔render). Half-screen ways add a `shifts` window (HALF_DX 470) so he slides right; panels melt into his video by mask (no seam), palette colours only. Portrait unchanged (VerseWords / NoteCard). Rules text is a proposal: rules_registry/proposals/verse_hadith_ways_random_2026-11-12.md (direct rule-file edit was denied in this session).

**Why:** he wants variety across every verse/hadith, never the same fixed choice. **How to apply:** when building a landscape montage, every landscape hadith `note` takes the new ways ALWAYS (user: «اعتمدنا طريقة جديدة وخلاص»); without `phrases` the engine splits the title itself (autoPhrases); give phrases/narrator/books/chain when available for better timing. Old card only with way "card" by his order. Never set `way` unless he orders it. Supersedes the landscape part of [[feedback-hadith-notecard-gallery-only]].
