---
name: rule-files-via-proposal
description: Never edit PREFERENCES.md / WORKFLOW_CHECKLIST.md directly; write a proposal file, compare with existing rules, wait for approval (user 2026-10-23)
metadata:
  type: feedback
---

**SUPERSEDED 2026-11-12 (user: «وين عم تروح تعليماتي؟»):** proposals that wait were never merged — 20 of 24 sat unread, and the user's 2026-10-23 decisions (Companions = calligraphy of the name from the internet; imams = public/scholar_images) were lost and asked again. Now: an ORDER of the user is merged into PREFERENCES.md + MONTAGE_BRIEF.md + the skill in the same turn, its proposal file gets «الحالة: مدمج <date> في …», and `tools/rules_pending.mjs` (run by stage.mjs prep|cut|check) blocks any montage while one is pending. Only a CONFLICT with another rule is asked by click. See [[feedback-orders-merged-same-turn]].

On 2026-10-23 the user said that editing `PREFERENCES.md` directly (I had added stills, typecheck and matte lines) violates their agreement: changes to rule files must first be compared with the existing text and saved as a proposal; no instruction may be deleted before its conditions and exceptions are checked.

**Why:** rule files are shared by several sessions and encode the user's decisions; silent edits can overwrite or contradict newer ones.

**How to apply:** put new/changed rules in `.tmp/PREFERENCES_proposal_<date>.md` (location of the addition + reason), tell the user, and merge only after approval. This overrides the older line in CLAUDE.md that says to update PREFERENCES.md immediately; ask if unsure. My 5 lines were moved to `.tmp/PREFERENCES_proposal_2026-10-23.md` (backups of the rule files before the move are in backups/). Related: [[feedback-rules-consolidated]].
