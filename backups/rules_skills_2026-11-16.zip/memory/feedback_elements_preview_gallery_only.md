---
name: feedback-elements-preview-gallery-only
description: Elements are shown to the user ONLY on the local gallery http://localhost:5601 (real videos); never open ElementsLab/Studio 3100 for that (2026-11-09)
metadata:
  type: feedback
---

The user approved gallery = local page http://localhost:5601 (tools/gallery_serve.mjs, built by tools/gallery_build.mjs) where elements run over real recordings. The Remotion Studio :3100 view / ElementsLab composition is the OLD one for showing elements and must not be opened for him.

**Why:** 2026-11-09 the user noticed I opened the old Studio and said he wants only the gallery with applications on real video.

**How to apply:** after any element change run node tools/gallery_build.mjs and send/open :5601; keep Studio :3100 for montage compositions only. See [[elements-gallery-page]].
