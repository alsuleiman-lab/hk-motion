---
name: pose-capture-rtmlib
description: Pose capture (rtmlib) was tried, measured and then deleted at the user's order; how to reinstall and the standing rule for «make it exactly like this video»
metadata:
  type: reference
---

Tried 2026-11-11 and DELETED the same day with the rest of the project («احذف الكل»): venv `S:\AI_Tools\pose_venv`, `tools/pose_extract.py`, retarget script and the model cache. Findings are in `.claude/skills/cartoon-animation/references/action-contracts.md` (19 fps on RTX 3090 = 100 s per 64 s video; tracks both people but coverage ~50%/30% and identity swaps at contact; image-plane transfer fails for rear views → useful as timing/angle reference, not as an automatic driver; 3D lifting would be needed).

**Reinstall if asked:** Python 3.10 venv on S: (not C:), `pip install rtmlib onnxruntime-gpu opencv-python numpy` (never plain `onnxruntime`: it hides CUDA), set HOME/USERPROFILE to an S: cache folder so models do not land on C:, and add the ComfyUI `torch/lib` folder to PATH/DLL dirs for cuDNN.

**Standing rule (user 2026-11-11):** when he gives a video and says «make it exactly like this / watch it», use the imitation route even if he does not name it: pose capture for motion; Wan2.2-Animate is the optional heavier tool — NOT downloaded (~20 GB GGUF); AniSora (Bilibili) rejected; slow production is rejected. Wan2.2 TI2V-5B is already in `ComfyUI_extra_models`. See [[feedback_study_source_video_before_cartoon]].
