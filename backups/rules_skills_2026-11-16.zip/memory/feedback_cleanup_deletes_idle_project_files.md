---
name: feedback-cleanup-deletes-idle-project-files
description: during a long render the auto clean_temp / another session deleted my project's temp + public files and Root.tsx lines; keep-alive touches and registration outside Root
metadata:
  type: feedback
---

2026-11-05/06 (DatePoison): while a ~2 h render ran, `.tmp/<p>/`, `public/<p>_*.mp4`, the cached bundle `.tmp/stills_bundle/<id>` and my `DatePoison-L` lines in `src/Root.tsx` disappeared (clean_temp skips only items touched in the last 30 min; another session also rewrites Root.tsx and deletes specs). Each loss cost 20–40 min of rebuild (prep + cut + smoothing + frames).

**Why:** the cleaner judges activity by mtime; a render touches only `render_work/` and `public/fr/`.
**How to apply:** before a long render start `bash -c 'while true; do touch .tmp/<p>/* public/<p>_* render_work/chunked_<id>/* ; find .tmp/stills_bundle/<id> -maxdepth 1 -exec touch {} +; sleep 300; done' &`; register the composition inside a component that Root already imports (PoisonComps → DatePoisonComp.tsx), not by editing Root.tsx; keep the cut audio wav (`.tmp/<p>/cut.wav`) and the frames; after any src change the judder probe must be rerun before resuming (hook). Related: [[feedback-judder-probe-before-full-render]].
