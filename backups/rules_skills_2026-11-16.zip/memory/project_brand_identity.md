---
name: brand-identity
description: One identity in shape, 5 colour palettes (steel/olive/maroon/kraft/teal) in src/brand.ts, chosen per video with spec "brand" (2026-10-29)
metadata:
  node_type: memory
  type: project
  originSessionId: e9cc025d-ecbf-4f39-9fee-5cc806491a64
  modified: 2026-10-29T07:26:25.461Z
---

User 2026-10-29: «هوية واحدة ولكن 5 أنماط لونية، هي هوية من حيث الشكل، و5 من حيث اللون» (replaces the single steel palette of 2026-10-28).

Source of truth: `src/brand.ts` — `PALETTES` (steel default, olive, maroon, kraft, teal; same tokens), live mutable `BRAND`, `applyBrand(name)` (MontageFromSpec calls it from spec `brand`; LabScene/TransitionScene from the gallery's palette switcher), `alpha(hex,a)` for translucent tokens, `BRAND_BAR` getters, `STARS` per-palette default background (`WarmBase` → KhBg; steel keeps the approved blue stars), `BRAND_HEX` = union of all palettes. `mgThemes.ts` maps every theme name to a live getter object over BRAND. The kit's literal hex/rgba were converted to `BRAND.x` / `alpha(BRAND.x, a)` by scratch/ptw/brand_codemod*.cjs. Backgrounds are never green/olive (MONTAGE_BRIEF rule), so the olive and teal palettes have neutral/blue bases.

**Why:** shapes stay the channel's identity; colour varies per video.

**How to apply:** new colours only as `BRAND.<token>` read at render time (never a module-level copy, it would freeze the palette); brand_audit + coverage_check (unknown palette) in stage check. Related: [[montage-as-data-spec]], [[elements-gallery]].
