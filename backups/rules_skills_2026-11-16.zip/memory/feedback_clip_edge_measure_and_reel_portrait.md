---
name: feedback-clip-edge-measure-and-reel-portrait
description: "Baked split clip|sheikh boundary must be measured on the real vertical edge (prep's width guess left a sliver of the clip in his card); reels are always portrait 9:16"
metadata:
  node_type: memory
  type: feedback
  originSessionId: aeb26639-f5c9-4e60-b9d9-804d2691fa9e
  modified: 2026-11-16T08:32:40.650Z
---

2026-11-16 (individual-religiosity, frame 305): the user circled a sliver of the answered clip (wooden railing) at the left edge of his landscape card. `stage.mjs prep` / `source_windows.mjs` guessed the split from `width` (0.34 → clip x 111+527, sheikh from 638) but the real vertical edge was at **x = 734** (measured: max column gradient across x 560–860 on two frames). Fixed in the spec `splits` (clip w 623, sheikh x 736 w 1184) and in `.tmp/<p>/sources.json`.

**Why:** the sheikh crop started 96 px inside the clip.
**How to apply:** after prep, for every video with a baked split measure the column-gradient edge (numpy on a gray crop) before trusting `sources.json`; sheikh crop starts ≥ edge+2; check the first split frame in Studio. The three videos prepped the same night (sufi has no video clip; ahmed-abdo-maher and hadra-khatib do) need the same check.

Also the user (2026-11-16): «الريل طولي وليس عرضي» — a reel is always portrait 9:16 (own spec, kind reel, portrait cover `cover_gpt_port.png`), never landscape. See [[four-videos-state-2026-11-16]].
