---
name: feedback-user-pictures-not-cropped
description: Pictures the user sends are never cropped to a frame; the frame follows the picture's aspect
metadata:
  type: feedback
---

الصور التي يرسلها المستخدم لا تُقصّ لتناسب الإطار، بل يُجعل الإطار مناسباً لها (2026-10-30، فيديو HaithamJail).

**Why:** صور المنشورات الست كانت تُصغَّر بعرض فقط فيُقصّ الإطار الثابت؛ وغلاف ThumbPro كان صندوقه ثابتاً.
**How to apply:** بعد كل `grid_plan --write` أعد حساب `h` من `w` بنسبة الصورة (`.tmp/<p>/fix_aspect.mjs` كنموذج)، وأعطِ غلاف evidence حقل `nat`. «اعرض كلام فقط» لا تعني إخفاء المقطع المردود عليه. ارتباط: [[feedback_apply_rules_before_user_asks]].
