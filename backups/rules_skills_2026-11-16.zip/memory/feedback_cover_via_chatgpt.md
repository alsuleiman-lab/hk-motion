---
name: feedback-cover-via-chatgpt
description: Covers are now made in ChatGPT via Claude in Chrome with uploaded photos + a no-face-change prompt + a topic-specific background (2026-11-06)
metadata:
  node_type: memory
  type: feedback
  originSessionId: c55085ef-1d7c-433b-9e41-f4d4c4bacfd1
  modified: 2026-11-06T10:36:08.212Z
---

The user ordered (2026-11-06): make covers by opening ChatGPT in Chrome, uploading the sheikh photo (public/sheikh_gallery/<robe>/) and a frame of the replied-to clip, with a prompt that forbids changing facial features, and **the prompt must also ask for a background that suits the video's topic**.

**Why:** the experiment on `masaj_syria` («مساج رباعي؟!») kept faces/beard intact and Arabic text correct; the user approved and said to use it from now on.

**How to apply:** follow the "الغلاف بـChatGPT" section in `.claude/skills/thumbnail-design/SKILL.md` (proposal in rules_registry/proposals/cover_via_chatgpt_topic_background_2026-11-06.md). Copy gallery photos to the scratchpad before file_upload (hard links are refused). Check faces at full size, then download to public/<p>/cover_gpt.png. Open point: how the finished image is placed in the first 0.25 s with the tear opening. See [[feedback_cover_photos_from_sheikh_gallery]].

**Update 2026-11-09:** mandatory for every speech montage (landscape, portrait, reels) — I forgot it once and the user objected. Prompt template + reference image: `.claude/skills/thumbnail-design/refs/chatgpt_cover_prompt.md`. Streams and lessons: I design those covers myself (Remotion), not ChatGPT.
