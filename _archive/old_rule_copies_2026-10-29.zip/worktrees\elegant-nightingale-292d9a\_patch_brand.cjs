const fs = require("fs");
const R = "S:/AI_Tools/Remotion_Workspace/src/";
const patch = (file, pairs) => {
  let s = fs.readFileSync(R + file, "utf8");
  for (const [a, b] of pairs) { if (!s.includes(a)) { console.error(file, "MISSING:", a.slice(0, 80)); process.exit(1); } s = s.replace(a, b); }
  fs.writeFileSync(R + file, s); console.log("patched", file);
};

// 1) every theme name renders the identity (steel = the item card); the table stays so old code still compiles
patch("MG.tsx", [[
  "export const MGTheme: React.FC<{ theme: MGThemeName; children: React.ReactNode }> = ({ theme, children }) => { CUR = THEMES[theme] ?? THEMES.steel; return <>{children}</>; };",
  "/** one colour identity (src/brand.ts, user 2026-10-27): whatever `theme` an older composition passes, the brand (steel) is used */\nexport const MGTheme: React.FC<{ theme: MGThemeName; children: React.ReactNode }> = ({ children }) => { CUR = THEMES.steel; return <>{children}</>; };"]]);

patch("mgThemes.ts", [
  [`  steel:  { paper: "#e2e8ee", paper2: "#d6dee6", card: "#f6f8fa", ink: "#16212e", accent: "#2f5f94", onAccent: "#ffffff", mark: "#b5412f", green: "#5d8a78", blue: "#3d7bc4", navy: "#14365c", gray: "#8793a1", label: "فولاذي هادئ" },`,
   `  // the brand (src/brand.ts) — the only theme in use since 2026-10-27; the others are kept only so old code compiles
  steel:  { paper: BRAND.paper, paper2: BRAND.paper2, card: BRAND.card, ink: BRAND.ink, accent: BRAND.accent, onAccent: BRAND.onAccent, mark: BRAND.mark, green: BRAND.green, blue: BRAND.blue, navy: BRAND.navy, gray: BRAND.gray, label: "هوية القناة" },`],
  [`export type MGThemeName =`, `import { BRAND } from "./brand";\nexport type MGThemeName =`],
]);

// 2) key-phrase chip: always the brand timer colours
patch("MGExtras.tsx", [[
  "theme = THEME_LESSON, bg = theme.timerBg, fg = theme.timerText }) => {",
  "bg = BRAND_BAR.timerBg, fg = BRAND_BAR.timerText }) => {   // one colour identity: a passed `theme` is ignored"]]);
{ let s = fs.readFileSync(R + "MGExtras.tsx", "utf8"); if (!s.includes('from "./brand"')) { s = 'import { BRAND_BAR } from "./brand";\n' + s; fs.writeFileSync(R + "MGExtras.tsx", s); } }

// 3) PortraitKit: the bar theme and the decorated base follow the brand
patch("PortraitKit.tsx", [
  [`export const BAR_WARM: BarTheme = { timerBg: "linear-gradient(#7a5233,#583820)", titleBg: "linear-gradient(#8f6a44,#6b4a2c)", timerText: "#ffe9b0", titleText: "#fff7e0", subText: "#f2dfbf" };`,
   `/** kept under its old name for the specs/compositions that import it: the brand bar (src/brand.ts) */\nexport const BAR_WARM: BarTheme = BRAND_BAR;`],
  [`/** warm beige/brown decorated base (used under collage pieces) */`, `/** the decorated video base in the brand colours (dark calm navy, drifting dots, soft light; never black, never plain) — old name kept */`],
  [`    <AbsoluteFill style={{ background: "linear-gradient(170deg,#c2a982 0%,#ad9068 48%,#8c7050 100%)" }}>
      <AbsoluteFill style={{ backgroundImage: "radial-gradient(rgba(255,255,255,.22) 2.4px, transparent 3px)", backgroundSize: "44px 44px", backgroundPosition: \`\${drift}px \${drift * 0.6}px\` }} />
      <AbsoluteFill style={{ background: "radial-gradient(ellipse at 62% 22%, rgba(255,244,222,.38), transparent 55%)" }} />
      <AbsoluteFill style={{ background: "radial-gradient(ellipse at 20% 78%, rgba(120,76,36,.28), transparent 55%)" }} />`,
   `    <AbsoluteFill style={{ background: \`linear-gradient(170deg,\${BRAND.base2} 0%,\${BRAND.base} 48%,\${BRAND.base3} 100%)\` }}>
      <AbsoluteFill style={{ backgroundImage: "radial-gradient(rgba(201,212,224,.14) 2.4px, transparent 3px)", backgroundSize: "44px 44px", backgroundPosition: \`\${drift}px \${drift * 0.6}px\` }} />
      <AbsoluteFill style={{ background: "radial-gradient(ellipse at 62% 22%, rgba(61,123,196,.22), transparent 55%)" }} />
      <AbsoluteFill style={{ background: "radial-gradient(ellipse at 20% 78%, rgba(10,18,30,.35), transparent 55%)" }} />`],
]);
{ let s = fs.readFileSync(R + "PortraitKit.tsx", "utf8"); if (!s.includes('from "./brand"')) { s = s.replace('import React from "react";\n', 'import React from "react";\nimport { BRAND, BRAND_BAR } from "./brand";\n'); fs.writeFileSync(R + "PortraitKit.tsx", s); } }
