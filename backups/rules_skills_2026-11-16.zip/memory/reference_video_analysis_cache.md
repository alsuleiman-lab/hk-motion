---
name: video-analysis-cache
description: "tools/video_cache.mjs — one GPU pass over a video, cached windows/thumbs/proxy; 4.4x faster, 38x less CPU (measured 2026-10-23)"
metadata:
  node_type: memory
  type: reference
  originSessionId: 16fc5954-5269-403d-b4a2-8fb9faf8b8b0
  modified: 2026-10-23T11:53:01.209Z
---

`node tools/video_cache.mjs analyze <video> [--map public/<name>_map.json --of source|cut] [--proxy]` → `.tmp/cache/<id>/` (meta, windows.json with clip/book windows + cut↔source times, thumbs, optional proxy 640x360 NVENC). `bench` records the fastest decode mode per codec in `.tmp/cache/decode_mode.json`. Full details are in the header of the tool.

**Measured on the 3.7 GB HEVC source (RTX 3090):** CPU decode 184.7 s / 1529 CPU-s; `-hwaccel cuda` only 159 s / 186 CPU-s; CUDA frames + `scale_cuda` + `hwdownload` of the small frames 41.8 s / 40 CPU-s (NVDEC 96 %). Full analysis 54.7 s, cached rerun 0.0 s, a threshold change re-runs only the `windows` stage (~11 s), a deleted chunk re-scans only that chunk (~9 s). Same on the H.264 cut: 33.9 s vs 60.3 s. 3 of 5923 samples differ from the CPU result (boundaries ≤ 0.25 s).

**Why:** the user asked (2026-10-23) to stop re-decoding the big HEVC for every check and to cut CPU use. **How to apply:** run it once per video (and after a re-cut, on the cut file with `--map … --of cut`); read `windows.json` instead of scanning again; never use the proxy for export or matting. The rule text is only in `.tmp/PREFERENCES_proposal_2026-10-23.md` (rule edits go through a proposal first).
