---
name: feedback-streams-cut-once-then-slice
description: "STRICT — a stream is prepped and cut ONCE as a whole, clips are slices of that cut; never prep/cut per clip (cost two hours and the user's anger, 2026-11-15/16)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 19435a74-d517-459c-9572-b7693d09ee81
  modified: 2026-11-16T00:59:16.780Z
---

The user (2026-11-16): «القص يكون مرة واحدة في البداية، ثم بعد ذلك تقسم مقاطع، يعني ما تحتاج إلى إعادة قص مدري كم مرة. ليش هالتأخير هذا؟ غير مقبول.» then «اعمل ما بوسعك لكي تتجنب تكرار هذا الخطأ».

**Why:** on the 2026-11-15 stream (`qe`, 83 min, 40 clips) I split the source into clips first and ran `stage prep` + `cut_smart` on each one (≈3–4 min × 40) — the rule «كتلة واحدة» (PREFERENCES «منع تكرار فشل البثوث» item 1, skill lessons-and-streams item 0) already said not to, but my own skill item 12/14 and the earlier `qd` reels had taught the per-clip flow. Then a tool bug (inner_pauses at −34 dB + VAD gaps dropped quiet reading, «مش عارف كيف») forced re-cuts, and I used `--keep` where `--keep-sound` was needed.

**How to apply:**
- Whole stream: `stage prep` once → read transcript by speakers → write `.tmp/<p>/plan.json` → ONE `cut_smart.sh <p>` with `KS` (ranges of words whose midpoint is outside `vad.json`, passed as `--keep-sound`) → `tools/stream/lost_speech_check.mjs <p>` → clips are slices (`tools/stream/clip_cut_all.mjs`), no new cut/ASR/smoothing.
- `stage.mjs` now refuses `prep|cut` for any id listed in a stream's `plan.json` (bypass only `STREAM_SLICE_OK=1`, for the slicing tool).
- Before any long batch: compare its steps with the skill, estimate the time, and if I'm multiplying a heavy step by the clip count — stop.
- `--keep` keeps a clip as speech but still cuts VAD gaps (noise); `--keep-sound` keeps all sound untouched. `inner_pauses.py` now never drops a range containing a spoken word.

Related: [[feedback_stream_failure_study_2026_11_11]], [[feedback_streams_cut_fully_plus_reels]], [[feedback_fix_failures_never_stop]].
- **Never end a turn with background work running without `.tmp/keep_awake` (ISO future time) + the keep-awake request:** the Stop hook hibernates the PC when the user sleeps (02:18 → 09:11 on 2026-11-16, a 7 h freeze of the whole-stream cut).
