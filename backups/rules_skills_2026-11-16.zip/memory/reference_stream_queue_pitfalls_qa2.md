---
name: stream-queue-pitfalls-qa2
description: "why the 31-clip qa2 stream queue was slow (2026-11-11) and the fixes: one queue only, solo-card coordinates, bumper vs audio mux, judder on pre-bumper original"
metadata:
  node_type: memory
  type: reference
  originSessionId: 19435a74-d517-459c-9572-b7693d09ee81
  modified: 2026-11-11T16:15:43.691Z
---

Stream queue (`tools/stream_queue.mjs`, helpers in `.tmp/b2_*.sh|mjs`) lessons from the qa2 stream (31 clips + reel):

- Never leave several `stream_queue` processes on the same json: three ran at once and fought over stills/CPU. Kill by PID with `taskkill //PID` (a PowerShell Stop-Process pattern matches its own shell, exit 255).
- Retrying a failed check changes nothing: fix the spec first (scraps with text not in the speech are dropped, gaps get scraps/zooms, `nameTag` alone, 4 kit kinds incl. tiny `pic`), then run the queue once.
- Landscape solo cards (nameTag/subscribe) must sit inside the solo slot [390,840,1520,985] but left of the face zone (title-bar zone starts x≈990–1160): nameTag land {x:692,y:800}, subscribe land {x:410,y:838} (left edge, y top ≥836). Any other value is snapped back to 955/684 by `grid_plan --write`.
- `hybrid_any` now prepends the 5 s opening bumper itself and mixes the audio: never replace its audio with the unshifted wav; judge judder on `.tmp/bumper_orig/hyb_<id>.mp4` (pre-bumper). Judging the bumpered file gives ~35% agreement (150 frames shifted).
- `judder_check` windows need ≥4 s margin at the end: for clips < ~15 s or zoom-heavy use `--at <s> --len 90` in a zoom-free span; a failing run deletes that file's gate entry.
- `grid_sheet` failed on clips < ~10 s (no minute samples): patched to sample quarters.
- `final_review` compared `bumper.at` (an ISO date) with seconds: patched to use it only when numeric.
- Whole-stream `audio_gate` can't be run per clip (needs tr_vad/map of the block): per-clip `pause_check` is the substitute, disclose it.
