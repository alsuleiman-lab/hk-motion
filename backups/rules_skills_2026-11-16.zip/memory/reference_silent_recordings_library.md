---
name: reference-silent-recordings-library
description: where the Sheikh silent watching recordings live (silent_recordings/ in the workspace) and what is there
metadata:
  type: reference
---

`S:\AI_Tools\Remotion_Workspace\silent_recordings\` holds his silent recordings (moved from C: on request, 2026-10-18). Currently `صامت1.mp4` (60 s, 1080p, plaid shirt, looks at the screen on his left). Outside public/ on purpose. New recordings he sends are MOVED here.

**How to apply:** when building a silent-reaction video, offer the recordings from this folder and copy the needed one into public/silent/<name>/. See [[project-silent-reaction-skill]].

Auto-filing rule (2026-10-19): when he names a file "صامت N" and says it is his silent recording, MOVE it from C: into silent_recordings/ without asking. Now there: `صامت1.mp4` (60 s), `صامت 2.mp4` (29.7 s, 1080p).
