---
name: feedback-original-voice-no-light-change
description: "keep the original recording's voice in cartoons; light pitch changes sound AI — propose only a very strong voice conversion for discussion"
metadata:
  node_type: memory
  type: feedback
  originSessionId: f3cde5e1-d3eb-4c09-be71-9a5dae9b84b6
  modified: 2026-11-02T14:39:19.995Z
---

For cartoons made from a user's clip, keep the **original voice unchanged**. A light per-character pitch/formant shift makes it sound like AI to the listener. If a character really needs a different voice, only propose a **very strong** conversion and discuss it first — never apply a light tweak. (2026-11-02, after the Abu Khatt «فتنة الممات» preview.)

**Why:** the user heard the pitch-shifted voices of the previous film (Dodo, where they had asked for a change) and the new one and judged that weak changes feel artificial.

**How to apply:** default `make_voices` = plain extraction of the source audio; ask only when a strong conversion is wanted. Speaker roles follow the meaning (a rhetorical question inside an answer stays with the answerer); cut at the lowest-energy instant, not at ASR word times. Related: [[feedback-arabic-short-and-fix-into-skill]].
