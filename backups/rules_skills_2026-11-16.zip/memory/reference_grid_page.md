---
name: grid-page
description: "Montage layout grid page (artifact) — editable slots per screen mode over his real clip; saves to db grids/current, applied to data/layout_grids.json"
metadata:
  node_type: memory
  type: reference
  originSessionId: d78793b3-e99b-4684-88db-353297219fb1
  modified: 2026-10-29T22:44:18.660Z
---

Page: now the 6th tab of the local gallery http://localhost:5601 (2026-10-30; the old claude.ai page belongs to the other account and is not the reference). Build: `node tools/grid_page.mjs [spec] [--at 40]` → scratch/grid_site/{index.html, clip.mp4}, publish index.html with files {clip.mp4} to the same url. Template `tools/grid_page.html`.

The user drags slots and presses «احفظ» → ArtifactData get collection "grids" doc "current" (fields `grids` and `notes` are JSON strings). Apply: write grids.land/port into data/layout_grids.json (keep kinds/_ keys), rebuild + republish the page, rerun `tools/grid_plan.mjs`. Tools that use the grid: grid_plan (place + face check, no render), grid_sheet (3 frames/min), stage check. Related: [[elements-gallery]].
