---
name: no-background-isolation
description: "Isolation = quick isolation only (2026-10-29): reels while a clip shows, full versions only where needed; spec matte + behind"
metadata:
  node_type: memory
  type: feedback
  originSessionId: f3346621-4118-4993-a9ba-566a55dce1a5
  modified: 2026-10-29T07:26:18.851Z
---

Quick isolation only (user 2026-10-29, replaces "no isolation at all" of 2026-10-27): in a **reel** while a video is shown (the answered clip), and in **landscape / full portrait only when needed**, to put a shot between him and his background. Fast RVM matte via `node tools/matte_cache.mjs get public/<cut>.mp4 0 <end>` (ratio 0.5, no matte_strong, no fixes; small gaps are fine). Spec fields `matte: {src, startFrom}` + `behind: [{from,to}]`; MontageSpec draws `MaskedSheikh` over the full pictures and the clip card in those windows. No isolated hook, no chest/bouquet fixes, no isolation outside the windows. Old isolation rules stay in the hidden archive S:\AI_Tools\_remotion_rules_archive (never read or cite it).

**Why:** the user first abolished isolation (2026-10-27), then on 2026-10-29 allowed it as a quick tool for reels and for occasional "behind him" shots.

**How to apply:** write each isolation window with its reason in the plan; rules_audit "quick isolation only" and coverage_check (behind needs matte) must pass. Related: [[rules-location]], [[montage-as-data-spec]].
