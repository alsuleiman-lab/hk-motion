---
name: do-not-change-approved-cast-look
description: Never restyle the approved cartoon cast (Abu Khatt legs are single lines, men have beards) to make an action readable
metadata:
  type: feedback
---

On «ليلة الشارع» (2026-11-11) I switched Abu Khatt's legs to thick coloured trousers (`trousers` key) and removed A's beard to tell the two men apart; the user objected twice: «رجل أبو خط عبارة عن خط ولم أطلب منك تغييرها» and «والرجل يجب أن يكون له لحية».

**Why:** the cast is an approved reusable library; look changes are the user's call, not a workaround for readability.

**How to apply:** keep library looks exactly (single-line legs, beards); tell the two characters apart by clothing colour only; make the action readable through contact/anchors, not by redrawing. See [[feedback_study_source_video_before_cartoon]].
