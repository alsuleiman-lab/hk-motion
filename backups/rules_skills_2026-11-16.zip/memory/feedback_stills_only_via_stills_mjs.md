---
name: feedback-stills-only-via-stills-mjs
description: "never bundle with the real public/ folder; stills only through tools/stills.mjs (cached bundle + hard-linked assets) — the user's standing order since 2026-10-22"
metadata:
  node_type: memory
  type: feedback
  originSessionId: ef9ee0b9-d7b5-4beb-81f6-359245969b3e
  modified: 2026-11-05T13:54:38.129Z
---

On 2026-11-05 I wrote my own `tools/poison_stills.mjs` using `bundle()` on the real `public/` (≈23 GB copied per run); two runs plus other temp filled S: to 100% and the stage check failed with ENOSPC. The user: «اتفقنا سابقاً على إبطال هذه الطريقة البدائية وكان عندنا بديلة».

**Why:** `bundle()` copies all of public/ (here 23 GB) every time; the agreed method is `node tools/stills.mjs <CompId> <outDir> name:frame` (code bundle cached in `.tmp/stills_bundle`, only the needed assets hard-linked).
**How to apply:** for any still/preview check use `tools/stills.mjs` (or `tools/edit_block.mjs`, `grid_sheet`, which call it); never write a new script that calls `bundle()` without an empty/limited publicDir; before a heavy step look at `df -h /s`. See [[reference-remotion-official-skills-stills-speed]].
