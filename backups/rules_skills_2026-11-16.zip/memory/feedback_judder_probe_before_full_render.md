---
name: judder-probe-before-full-render
description: always render a 10-second clip from the middle and check judder before any full render (tools/judder_probe.mjs, enforced by the hook)
metadata:
  type: feedback
---

Before ANY full render, render 10 seconds from the middle of the video with the fast path and check judder against the source; only then run the full render.

**Why:** the user (2026-10-27) lost hours on full renders that turned out jittery (stale frames from `EuKit.Pic`); a 10-second probe finds that in about a minute. See [[feedback_judder_root_cause]].

**How to apply:** `node tools/judder_probe.mjs <CompId> --src <smoothed cut> --offset <frames> --name <p> [--avoid curtains/zooms/shakes] [--crop … --src-crop … for portrait]` writes `.tmp/gates/<p>.probe.ok`; `tools/hooks/guard.mjs` denies render_chunked/render_final until a probe newer than every `src/*.tsx` edit exists. Any src edit means probing again (cheap).
