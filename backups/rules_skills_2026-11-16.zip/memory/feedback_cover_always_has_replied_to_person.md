---
name: cover-always-has-replied-to-person
description: Every reply-video cover must show the person he answers (cut out of the baked clip if no photo exists) — user shouted about it on 2026-10-28 after I skipped it
metadata:
  node_type: memory
  type: feedback
  originSessionId: 7f584406-3221-4cc2-8971-86400a5f9aad
  modified: 2026-10-28T13:35:40.862Z
---

When the video answers someone (a baked clip|him split, «المقطع المردود عليه»), the cover MUST include that person even if his name is unknown: crop the clip region from the source, matte one frame (tools/matte_rvm.py, ratio 0.75), measure with tools/cutout_head.py, use ThumbPro `layout:"duel"` with `opp` (+ `clip` polygon to drop bystanders/logos). I skipped it on MasajidRoots and the user objected loudly.

**Why:** the rule already existed (PREFERENCES §4 cover, MONTAGE_BRIEF §5); an unknown identity is not an excuse.
**How to apply:** do it in the cover stage every time there is a split window or a «رد على» context; never pick the `word` layout in that case.
