---
name: reference-kamali-voice
description: "كملي" = approved OmniVoice cloning reference voice at data/voices/kamali.wav (+kamali.txt); VibeVoice was tested and deleted as weak in Arabic (2026-11-05)
metadata:
  type: reference
---

الصوت المرجعي المعتمد «كملي» (أمر المستخدم 2026-11-05): `data/voices/kamali.wav` (18.8ث) ونصه `data/voices/kamali.txt`. يُستعمل مع OmniVoice: `generate(text=مشكول, ref_audio=…, ref_text=…, speed≈0.95)` من بيئة `VoiceStudio\project\.venv`. مرجع 11ث يُفسد النطق؛ يلزم ~19ث.

**النطاق:** لقراءة الأحاديث النبوية فقط؛ لا نسبة لأي كلام إلى صاحب الصوت ولا يُذكر اسمه (توضيح المستخدم 2026-11-05).

**Why:** جُرّب VibeVoice (Arabic_TTS مجتمعي) فأخطأ في كلمة بكل مقطع وبدا اصطناعياً فحُذف كاملاً؛ OmniVoice بالاستنساخ نطق «إنما الأعمال بالنيات» سليماً.

**How to apply:** لا تُقترح VibeVoice ثانيةً؛ كل مقطع مُولَّد يُفرَّغ بـWhisper للتحقق من النطق قبل العرض. المقترح مكتوب في `rules_registry/proposals/kamali_reference_voice_2026-11-05.md` (لم يُدمج في PREFERENCES بعد). انظر [[reference-preferences-file]].
