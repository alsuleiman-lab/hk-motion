---
name: git-commit-automatically
description: after finishing a change in a project that has a git repo (HK Stream at E:\new obs), commit it automatically without being asked
metadata:
  type: feedback
---

When I finish a change in a project with a git repo, I commit it myself — the user said (2026-10-26) git is automatic and I must do it, not wait to be asked.

**Why:** I finished the HK Stream frame-rate guard, left the files uncommitted and said so; the user answered that committing is automatic.

**How to apply:** commit at the end of each finished piece of work, in the project's own repo. HK Stream (`E:\new obs`) rules: call it only "HK Stream" in messages and docs (project AGENTS.md identity rule); the tree there holds ~260 earlier uncommitted paths, so commit only the files I touched and say in the message that those files also carry earlier uncommitted work; no git user is configured, so pass `-c user.name=Claude -c user.email=noreply@anthropic.com` per commit instead of changing config; end messages with the attribution line from the session reminder. Never push. The Remotion workspace repo is mostly untracked: ask before a first big snapshot there.
