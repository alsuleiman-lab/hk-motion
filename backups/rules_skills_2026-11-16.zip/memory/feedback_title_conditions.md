---
name: feedback-title-conditions
description: video title rules ordered 2026-11-11: attractive (question/shock/curiosity), truthful, mention caller's religion/country, <=99 chars, then #محمد_بن_شمس_الدين if room
metadata:
  type: feedback
---

Every video/stream/lesson title: (1) attractive by question («ما حكم…؟»), shock, or curiosity; (2) tied to the content, no lies; (3) names the caller's religion/creed/country when stated («حوار مع نصراني مصري»); (4) max 99 chars; (5) append #محمد_بن_شمس_الدين if room (so keep title ≈80).

**Why:** user order 2026-11-11 «سجل هذا كقاعدة». **How to apply:** all titles incl. cover text; rule is in PREFERENCES.md next to «عقيدة المتصل في العنوان». Related: [[feedback_doctrine_rule_streams_only]].

**2026-11-13:** in titles and cover words, never «شيعي» — always «واحد من 12» (user order). Recorded in PREFERENCES.md (after the caller-creed rule) and MONTAGE_BRIEF title conditions.
