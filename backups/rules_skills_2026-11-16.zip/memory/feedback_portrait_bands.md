---
name: feedback-portrait-bands
description: "Portrait layout: caption band ends at 1372 (blue), every element inside 1400–1880 (red); placed by estimate in the engine, never by screenshot measuring"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 14940f0b-7125-4eb4-b3ba-18d6387af65d
  modified: 2026-11-16T12:00:52.247Z
---

User order 2026-11-16, given with two marked screenshots:
- The caption goes in the blue band. `PillCaptions` is anchored at bottom 1372, so a second line grows upward.
- Every portrait element goes in the red rectangle: y 1400–1880, x 30–1050 (`PORT_ZONE` in src/MontageSpec.tsx).
- The user explicitly rejected a still-probe tool ("اعملها بدون لقطات شاشة، أنت قدّر المقاس والمكان"). It was deleted.

**Why:** elements and the caption were sitting on his beard and overlapping each other.

**How to apply:**
- The engine handles placement by estimate:
  - `portBox` gives the estimated box per item type.
  - `zoned` moves the item into the zone and shrinks it only when it is too tall.
  - Pick elements use `pickPortBoard` with `PICK_PORT_BOX` [top, height] in board units, in src/PickKit2.tsx.
- When adding a new element, give it an estimated box in those tables.
- Do not measure with screenshots.

Related: [[feedback-portrait-captions-always]], [[feedback-text-fit-and-hold]].
