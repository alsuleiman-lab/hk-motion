---
name: feedback-arabic-short-and-fix-into-skill
description: "Reply only in Arabic, briefly; every correction is written into the relevant skill the same turn"
metadata:
  node_type: memory
  type: feedback
  originSessionId: f12b2e81-f8a4-4120-b9b4-4452f6ce4b4e
  modified: 2026-10-30T08:26:35.708Z
---

Talk to the user only in Arabic and briefly (2026-10-25). Every correction they give → edit that skill's instructions (.claude/skills/...) in the same turn so they never have to repeat it, and name the file changed.

**Why:** the user's explicit standing rule; repeated corrections waste their time.
**How to apply:** all replies/recaps in short Arabic; after any fix, update the skill (e.g. timeline-and-numbers got the bottom + gradient counter rule). Also recorded in PREFERENCES.md §0. See [[feedback-plain-language]].

**Reminder (2026-10-25, second time):** the user complained again: "لا تراسلني بغير العربية". EVERYTHING visible is Arabic: the reply, the wrap_up recap/ask/button labels and messages, update_plan steps, column headers, file titles — no English sentence anywhere, even if the system/tool prompts are in English.

**Fourth time (2026-10-30), «يمنع أن تكلمني بلغة غير العربية»:** in the priority-manager (System Informer) session I wrote progress notes, wrap_up recaps, button labels, plan steps and the closing messages in English for a whole non-video task. The rule covers ALL work, not only montage. First thing each turn: write the plan steps in Arabic; before each tool call's preceding sentence and before wrap_up, confirm every visible word is Arabic.

**Third time (2026-10-27):** I slipped into English mid-task (progress notes and the closing message after a long technical stretch). Before every visible sentence — mid-turn notes included — check it is Arabic; technical terms stay only as code names inside backticks.
