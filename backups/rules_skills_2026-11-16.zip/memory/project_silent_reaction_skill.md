---
name: project-silent-reaction-skill
description: Skill «التعليق الصامت» (silent reaction videos) built 2026-10-16: files, layout, optional voice-over outro
metadata:
  type: project
---

Skill `silent-reaction` in `.claude/skills/silent-reaction/` + `src/SilentReaction.tsx` + `tools/silent_prep.mjs`. Input: his silent recording of himself watching + the source video; portrait = him on top / source below, landscape = source left / him in right card; captions, highlights, punch-ins, keywords, fact cards; optional voice-over outro over motion graphics. Goal: re-edit + reaction rights on re-upload.

**Why:** he wants to comment on others' videos without speaking and own the re-edit rights.
**How to apply:** when he says "اعمله تعليق صامت", run the skill; register a Latin-id composition in Root.tsx per project (not yet registered; untested with real footage). Be honest it does not guarantee Content ID/copyright safety. See [[feedback-essence-coherence]] style of approving storyline first.

Rules added 2026-10-16: default portrait; never bare-cut between his several recordings — swap the two cards' positions (reaction.clips); source women blurred; ambient motion every ~2 s; captions = key phrases only; first test project `ist-test` (Silent-Ist-Test-Portrait, Studio port 3100).
