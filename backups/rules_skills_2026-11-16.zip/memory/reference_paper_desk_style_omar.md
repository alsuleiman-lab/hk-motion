---
name: reference-paper-desk-style-omar
description: Reference video for «مونتاج ورقي» desk-diagram style (Omar Alshal, youtu.be/1v3J_4K7af4) + GitHub skills read
metadata:
  type: reference
---

نمط «المكتب الورقي»: ورق كريمي بملمس، مخطط تدفق حول لابتوب بخطوط زرقاء وبطاقات أيقونات، شرائح ورق ممزق عنابي/أزرق، عناوين على أوراق ممزقة. مفصّل في `.claude/skills/paper-montage/SKILL.md` القسمان 3ج و3د.

**Why:** المستخدم أرسل الفيديو 2026-11-10 وقال «تعلم من هذا»؛ توجيه أحدث يغلب «لا ورق فاتح».
**How to apply:** استعمله للشرح والمفاهيم المعقدة. مستودعات GitHub (pasteup، vox-style-video، paper-collage-skill، darin-broll-skill) قُرئت فقط ولم تُنسخ. See [[project_paper_montage_skill]].
