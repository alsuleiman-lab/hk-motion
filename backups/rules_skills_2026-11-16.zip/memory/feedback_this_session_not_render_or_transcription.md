---
name: feedback-this-session-not-render-or-transcription
description: "In the skills/motion-kit development session: do not touch, run or monitor rendering or audio transcription; leave them to the montage sessions"
metadata:
  type: feedback
---

في جلسة تطوير المهارات والقطع (2026-10-20) قال المستخدم: «لا علاقة لك بالرندر ولا التفريغ الصوتي».

**Why:** جلسات المونتاج الأخرى تتولى الرندر والتفريغ، وتدخّل هذه الجلسة قد يعطّلها (ذاكرة، كرت، ملفات).

**How to apply:** لا أشغّل رندراً ولا تفريغاً، ولا أراقب عملياتهما ولا أتدخل فيها. عملي: المهارات والقطع والقواعد والأدوات (وفحصها بلقطات ثابتة). عند طلب «راقب المونتاج» أكتفي بما يخص القطع/القواعد (مثل `tools/mg_usage_audit.mjs`) لا بحالة الرندر أو التفريغ. انظر [[feedback-use-new-motion-kit-mandatory]].
