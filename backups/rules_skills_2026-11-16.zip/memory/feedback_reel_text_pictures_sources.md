---
name: reel-text-pictures-sources
description: Writing types (torn/scraps/blur), hadith box with book-name source, pictures first ×1.3 and generated faceless, no picture sources
metadata:
  type: feedback
---

2026-11-01/02 (ريلات الكتفين/المتعة/مدد) — صارت قاعدة في PREFERENCES.md («أشكال الكتابة الثلاثة» والبند الذي بعده) وفي critical-rules 51–55:
- عبارة تلخّص كلامه ← `torn`؛ كابشن كلامه ← `scraps`؛ كلام المردود عليه ← `blur` أسفل اليسار. كنتُ أستعمل `torn` لكل شيء.
- **الحديث ← صندوق الحديث** (نوع `hadith` في MontageSpec، ملء الشاشة مثل الآية) بالمتن من sunnah.com/الدرر/الشاملة، **والمصدر اسم الكتاب ورقمه لا رابط**. كتبتُه مرتين خطأً (تلخيصي ثم torn برابط).
- لا مصدر للصور؛ الرابط للأخبار والفيديوهات فقط.
- صور أولاً؛ **الصور المولَّدة بـ`comfy_still.mjs` اعتمدها المستخدم** (رسم مسطح بلا ملامح)؛ أكبر بـ1.3؛ لا قصّ.

**Why:** غضب متكرر من أخطاء تتكرر بعد التنبيه.
**How to apply:** قبل البناء: كل حديث في `hadith`، كل مصدر نصي اسم كتاب، صورة لكل فعل. ارتباط: [[feedback_gallery_elements_default_look]] و[[feedback_user_pictures_not_cropped]].
