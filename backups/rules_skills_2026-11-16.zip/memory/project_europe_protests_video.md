---
name: europe-protests-video
description: Project record of the «اشتعال أوروبي» montage (2026-10-18): files, tools, kit components, open items
metadata:
  type: project
---

فيديو «اشتعال أوروبي: مظاهرات في فرنسا وإيطاليا وبلجيكا» (مصدر 15:44 + تسجيل تصحيح «التصحيح.mp4» 6:00). التركيبات: `EU-Protests-Portrait` (≤3د، بطاقة الشيخ أعلى) و`EU-Protests-Landscape` (8:30 مع مشهد مظاهرات ختامي)، ثيم teal. الملفات: `public/eu/`، الأدوات: `tools/eu_cut.mjs` (مصدران)، `eu_intro.mjs` (عزل + موشن أول 5ث)، `eu_render.mjs`، مكوّنات `src/EuKit.tsx` قابلة لإعادة الاستعمال.

**Why:** مرجع لأي فيديو أخبار قادم بالأسلوب نفسه (بطاقات أرقام + روابط مصادر + أعلام + تصحيحات).

**How to apply:** انسخ بنية EuKit/EuLandscape؛ أحكام المستخدم في [[feedback_no_unapproved_cuts_keep_context]] و[[feedback_no_news_without_proof]] و[[feedback_speaker_not_at_bottom]]. **الحالة (بعد الاعتماد):** العرضي اعتُمد وهو في `G:ملفاتيجاهزعرضيأساسية` (8:30، 991 ميجا)؛ المؤقتات لم تُحذف بقرار المستخدم؛ الطولي لم يُرندَر بعد (بطاقة الشيخ أعلى، ينتظر أمره ومجلده)؛ أرقام لبنان/شمال إفريقيا/غربها حُذفت لعدم وجود مصدر؛ رجل السيلفي (ايطاليا 1.mp4) أُخرج بأمره واستُعمل مقطع البورصة لبلجيكا.
