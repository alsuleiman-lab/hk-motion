---
name: feedback-drawn-metaphors
description: "Every episode must express his abstract meanings with code-drawn metaphors (roots, battery, filling glass, iceberg…), no assets or generated images; ≥1 per 2 minutes"
metadata:
  node_type: memory
  type: feedback
  originSessionId: f3346621-4118-4993-a9ba-566a55dce1a5
  modified: 2026-11-14T12:23:41.495Z
---

The user (2026-11-14) wants me to be creative during episodes: turn the meanings he says into drawn metaphors, the way the temporary galleries showed roots and branches, faith rising and falling like a battery, and a glass filling up. These are built in code from `src/PickKit.tsx` / `src/PickKit2.tsx` (spec `{ t: "pick", el }`). They need no existing asset and no generated pictures.

**Why:** the user said this expresses much of what he says "دون أن يكون لذلك أصل عندنا وبدون أن تولد صور". The temporary-gallery rounds showed that he values these meaning-pictures most.

**How to apply:**
- While planning a montage, read the transcript for abstract meanings and map each to a metaphor element:
  - grows/shrinks → Battery
  - roots/fruits → RootsTree
  - share → FillGlasses
  - surface vs hidden → Iceberg
  - repeating habit → ViciousCycle
  - two paths → Crossroads
  - never meet → NeverMeet
  - break a doubt → ClaimWall
- Invent new ones of the same kind when needed, and show them in the gallery first.
- Use at least one per 2 minutes. `pick_triggers` enforces this; a waiver goes in `skipMetaphors` with a reason.
- Rule text: PREFERENCES «المعاني المجسّدة».
- The galleries ran 4 rounds of 50 (2026-11-13/14). Picks go to the main gallery with a «متى يُستعمل» text and a trigger, and the round page is deleted after.

Related: [[feedback-arabic-only-everywhere]], [[project-motion-graphics-skill]].
