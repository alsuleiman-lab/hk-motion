---
name: feedback-lesson-tirmidhi31-corrections
description: zoom only at important words (never to fill gaps), picture of what is explained, rows for descriptions in his words, stamp at «المرجح», verses full screen in portrait lessons (2026-11-12)
metadata:
  type: feedback
---

User review of the Tirmidhi-31 lesson clips (2026-11-12): (1) «هذا هو المرجح» → red stamp at the word; (2) too much zoom in/out — zoom only at important words, fill gaps with pictures of what he explains (face + palms; fals coin + dinar/money changer) and cards writing his description; (3) verses in portrait lesson/stream clips fill the screen; (4) every written text, rows titles/labels/subs too, must be his words word for word. He also said: «شغل فكرك وحسن القواعد» — improve the rules, not only the video.

**Why:** the normalizer filled every gap with a slow push-in (eyes tired), and I paraphrased rows.
**How to apply:** rules in PREFERENCES §12, MONTAGE_BRIEF §11, critical-rules 92, lessons skill 9; spec_normalize now reports gaps instead of zooming; writing_place rejects non-verbatim rows; new spec item `stamp`. Related: [[feedback_writing_chosen_not_chunked]].
