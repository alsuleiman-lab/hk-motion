---
name: stream-failure-study-2026-11-11
description: evidence-based study of why the qa2 stream took ~21 h and why the user kept poking; root causes and the binding preventions now in PREFERENCES (2026-11-11)
metadata:
  type: feedback
---

Timeline (local time) from the transcript: 22:57 I started per-question prep (wrong; user corrected at 01:36 «ككتلة واحدة»); 00:25 delivered the wrong reel (sheikh's verdict instead of the caller's admission; corrected next morning); 02:45→07:50 work dead for 5 h (background died, likely a reboot) and I answered the next notification with «No response requested»; 07:52 relaunched then went silent 57 min while it failed at the audio gate until the user wrote «اعمل هيا»; user asked «وين وصلت» three times; 10:20→17:56 repeated failing checks (my under-built specs, 3 concurrent queues); bumper rule changed mid-run → desync and rework; I then blamed the queues first and wrote tool names to the user.

Same pattern on 2026-11-06/08 («تأخرت جدا»، «لماذا لم تكملها»، «الرندر واقف» twice, «قلت لك الاسم عربي»، «طولت جدا… كم يوم»): lessons were written as notes but not enforced.

**Why:** I improvise per job, wait passively for notifications, deliver without matching the user's description to the exact transcript lines and speaker, bypass gates instead of fixing, ignore «brief stale», and report in jargon.

**How to apply:** the 7-point block «منع تكرار فشل البثوث والدروس» in PREFERENCES.md and step 0 of lessons-and-streams; plus [[fix-before-render-use-render-queue]] and [[plain-arabic-no-tool-names]]. Proposed (needs the user's yes): a Windows logon task that resumes the render queue after a reboot.

**ADDED same day:** user: «تشتغل شغل ناقص وتنتظر الفحص حتى يقول لك أعد». Stage check now starts with spec_normalize (--normalize for streams/lessons, --dry report for others that fails when the spec is incomplete); a clip failing twice for the same reason means fix the tool/template that built it. Windows logon task RemotionResumeWork (approved) runs tools/resume_after_reboot.mjs: restarts the render queue worker and every registered long job (register before starting, unregister after). Tested via Start-ScheduledTask 2026-11-11.
