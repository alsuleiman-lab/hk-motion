---
name: project-hybrid-render-adopted
description: "Final render = hybrid (Remotion alpha graphics layer + FFmpeg/NVENC composite), adopted 2026-11-08; no other render engines to be tried"
metadata:
  node_type: memory
  type: project
  originSessionId: f3346621-4118-4993-a9ba-566a55dce1a5
  modified: 2026-11-08T22:58:43.930Z
---

The user adopted the hybrid path (`tools/hybrid_full.mjs`: Remotion draws only the graphics layer with transparency, FFmpeg composites over the source with CUDA decode + NVENC) as the final-render method on 2026-11-08. Measured on a simple 1080p 300-frame scene: 12.2 / 12.7 fps vs 4.3 for plain Remotion (x2.8). Not yet measured on a full montage.

**Why:** the browser decoding the video is the bottleneck ([[reference-session-errors-log]] style findings in PREFERENCES R-RENDER-SPEED.3); the hybrid removes it. The user then ordered every other tested method removed from my knowledge and disk (alternative engines, chrome-for-testing, the media-package video tag, their installs and scratch scripts were deleted).

**Next step (user, 2026-11-08):** the user will film a NEW video and we build it hybrid from the start (HybridHost/VSlot in src/hybrid/Slot.tsx, render with tools/hybrid_any.mjs). Data-spec montages (MontageSpec, e.g. mufti_iraq) do not use the hybrid host, so the Iraqi video is not the test case. Open question for that build: the 4 `behind` matte windows are unsupported by the hybrid.

**How to apply:** use the hybrid for final renders; verify quality and judder on the first real montage with it and report the measured fps honestly. Do not propose or test other render engines or browsers. Rule text lives in PREFERENCES.md R-RENDER-SPEED.5 and the MONTAGE_BRIEF render line. render_chunked / render_final / extracted-JPEG rules were kept as the existing fallback and were NOT deleted (the user's "delete other methods" was read as the tested alternative programs).

**Update 2026-11-09:** lessons now render hybrid: MontageSpec has HybridHost/VSlot (landscape, no splits/solos/behind/mini); .tmp/b2_render.sh L branch calls hybrid_any with fallback to render_chunked. Measured on Bath2-Shams-L (4318 frames): 5.1 min, 14.2 fps; judder on face crop 99.1% vs old 99.3% (both pass). Disk filled once: hybrid_any bundles copied public/fr (fixed: skips fr/matte_cache, deletes bundle on exit). Exported old file kept (user: leave as is).

**STRICT (user order 2026-11-09):** hybrid only. render_final/render_chunked/render_clip exit 4 via tools/hybrid_gate.mjs and the guard hook denies them; no fallback in .tmp/b2_render.sh. Old path only with the user's own words in the CURRENT message (env LEGACY_RENDER_USER_OK="<words>"). Unsupported comps (portrait, splits/solos/behind/mini) get PORTED to HybridHost/VSlot, never rendered the old way. Encoder cq 15 + 26M cap = ~16.7 Mbps (cq17 gave 10 Mbps, below R-RENDER-QUALITY).
