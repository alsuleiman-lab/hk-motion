---
name: feedback-approval-purges-everything
description: "«اعتمد» = everything of the project goes automatically (code, spec, titles, data, temps, original); user tired of reminding (2026-11-13)"
metadata:
  type: feedback
---
User 2026-11-13: «تأكد من انه احنا لما نعتمد مشروع كل ملفاته تروح. ليش دائما انبهك؟» — after Mufti-Iraq approval its component (registered in ReelsComps, CamelCase name), spec and prep log had been left, and the 22 Poison clips lingered in Studio.

**Why:** approval exists to clean the machine of finished projects; reminders mean the tool failed.
**How to apply:** on «اعتمد» run `node tools/montage_guard.mjs end <p>` at once (no asking); it now calls `tools/approve_purge.mjs` (spec, dedicated component, registry lines in Root/ReelsComps, titles/dates, data/youtube, preview proxies, done queue jobs, `<seg>_prep.log`, then tsc) and scans case/underscore-insensitively. Side clip sets with a different prefix (like Poison-*) are not caught: when approving, look at the Studio list for the project's helper comps and remove them too. Related: [[feedback-cancelled-means-deleted]], [[feedback-cleanup-deletes-idle-project-files]].
