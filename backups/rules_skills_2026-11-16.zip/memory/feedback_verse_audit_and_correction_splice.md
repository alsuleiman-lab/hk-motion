---
name: feedback-verse-audit-and-correction-splice
description: User corrections of a misread verse: splice audio into the cut, shift all times, show the verse full screen; verse_audit.mjs reports misreadings before any render (2026-11-09)
metadata:
  type: feedback
---

User sent «تصحيح.mp4» (hoodie, dark room — different look) to replace his misreading of Baqarah 214 («والذين معه» without «آمنوا») at frame ~6815 of «فيضانات غزة»: «عدّل الآيات، أظهرها ملء الشاشة في هذه الحالة فقط، وإن أخطأتُ في أي آية اكتب لي بوضوح قبل الرندر».

**Why:** the correction's picture must never show; the verse card covers it. He wants every misreading reported in plain words before rendering so he can re-record.
**How to apply:** audio from the correction (+5.8 dB to match level, internal pause ≤0.4 s, 20–60 ms audio fades), picture = original frames slowed to the new length, one NVENC re-encode of the whole cut (new file swapped in place, old kept in .tmp/<p>/fix/), then shift every time after the splice (spec, cut_words, map, verses.json, skipRequired; scripts in .tmp/gaza_floods/fix/apply_fix.mjs). Full-screen = `verse` item with `full:true`. `tools/verse_audit.mjs` (runs in `stage check`) lists omitted/added/replaced words per verse card; it also exposed two cards showing the wrong half of the verse (33:62, 4:102) — always run it after building cards. Limit: transcript-based, misses vowel/elongation errors. Related: [[project_gaza_floods_video]], [[feedback_no_opacity_transitions_gallery_only]].
