---
name: feedback-verse-questions-on-page
description: Recitation/verse questions go on the questions HTML page with a playable clip of the moment, never as a click question (2026-11-11)
metadata:
  type: feedback
---
When I asked about verse slips (Baqara 6, Al Imran 79) with AskUserQuestion, the user answered: «التعليمات أن تضع هذه الأسئلة في ملف html وأن تعطيني الموضع لأسمعه».

**Why:** he must HEAR the moment to judge a recitation; a text question cannot show it.

**How to apply:** verse / recitation / "is this what I said" questions → `node tools/questions.mjs add <p> --id … --q … --video public/<p>_cut_s.mp4 --t0 … --t1 …` with options, then give the page link (LAN IP) and the times. Click questions only for choices that need no listening. Related: [[feedback_questions_first_and_background_work]], [[feedback_verse_audit_and_correction_splice]].
