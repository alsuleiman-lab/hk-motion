---
name: feedback-verify-cut-words-against-cut-audio
description: "cut_words.json can be stale vs the real cut audio (mufti_iraq: +2.84 s after 168 s, +2.67 s after 285 s); verify by a fresh Whisper pass over cut16k.wav before trusting any word-derived timing (2026-11-09)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: be6dff2a-c908-46d6-bb2f-477031ad8aae
  modified: 2026-11-09T17:57:55.032Z
---

In `mufti_iraq` every element built with `at("phrase")` from `.tmp/<p>/cut_words.json` appeared ~2.7 s late after 2:48, and I "fixed" verses by retiming them to the same wrong words (making them wrong). The user caught it with exact frames (spoken 9293, shown 9371). The words file came from an older cut; the real audio (`cut16k.wav`) was 2.84 s shorter after 168 s and 2.67 s after 285 s.

**Why:** all tools (writing_sync, verse_audit, scraps_times, coverage_check, late_audit) trust cut_words.json, so they all pass while everything is late; late_audit only compared against the same wrong words.

**How to apply:** when the user reports lateness, or before any retime from words: transcribe `cut16k.wav` fresh (faster_whisper large-v3, add torch\lib to dll dir, PYTHONIOENCODING=utf-8), compare per-word offsets in 20 s bins to cut_words.json; if bins differ from 0, correct the words and shift every word-derived field (items at/until/from/to/times, nested rows[].at, zooms, shake, behind + regenerate matte windows with `matte_windows.mjs --force` and re-extract `public/fr/w_*` frames, skipRequired `@sec`, verses.json) via a piecewise D(t). Splits/cams come from video analysis: leave them. When the user gives exact frames of speech, trust them over the tools. See [[feedback_studio_deep_links]].
