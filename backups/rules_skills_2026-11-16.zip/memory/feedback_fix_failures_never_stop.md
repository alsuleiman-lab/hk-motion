---
name: feedback-fix-failures-never-stop
description: On any failure (render, check, Studio compile error) diagnose and fix then retry; never stop at a report; use the stream queue always (2026-11-09)
metadata:
  type: feedback
---

When something fails I must find the cause, fix it and re-run until it works; stopping/waiting is forbidden. The queue (tools/stream_queue.mjs) is the permanent route for lessons/streams.

**Why:** user order 2026-11-09 after I stopped at a hybrid failure and Studio sat on a compile error (a // comment in src/MontageSpec.tsx swallowed the rest of the flag case line) while I reported instead of checking Studio.

**How to apply:** after any edit of src/ check Studio itself (open localhost:3100, look for the red Error overlay), not only tsc. Hybrid-only rule: [[project-hybrid-render-adopted]].
