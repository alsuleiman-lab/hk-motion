---
name: feedback-times-mmss-and-torn-overuse
description: Report times as minute:second; never overuse the torn note; vary elements; add light sound effects; search real news posts
metadata:
  node_type: memory
  type: feedback
  originSessionId: af26c176-c778-4fdc-bec3-248d33a6168e
  modified: 2026-11-06T01:01:20.472Z
---

Write every time to the user as دقيقة:ثانية (e.g. 7:36), never raw seconds — they cannot navigate by seconds.

Torn note (`torn`) must not dominate a video (user 2026-11-06, abdul_america): keep it for ~1 key claim per 30 s, carry the rest with photos, generated stills, rewrite, arc, flash, scraps, rows, clock, verse, news. Add light sound effects (≤0.06, ≤5/min, ≥1.8 s apart, in word gaps) via `tools/mix_sfx.py`.

When he mentions a news post/photo (e.g. Trump's "two Americas" post) search for the real item (WebSearch), show it as `news` with a link, blur women's faces — don't skip it.

**Why:** he repeatedly complained about slowness, repeated elements and missing research.
**How to apply:** use mm:ss in all replies; budget torn count when drafting; run mix_sfx before the final audio; do a news search for every news/post mention. See [[feedback_save_tokens]].

Writing never before its words: tools/writing_sync.mjs (in stage check). Torn ≤50% of writing; questions/lists = StatRow rows; his quotes = WordScraps (2026-11-06). Always verify every spec image path exists (a .png referenced as .jpg shows a broken card).
