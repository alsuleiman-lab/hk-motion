---
name: feedback-no-full-check-per-small-fix
description: "Small spec fixes get only the quick targeted checks (writing_sync, coverage_check, one still); full stage check once at the end (user complaint 2026-11-08)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: be6dff2a-c908-46d6-bb2f-477031ad8aae
  modified: 2026-11-08T21:24:42.543Z
---

After each small fix (moving an element, retiming a card) I ran the full `stage.mjs check` (5–8 min, bundle + grid_sheet) and the user complained: «15 دقيقة يا ظالم حتى تعدل مكان العناصر».

**Why:** MONTAGE_BRIEF «التعديل كتلة واحدة» already says no full re-check after a local edit; the slow cycle makes the user wait for trivial changes.

**How to apply:** for a local fix run only `grid_plan --write`, `writing_sync`/`coverage_check` (seconds) and a single `stills.mjs` frame; run the full `stage check` once when all the user's notes are done. Batch several notes into one pass when they arrive together. See [[feedback_edit_is_one_block]].
