---
name: feedback-arabic-names-in-remotion
description: "Everything named in Remotion Studio (composition titles, Studio folders) must be Arabic; no foreign names (2026-11-09)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: f3346621-4118-4993-a9ba-566a55dce1a5
  modified: 2026-11-09T06:23:44.317Z
---

Name everything shown in Remotion Studio in Arabic: every composition has an Arabic title in `src/compositionTitles.ts` (helpers and reference comps too), and Studio folder names are Arabic (فيضانات غزة، البثوث، الدروس، أصول الهجين (مخفية)، عروض مرجعية، أدوات). Composition IDs stay Latin (technical).

**Why:** the user said «لا أريد أسماء أعجمية في ريموشن» and «سمِّ بالعربي». I first wrongly claimed Remotion rejects Arabic folder names; the project already patches Remotion (`tools/patch_remotion.mjs`) to accept them.

**How to apply:** when adding any composition or `<Folder>`, give it an Arabic title/name at once via `node tools/set_title.mjs <Id> "العنوان"`. Rule text: PREFERENCES.md (Arabic title line) + MONTAGE_BRIEF.md. See [[reference-studio-arabic-titles]].
