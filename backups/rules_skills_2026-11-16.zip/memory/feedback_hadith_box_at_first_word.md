---
name: feedback-hadith-box-at-first-word
description: Every hadith wording he recites gets its own hadith box from its first word, one box per narration (2026-11-09)
metadata:
  type: feedback
---

When he says a hadith, the hadith box (NoteCard with book + number) must open at the first word of that matn, not later and not only for the "main" narration. In the Gaza floods video he recited «ما من مرض أو وجع…» (Muslim, Ma'mar narration) then «وفي رواية ما من مصيبة…» (Bukhari 5640): I only boxed the second, 4 s late, and left the first as plain scraps. User was furious (2026-11-09).

**Why:** the rule "hadith always in hadith box with book+number" ([[feedback-hadith-box-and-reply-geometry]]) applies to every wording he quotes, at word onset.

**How to apply:** in the transcript sweep before building, find every «قال النبي ﷺ / وفي رواية / وفي حديث» and give each narration its own `note` at the word timestamp; verify the matn with shamela verify_quote; if the number cannot be verified, say so instead of inventing it.
