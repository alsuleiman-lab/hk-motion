---
name: cancelled-means-deleted
description: "When the user cancels an element/feature, delete its code completely; run only gallery-approved elements; moves are planned before the build"
metadata:
  node_type: memory
  type: feedback
  originSessionId: f3346621-4118-4993-a9ba-566a55dce1a5
  modified: 2026-10-28T18:41:46.142Z
---

When the user cancels an element in the gallery, **delete it from the code** (not "keep while others import it") and keep the name in `data/retired_elements.json` so `tools/rules_audit.mjs` fails if it returns. The renderer (`src/MontageSpec.tsx`, `APPROVED_TYPES`) only runs item types of elements approved in the gallery HTML; an unknown type is a loud error.

**Why:** retired elements kept coming back (Jordan video 2026-10-28) because their code stayed, and `mg_usage_audit` even counted `neon` as NeonWord.

**How to apply:** a cancel decision = delete component + gallery entry + docs lines in the same turn. Camera moves (push-in every 1–2 min, never >2 min apart; shake on objecting/sarcastic sentences) are PLANNED before the build by `tools/moves_plan.mjs` → `.tmp/<p>/moves.md` → spec `zooms`/`shake`; `coverage_check` (15 s gap, a picture per mention) is only the later check. Each video re-reads the rules (hook-enforced). Related: [[reference_elements_gallery_page]], [[feedback_no_background_isolation]].

Backup: `node tools/backup_push.mjs` commits code/rules/data (not media) into a SEPARATE small git store `S:/AI_Tools/Remotion_Workspace_backup.git` and pushes to its `backup` remote (user must create the private GitHub repo and add the remote). The damaged workspace .git was deleted on 2026-10-29; the workspace `.git` is now a gitfile pointing to the backup store (media excluded there). Never run `git gc` from several sessions at once.
