---
name: feedback-reel-always-card-grid-lessons
description: Reels whose replied-to clip stays on screen all along (split window = whole video): face shift, grid half-mode limits, 0.2s gaps, no nameTag, hclip for flicker (2026-11-11)
metadata:
  type: feedback
---

Five reels built in one go (jafri_raqs, english_proverb, atfaluhum_rijal, azka_ashari, qiss_mashlula; user instructions inside the recordings said «keep the replied clip on screen always»).

**Rules found by the gates (apply to any reel with a permanent card):**
- cams: draft `cx − 100` so his body sits right and the card (left −50, top 600, innerH 480) is visible beside the head; centred face hides the card behind his body.
- The grid treats a split window as `half`: key items (torn/scraps/blur/word) go to the `under` strip (170px: scraps ≤ 6 words size 50, blur y 1530 x 30 w 600); photos (pic/tphoto/date) shrink to ~70px unless the beard zone leaves a side strip → for permanent-card reels skip small pictures and use `skipMentions` with the reason (or accept the planner size).
- Consecutive items of one slot need ≥ 0.2 s between them (busy margin 0.15) but coverage fails at gaps > 0.3 s: set `until = next.at − 0.2`.
- `nameTag` cannot coexist with a split window → drop it in always-card reels.
- A flicker (speech bubble that appears at each word) = pre-render a small mp4 (PIL frames + ffmpeg concat) and show it as ONE `hclip` item with `psplits` (portrait lower panel), not many pic items.
- `writing_sync --fix` drops items it shortens; cut_words merge can jumble times (duplicated «جفري», shuffled words) → patch `.tmp/<p>/cut_words.json` from `cut_words_large.raw.json` before blaming the spec.
- Women in the clip: ffmpeg gblur of the panel + overlay a sharp keep-box on the pastor (use gblur, `boxblur` gave green chroma; even crop sizes).
- Frozen clip panel (second video not answered): overlay a still of the first clip's last frame over the panel from the switch time.

**Why:** gates failed repeatedly on these points; user wants all five delivered with preview links, no render until he agrees.
**How to apply:** start from `.tmp/mk_reels*.mjs` style generators (they are in the workspace .tmp, may be cleaned) and run scraps_times → sfx_bind → grid_plan --write → stage check. See [[feedback_reel_verse_fullscreen_and_word_onset]].
