---
name: feedback-pad-frames-before-render
description: Before a fast render, make public/fr/<cut> hold a file for EVERY composition frame (tail/extra frames included) or the last chunk fails after ~25 min
metadata:
  type: feedback
---

Fast render (`frames:true`) reads `public/fr/<cut>/f_<comp frame>.jpg`; the cut had 12969 frames, the spec 12971, and an appended `tail` made the composition 14845, so the last chunk failed three times (allah_taht, 2026-10-31).

**Why:** the frame-count check existed in [[feedback-always-fast-render]] («check the frame count matches the composition, clamp to the last file») but I only extracted frames and did not compare with `spec.frames`.
**How to apply:** after `kh_frames.sh`, compare `ls public/fr/<cut> | wc -l` with the composition frames; pad the missing numbers with copies of the last frame (`cp f_<last>.jpg f_<n>.jpg`) BEFORE the probe; rerun `judder_probe` (src edits invalidate its gate). Prefer building `frames` from `ffprobe nb_frames`.
