---
name: feedback-hadith-box-and-reply-geometry
description: every hadith he cites goes in the hadith box with full matn + book + number (never a torn note); reply-layout geometry set by the user's red boxes; covers use public/cov/sheikh_poses (2026-11-05)
metadata:
  type: feedback
---

User orders on 2026-11-05 during DatePoison:
1. **Hadith = `hadith` box** with the matn as in the source and «اسم الكتاب + رقم»; I had written two hadiths as torn notes («من قرأ آية الكرسي…» ← البخاري ٢٣١١، «خواتيم البقرة» ← البخاري ٥٠٠٩) and he called it a «خطأ فادح يجب ألا يتكرر».
2. **Landscape reply layout (dossier):** he drew red boxes: his card ≈ 86 % of the height (≈ 930 px with mount), centre ≈ (1289, 543), never touching the edges; the opponent's blue chip (`blur`) under the answered clip, centre ≈ (431, 880), tilted −7°, ≈ 29 px. Now defaults in `DebateLayouts.tsx` / `MontageSpec.tsx`.
3. **Covers:** use poses from `public/cov/sheikh_poses/` (symlink to `S:\AI_Tools\covers\sheikh_poses`), a suitable or random one each time; measure with `tools/cutout_head.py`, copy to `public/<p>/cover_pose.png`.

**Why:** he checks these details himself and wants them never repeated.
**How to apply:** before placing any quote from the Prophet ﷺ, search shamela (`shamela_search_hadith`) and use `hadith`; never paraphrase into `torn`. See [[feedback-doctrine-rule-streams-only]], [[feedback-stills-only-via-stills-mjs]].
