---
name: feedback-close-chrome-tabs
description: Always close Chrome tabs I opened (ChatGPT cover work etc.) before finishing; cover image must show the topic itself (2026-11-06)
metadata:
  node_type: memory
  type: feedback
  originSessionId: c55085ef-1d7c-433b-9e41-f4d4c4bacfd1
  modified: 2026-11-06T11:17:26.505Z
---

After using Claude in Chrome, close every tab I opened with `tabs_close_mcp` (user complained I left the ChatGPT tab open, 2026-11-06). Also: the cover's second picture must depict the subject (e.g. the man with the massage from the replied-to ad, women blurred beforehand with PIL), not just a face frame.

**Why:** the first «مساج رباعي؟!» cover only showed the man's face; the user wanted the man with the massage + blur on the woman, and noticed the open tab.

**How to apply:** after downloading the cover, close the tab before replying. See [[feedback-cover-via-chatgpt]].
