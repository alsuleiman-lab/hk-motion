---
name: reference-channel-index
description: Local index of the Sheikh's YouTube channels (@MShmsDin, @MShmsDin1; 6584 titles) — use channel_index.mjs find when he says «تكلمتُ عن كذا في حلقة سابقة»
metadata:
  type: reference
---

`data/channel/episodes.json` (built 2026-10-27 with yt-dlp, titles only: id, title, kind فيديو/بث/شورت, duration, views, URL). Search: `node tools/channel_index.mjs find "<موضوع>" [-n 8]` (Arabic-normalised word match on titles). Refresh: `node tools/channel_index.mjs refresh` (~2 min). Rule is in PREFERENCES.md §4 and MONTAGE_BRIEF.md.

**Why:** user wanted to reach a previous episode fast without re-searching each time (no transcripts needed: «فقط عناوين الفيديوهات»).

**How to apply (updated 2026-10-27):** do NOT show candidates up front: auto-pick the top match with `node tools/episode_ref.mjs pick <project> <slot> "<topic>"` (thumbnail+title+link into data/episode_refs/<project>.json), ask «is this the right episode?» by click AFTER the montage (with the approval question; `show` lists alternatives); if he changes it run `swap` (instant, no checks, no rebuild). If no title matches the talk is inside an episode: ask before building a transcript index.
