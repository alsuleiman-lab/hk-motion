---
name: deliver-to-jahiz-independent-of-approval
description: every finished render is copied to جاهز right away; approval only triggers the purge
metadata:
  node_type: memory
  type: feedback
  originSessionId: c8d915c7-db96-4f2d-90e9-fcd170615e00
  modified: 2026-11-16T08:44:59.475Z
---

كل فيديو مرندر ينجح فحصه يُنسخ إلى `C:\Users\mshms\Videos\جاهز` فوراً، دون انتظار اعتماد ودون سؤال.

**Why:** أمر المستخدم 2026-11-16: بعد أن سلّمتُ الرندر في مجلد العمل وسألتُ «هل تعتمده؟» قال «لا أراها في جاهز» ثم «الاعتماد لا علاقة له بالنقل لجاهز».

**How to apply:** بعد الرندر والفحص أنسخ الملف إلى جاهز (عرضي: العنوان + «-»، طولي: العنوان فقط) وأذكر ذلك، ثم أسأل «هل تعتمده؟» فقط لقواعد الحذف والتنظيف. انظر [[feedback_export_name_landscape_dash]] و[[feedback_approval_purges_everything]].
