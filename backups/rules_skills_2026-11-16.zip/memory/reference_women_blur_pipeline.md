---
name: women-blur-pipeline
description: "How to blur women's faces in a clip window (handheld conference footage): YuNet detector + purple-jacket fallback → blur_clip_keys, with the box-expansion trap"
metadata:
  node_type: memory
  type: reference
  originSessionId: 03ec385d-f18b-4a2a-acaa-fa545ead443b
  modified: 2026-11-03T17:02:32.634Z
---

Baked blur of women inside a baked-split clip window (user instruction «طمس النساء», 2026-11-03, WhiskyConf):
- `tools/women_faces.py <video> .tmp/models/yunet.onnx <hand_keys.json> <out.json> a-b … [--force a-b]` = per-frame YuNet faces; a face is a woman if it is above the purple-jacket blob (`purple_track.py` colour fallback) or near a hand-keyed woman box; `--force` spans = every face. Model file `.tmp/models/yunet.onnx` comes from opencv_zoo (github.com/opencv/opencv_zoo, raw LFS link) — re-download if missing.
- Hand keys alone fail on handheld pans; `tools/track_keys.py` (optical flow) drifts. Detection first, hand keys only as a hint.
- **Trap:** `tools/blur_clip_keys.py` expands every box (x−0.45w, w×1.9, y−0.15h, h×2.1). Give it boxes divided by 1.9/2.1 around the centre (x = cx−0.5w, y = cy−0.9h) or the blur swallows the speaker next to the woman.
- Bake onto the smoothed cut from the ORIGINAL (`cut_s_orig`), never re-blur a blurred file; stop Studio before replacing `public/<p>_cut_s.mp4`.
- Verify with gridded strips (ffmpeg drawgrid + arial.ttf copied next to the cwd) at pan moments; check the speaker's face stays visible.

**Why:** the user asked to blur women in the conference footage and to enlarge the blur area so little tracking is needed.
**How to apply:** any clip window with women (conference, street). Related: [[feedback_judder_root_cause]].
