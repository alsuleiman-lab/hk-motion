---
name: project-video-constitution
description: The 9-stage «دستور الفيديو» with automatic gates (MONTAGE_BRIEF §00, PREFERENCES §0) — read first for every video; render queue + sleep hook enforce it (2026-11-12)
metadata:
  type: project
---
After the «سانت رامبال» failures the user ordered strict self-binding rules. The constitution (MONTAGE_BRIEF.md §00, pointer in PREFERENCES §0, video-montage SKILL top, WORKFLOW_CHECKLIST item 0): orders planned before build → requirements ledger → real pictures checked by eye → writing chosen by reading → gallery geometry / background full with him right / no curtain / map beside him → audio without leftovers → link only after full check + phone preview + freeze, edits as blocks → render via queue → Arabic, parallel checks, no «done» without a frame.

**Why:** most failures were me treating a passing tool as done, routing around blockers, and mechanical generation.

**How to apply:** the checks run in stage check before the link (the render queue only renders — the user rejected content gates in the queue 2026-11-12: it records a failed job with its reason, I am notified, fix and resend; chunked rendering is fine if better); the prompt hook sets .tmp/user_sleeping when he says he sleeps (any other message clears it) and the Stop hook hibernates (90 s) when I stop with no render running, or arms tools/hibernate_after_queue.sh while one runs (.tmp/keep_awake = ISO time to hold). Old conflicting rules archived in rules_registry/archived_2026-11-12.md (the outside archive folder is permission-blocked). Related: [[feedback_render_then_hibernate]], [[feedback_done_means_verified_output]], [[feedback_writing_chosen_not_chunked]].

**User additions 2026-11-12:** states («حالات»: a posture/act scene — standing on the bridge, prostrating to him, lying on the ground raising hands) are ledger rows (kind state) each needing a scene picture, generation allowed; at most ONE scraps and ONE torn per minute (writing_place enforces); cutting as it used to be — every throat-clear/sneeze/sigh/door/click removed, words cut whole: audio_gate now fails on undecided «review» sounds (.tmp/<p>/noise_ok.json) and on joins inside speech (join_word_scan.py).

**User clarifications 2026-11-12:** generated pictures are FOR states (e.g. a man making du'a) when a real photo is hard to find, never for real-shaped things; no curtain at isolation, curtain only at transitions; a real picture keeps its true ratio and only our frame is added.
