---
name: pixabay-broll
description: Free stock B-roll (video and photos) via Pixabay API; where the key lives and how to use the tool
metadata:
  node_type: memory
  type: reference
  originSessionId: c9666df7-21d7-4935-af8a-de1661df3587
  modified: 2026-10-14T10:36:41.454Z
---

Free stock B-roll comes from Pixabay. The API key is in `S:\AI_Tools\Remotion_Workspace\.env` as `PIXABAY_API_KEY` (git-ignored). Never print or repeat the key in a reply.

Tool: `node tools/fetch_broll.mjs search "<query>" --type video|photo [--sheet out/sheet.html]` and `get <id>`. Downloads go to `public/stock/`, logged in `sources.json`.

Rules: show candidates first and wait for approval before `get`. Inspect every file at full resolution for women (forbidden). Blur faces for general subjects (see [[preferences-file]]). Videos stay silent, with no music. Pixabay results are patchy for religious and niche topics, so verify relevance.

**تحديث 2026-10-21:** مهارة `pixabay-search` + أداة `tools/pixabay_multi.mjs` (بحث متعدد الاستعلامات، `--must`، حذف المكرر والنساء والمولَّد، لوحة معاينة PNG). لا توجد مهارة عامة جاهزة لـPixabay (بُحث ولم تُجد). واجهة الفيديو لم تعد تعطي `picture_id`؛ المصغّرات من `videos.medium.thumbnail` (أُصلح في `fetch_broll.mjs` أيضاً).
