---
name: reference-remotion-official-skills-stills-speed
description: "2026-10-22: official remotion-dev/skills (repo version 4.0.538, installed Remotion 4.0.535) copied into .claude/skills (11 skills; their remotion-render NOT installed — name clash with ours, its tips merged into ours); preview stills sped up: shared browser in tools/stills.mjs, parallel measured slower"
metadata:
  type: reference
---

طلب المستخدم: ثبّت مهارات Remotion الرسمية وحسّن سرعة صور المعاينة. نُسخت من clone للمستودع (`scratch/ext_repos/remotion-skills`، مراجعة 6c67adc) إلى `.claude/skills`: best-practices وcaptions وcreate وdocs وinteractivity وmaps وmarkup وmultimedia وsaas وstudio وupgrade (لم يُنفَّذ `npx skills add`؛ كانت نسخها موجودة في `.agents/skills` ومسجَّلة في `skills-lock.json` ولم أمسّها). **مهارتهم `remotion-render` لم تُثبَّت** لأن اسمها يطابق مهارتنا؛ دمجتُ نصائحها (`render --frames=0,30,90` بنداء واحد) في مهارتنا.

**السرعة:** `tools/stills.mjs` (الذي طوّره غيري: حزمة مخزَّنة + أصول بروابط صلبة بدل نسخ public كله) أضفتُ إليه **متصفحاً واحداً مشتركاً** لكل اللقطات بدل إطلاق متصفح لكل لقطة: 6 لقطات **15 ← 9.7 ثانية** (مقاس على Lamp-Demo). **التوازي أبطأ**: 3 عمّال 12–13ث مقابل 9.4–9.7ث بعامل واحد، فالافتراضي `--jobs 1`. لقطة واحدة ≈ 3ث كلها. لا ثبت تطابق بايتي بين الطريقتين (فرق بكسلي صغير محتمل من فك الفيديو؛ لم أقس PSNR بنجاح).
