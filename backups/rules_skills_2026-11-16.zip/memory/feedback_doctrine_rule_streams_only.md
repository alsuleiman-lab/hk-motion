---
name: feedback-doctrine-rule-streams-only
description: "the «caller's doctrine in title and cover» rule (2026-11-05) applies to streams only, not to explainer/answer videos"
metadata:
  node_type: memory
  type: feedback
  originSessionId: ef9ee0b9-d7b5-4beb-81f6-359245969b3e
  modified: 2026-11-05T13:05:27.625Z
---

When I asked which title to use (the rule says title and cover must name the caller's doctrine, here «ملحد»), the user answered «هذه القاعدة للبثوث فقط» and kept «كيف يحمي التمر من السموم؟».

**Why:** the doctrine-in-title order concerns live-stream/debate videos with a caller; an explainer answering a clip does not need it.
**How to apply:** do not force «ملحد/نصراني…» into titles or ThumbPro words of non-stream videos; no need to ask again. Also: every explainer clip shows its source under it ([[project-poison-explainer-clips]]).
