---
name: apply-rules-before-user-asks
description: The user had to prompt every missing element in the zaynab_shrine montage; sweep the rule files against the transcript BEFORE building and run the render with the cached bundle
metadata:
  node_type: memory
  type: feedback
  originSessionId: 834fa5b6-7544-4851-b9c3-52d754a763cd
  modified: 2026-10-29T19:14:11.725Z
---

In the zaynab_shrine montage (2026-10-29) the user had to point out, one by one, things the rule files already required: a map for every journey / two countries, the timeline element for history, `episode_ref` for «في حلقة سابقة», TornNote for key phrases, trusted-outlet news shown with its headline, every important word written, pictures with true proportions, the colour code (brand tokens only), and `RENDER_CACHED=1` for chunked renders (the full public/ copy cost ~15 min).

**Why:** the user ended up angry about repeated misses and delay ("لماذا من أول الجلسة وأنت تنسى التعليمات").

**How to apply:** before the plan stage, walk the whole cut transcript sentence by sentence against MONTAGE_BRIEF.md / PREFERENCES.md / the element gallery and write a table «الجملة ← العنصر المطلوب» (places and journeys → paper map with the camel/car, history → TimelineTravel, news → trusted outlet headline clipping, previous episode → episode_ref, important claims → TornNote, lists → PanelToCanvas with ticks, two ayat never in one card, every picture in its real aspect); only then build. For renders: `render_chunked` now defaults to the cached bundle; do not re-run the whole `stage check` after small edits (use edit_block / face_fast on the span). See [[reference-preferences-file]] [[feedback-edit-is-one-block]].
