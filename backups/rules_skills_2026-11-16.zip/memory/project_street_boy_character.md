---
name: project-street-boy-character
description: "ولد صايع" added as 7th cast member (id boy-street) to both Abu Khatt (family_stick) and Dodo rigs, expression 'smirk'
metadata:
  type: project
---

On 2026-11-09 the user asked for a «ولد صايع» (street-smart kid) character in both the Abu Khatt family (`cartoon_projects/family_stick/rig.ts`) and the Dodo family (`cartoon_projects/dodo_family/rig.ts`). Id `boy-street`, cast index 6: sideways red cap with star, sage-green hoodie (strings, pocket), gold chain, sleepy lids + one raised brow, lopsided smirk, toothpick. New `Expression` value `'smirk'` (default for him). Heights: .84 stick / .88 Dodo.

**Why:** the user wants a rowdy/cheeky kid type for stories alongside the existing six family members.

**How to apply:** use `cast.find(c=>c.id==='boy-street')`; the Cast comps are now 3×3 grids (hidden in Studio by [[feedback-reference-comps-hidden-in-studio]]). Preview without Studio: transpile the rigs like `cartoon_projects/dodo_family/verify.mjs` and convert the SVG with Inkscape. `python3` here is a stub; use node scripts for file edits.
