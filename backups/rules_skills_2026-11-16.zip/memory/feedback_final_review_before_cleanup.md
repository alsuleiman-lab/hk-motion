---
name: feedback-final-review-before-cleanup
description: the approval cleanup (montage_guard end + clean_temp) erases .tmp/gates/<project>.* so the Stop hook blocks «انتهيتُ»; announce done only while the gate files exist
metadata:
  node_type: memory
  type: feedback
  originSessionId: f3cde5e1-d3eb-4c09-be71-9a5dae9b84b6
  modified: 2026-11-02T18:17:38.225Z
---

On approval, cleanup of the project deletes its audio_gate/map files and `.tmp/gates/<project>.final.ok`; after that `final_review` cannot be rerun (audio gate stale, duration 0) and the Stop hook blocks any «✅ انتهيتُ» message. (2026-11-02, adam_dodo.)

**Why:** the hook needs a fresh `.final.ok`; faking it is forbidden.

**How to apply:** write the «✅ انتهيتُ» message with the link BEFORE asking «هل تعتمده؟», right after `final_review` passes. After approval, do the cleanup and reply briefly WITHOUT the phrase «انتهيتُ من المونتاج». Also check the delivered file name in `جاهز` before cleanup (a rename by another process was seen). Related: [[feedback-original-voice-no-light-change]].
