---
name: formats-and-rules-lint
description: Three formats (landscape / full portrait / reel, spec kind) and tools/rules_lint.mjs against stale instructions; per-project temp deleted on approval (2026-10-29)
metadata:
  type: project
---

From the 2026-10-29 audit (report artifact https://claude.ai/artifact/2E6wGTFvxsqxZkPnRMHEzx):
- **Formats:** عرضي (16:9 full), طولي كامل (9:16 full, same timeline), ريلز (9:16 excerpt ≤ 3 min, story first, hook 10–15 s). First questions = three clicks: title, B-roll (= added video clips only), «الصيغ» multi-select. Paper collages, images and elements are always made, never asked. Spec `kind: "reel"`; coverage_check rejects a reel > 3 min.
- **Stale rules:** `node tools/rules_lint.mjs` (in stage check and rules_audit) fails on missing tools, cancelled elements, replaced wordings (REPLACED list inside it), expired «حتى DATE» rules. When a rule is replaced, add its old wording to REPLACED in the same turn. Replaced lines are kept in scratch/rules_removed_2026-10-29.md (the hidden archive is write-denied to me).
- **Temp:** each project's temp in `.tmp/<p>/`; `montage_guard end` → `clean_temp.mjs --approval --project <p>` deletes it entirely; leaked `run_*` dirs older than a day are purged.
- **Git:** the damaged 36 GB workspace .git was deleted; `.git` is now a gitfile → S:/AI_Tools/Remotion_Workspace_backup.git (media excluded in its info/exclude).

**Why:** the user suffered from old instructions being followed and from reels/portrait confusion. **How to apply:** see [[rules-location]], [[cancelled-means-deleted]].
