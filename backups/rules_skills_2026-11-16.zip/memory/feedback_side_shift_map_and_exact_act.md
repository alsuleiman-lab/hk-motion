---
name: feedback-side-shift-map-and-exact-act
description: Centred subject behind him → shift him right (dx 420); map country beside him not behind his head; footage must show the exact act said (2026-11-11)
metadata:
  type: feedback
---
From «سانت رامبال» review: (1) the god in the glass cabin was in the middle behind him → «اجعل الفيديو تبعي على جنب»; (2) the map showed no India (atlas had only the Arab region) and Haryana sat behind his head — said twice; (3) the intro showed hand-kissing while he said feet-kissing.

**Why:** what stands behind him must be seen; a map must show the named country; footage must illustrate the words literally.

**How to apply:** behind windows with a centred subject → [{only:"land",dx:420},{only:"port"}], subject composed on the left; pmap landCenter puts the country on the free side (coverage_check fails a point behind his head); atlas now has South/Central Asia (src/asiaMap.ts) — add other regions from Natural Earth before use; look at every clip and match the act word for word, men only. Related: [[feedback_two_countries_map_nasrallah_x_missing_pictures]], [[feedback_done_means_verified_output]].

**Default since 2026-11-11 (later the same day):** EVERY background window (video or picture) puts him on the right (dx 420) with the subject composed on the left — «ضع صورتي على جنب ليظهر الفيديو بشكل كامل». Also: orphan_scan.mjs lists cut fragments / trailing-off speech (said three times) — cut them with cut_block.mjs at the measured silence before any link.
