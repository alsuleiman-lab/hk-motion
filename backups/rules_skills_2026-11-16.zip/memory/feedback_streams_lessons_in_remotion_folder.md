---
name: feedback-streams-lessons-in-remotion-folder
description: "stream and lesson compositions always go inside <Folder> (Streams / Lessons) in src/Root.tsx, never in the main list (2026-11-08)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 19435a74-d517-459c-9572-b7693d09ee81
  modified: 2026-11-08T21:46:55.835Z
---

All stream clips go in `<Folder name="Streams">`, lesson clips in `<Folder name="Lessons">` in src/Root.tsx; folder names must be Latin (Remotion restriction).

**Why:** user order 2026-11-08 («اجعل دائما مقاطع البثوث داخل مجلد في ريموشن يعني ليست في القائمة الأصلية»); the main Studio list was crowded.

**How to apply:** when registering any new stream/lesson composition, place it inside the matching Folder. Rule also in skill lessons-and-streams §0 item 7. Related: [[feedback_streams_never_stop_queue_workflow]].
