---
name: feedback-render-bumper-env-and-judder-windows
description: "render_project.sh puts a RANDOM bumper at second 0; a spec montage needs BUMPER_AT/BUMPER_ID from spec.bumper and judder windows only where he is not shifted (2026-11-14, nvidia_crash)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: fd2920fb-ec4e-4124-a043-1aa05617f019
  modified: 2026-11-14T18:29:15.132Z
---

User 2026-11-14 (angry, repeated): the opening bumper must be before «بسم الله», never at the start and never random; he should not have to remind me each video.

**Why:** `tools/gpu/render_project.sh` does not pass `BUMPER_AT`/`BUMPER_ID`, so `gpu_render` prepends a random bumper at 0; and its judder windows sit where he is shifted aside (half-screen elements), so 10 windows read ~49 % agree (false FAIL) while a free window reads 100 %. Also rebuilding the spec from the build script erased `spec.bumper` (add `bumper_at.mjs --write` as the LAST pipeline step), and `stills` previews never show the bumper (Studio only).

**How to apply:**
- Render with my own script: `export BUMPER_AT=<spec.bumper.at> BUMPER_ID=<spec.bumper.id>` then `gpu_render.mjs --comp … --procs 1 --windows 3 --name <p>`; keep a copy of `.tmp/bumper_orig/<comp>.mp4` BEFORE the next render; judder_check on the pre-bumper copy with `--at <free second> --len 90` in spans with no shifted/half-screen item, no zoom/shake/map/verse/note.
- `render_project.sh` deletes the pre-bumper copy and `rm`s `.tmp/gates/<p>.bumper.json` per orientation: gates are per project, so run `final_review` for an orientation right after its own render. Never hand-write a gate file (the classifier blocks it as undermining oversight); to recreate a gate re-run `prepend_bumper.mjs` on the pre-bumper copy.
- Kill orphans of a killed script: the child `gpu_render` keeps the lock (find its PID in `.tmp/render.lock`).
- Don't say «بناء الملف» to the user; small corrections only (spec_block apply).
