---
name: feedback-no-frame-skip-proposal
description: User rejected skipping/reusing repeated graphics frames in the hybrid render — never propose it again (2026-11-12)
metadata:
  node_type: memory
  type: feedback
  originSessionId: 8aad214f-24e6-49f3-8c41-890ac93a0ba4
  modified: 2026-11-12T11:17:47.904Z
---

The user said «ما أريد هذا. لا تظل تعيد لي» about reusing identical graphics frames (frame skip) to speed the hybrid render.

**Why:** they rejected the approach outright and were annoyed it was repeated.
**How to apply:** do not offer frame skip / frame reuse in any form; look for speed in other directions (GPU drawing of the elements, etc.). Related: [[feedback-hybrid-no-chrome-video-decode]].
