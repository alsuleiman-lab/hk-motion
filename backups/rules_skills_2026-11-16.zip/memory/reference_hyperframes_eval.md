---
name: reference-hyperframes-eval
description: HyperFrames (HeyGen HTML→video) installed and benchmarked vs Remotion on 2026-11-09; where the test lives and the verdict
metadata:
  type: reference
---

Test folder `S:\AI_Tools\HyperFrames_Test` (hf-test = HyperFrames 0.9.25, rm-test = same scene in Remotion 4.0.538 via node_modules junction). Same 10s 1080p30 Arabic scene (blur-in title, counter, moving dot, glass card).

Results: HyperFrames CPU 87s / `--gpu` 68s; Remotion CPU 62s / NVENC+concurrency 3 38s. SSIM between outputs 0.95; HyperFrames ignored system font "Segoe UI" (only Google Fonts injected, cached on C:), Remotion used it.

**Why:** user asked to try and compare (2026-11-09). **How to apply:** no reason to switch; HyperFrames would only matter for GSAP-authored HTML scenes. Our hybrid render [[project_hybrid_render_adopted]] stays.

**Deleted 2026-11-09 at the user's order** (test folder, its skills in ~/.claude/.agents/.gemini, C: font/Chrome cache). The folder path above no longer exists; do not reinstall.
