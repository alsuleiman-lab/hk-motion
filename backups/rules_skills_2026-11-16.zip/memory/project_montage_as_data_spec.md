---
name: montage-as-data-spec
description: "Portrait montages can be written as data/specs/<id>.json rendered by src/MontageSpec.tsx over shared kit elements (MG.tsx, PortraitKit.tsx) — user's «write once, edit once» idea, 2026-10-26"
metadata:
  node_type: memory
  type: project
  originSessionId: 7f584406-3221-4cc2-8971-86400a5f9aad
  modified: 2026-10-27T07:35:01.765Z
---

The user asked (2026-10-26) to stop re-writing element code per video: put each element once in the library and make videos reference it, like PHP includes (edit once → everything follows).

Built that day: shared helpers promoted into `src/PortraitKit.tsx` (`PORTRAIT` layout constants, `CreditLine`, `CropCard`, `Marker`, `PopCard`, `FullImage`); `src/MontageSpec.tsx` (`MontageFromSpec` + `SpecItem` types); `data/specs/demo.json` + composition `Spec-Demo`; `tools/gen_quickref.mjs` now catalogues MG.tsx + PortraitKit.tsx; `tools/lib/cached_bundle.mjs` links assets named in specs; proposal in `rules_registry/proposals/2026-10-26_montage_as_data.md` (rules not yet edited — owner/user approval needed).

**Adopted 2026-10-26 (user said yes):** rules written into PREFERENCES.md §6 first bullet, MONTAGE_BRIEF.md §6, video-montage/workflow-plan.md step 5; proposal archived in the hidden archive S:\AI_Tools\_remotion_rules_archive (never read). Cover is now a spec item `{t:"cover", palette, kit}` (CoverKit, first 3 frames; palettes by name in `COVER_PALETTES`). Cut/transcript stages still outside the spec.

**Landscape added 2026-10-27 (user: «اعمل للعرضي»):** one spec, two compositions (`Spec-Demo`, `Spec-Demo-L`); `MontageFromSpec` picks layout by composition width; `LANDSCAPE` constants + orientation-aware `CreditLine` in PortraitKit; item `land` override / `only`; new items `rows` (Banner+StatRow column) and `scholar` (ScholarPolaroid). Landscape: word/blur→KeyChip y756, cards in left column x40 w600, scholar right. NOT built: `phone` in landscape, the polaroid pair «his video + clip he answers» (needs audio decision), landscape hook.

**Why:** every video re-wrote the same ad-hoc pieces (CropCard, Marker, PopCard, FullImage were lost when BaVideo.tsx was deleted on approval).

**How to apply:** for the next portrait montage prefer a spec JSON; add a missing element type once in the kit + one `case` in MontageSpec; regenerate the catalogue. Cover, cut and transcript stages are still outside the spec. Related: [[montage-skill]], [[mg-catalog]].
