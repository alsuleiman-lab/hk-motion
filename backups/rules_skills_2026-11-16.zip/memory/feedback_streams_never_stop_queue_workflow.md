---
name: feedback-streams-never-stop-queue-workflow
description: "streams/lessons run as one continuous queue until everything (render, move, Drive upload, trash, guard end) is done; don't end the turn between items (2026-11-08)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 19435a74-d517-459c-9572-b7693d09ee81
  modified: 2026-11-08T18:55:51.287Z
---

For streams and lessons, build a resumable queue (`tools/stream_queue.mjs` + `data/stream_queue/<name>.json`) and keep working until ALL stages finish; never stop to report between clips.

**Why:** on 2026-11-08 I kept ending turns after each batch, so the user saw idle gaps («المفترض ألا تتوقف حتى تنتهي من كل شيء»).

**How to apply:** queue runs in background; meanwhile do Drive upload prep; after QUEUE_DONE continue to upload→verify→trash→guard end, one final report. Rule is in skill lessons-and-streams §0 item 7. Related: [[feedback_streams_cut_fully_plus_reels]], [[feedback_render_progress_visible_in_claude]].
