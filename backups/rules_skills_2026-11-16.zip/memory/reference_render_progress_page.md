---
name: reference-render-progress-page
description: Live render progress bar page — tools/render_progress.mjs on port 3105 (browser pane or LAN)
metadata:
  type: reference
---

`node tools/render_progress.mjs` (background) serves http://localhost:3105 / http://<LAN IP>:3105: one bar per `render_work/progress_chunked_*.log` (measured `[جزء i/n] p%`, DONE = 100%, elapsed + ETA, stalled after 5 min). Probe renders are hidden. Requested by the user 2026-10-31 («شريط عداد للرندر»); open it in the Browser pane with `preview_start {url}` whenever a final render starts and send the LAN link.

**How to apply:** start the server before/with every final render and give the user the link; Janib cards (tools/monitor.mjs) stay as they are.
