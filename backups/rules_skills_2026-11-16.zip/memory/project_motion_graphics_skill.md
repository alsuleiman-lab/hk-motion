---
name: project-motion-graphics-skill
description: motion-graphics skill (2026-10-18): editor-desk language learned from a reference video; src/MG.tsx primitives, MotionLab, tools/mg_analyze.mjs
metadata:
  type: project
---

Skill `.claude/skills/motion-graphics/`, primitives `src/MG.tsx` (+ MotionKit.tsx icons), practice comp `MotionLab`, analyzer `tools/mg_analyze.mjs`. Reference: Egyptian creator video "مونتاج الدحيح في كلود". Not yet used in a real video or rendered.

**Why:** user asked to study a reference video frame by frame and build a motion-graphics skill.
**How to apply:** use for explanatory graphics; keep face/timing/transition rules. See [[project-silent-reaction-skill]].
