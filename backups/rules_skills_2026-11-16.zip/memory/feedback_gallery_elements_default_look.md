---
name: gallery-elements-default-look
description: Use only gallery-approved elements in their default look; never restyle (size/colour) one so it no longer matches the gallery
metadata:
  type: feedback
---

On 2026-10-30 the user asked «هذه الكتابة غير موجودة في المعرض فلماذا أتيت بها؟» about a reel line I drew with `blur` (BlurRise) at size 56 and plain white, instead of the gallery look (Zain 100 with black stroke) or the KeyChip used for every other line.

**Why:** a gallery element with changed size/colour is a different element to him; the gallery is the only source of looks (see [[project_brand_identity]] and the retired-elements list).
**How to apply:** pick the element by its gallery name; keep its default size/style; change only text/timing/position inside its zone. For a hook line use `word` (KeyChip). If a need has no gallery element (e.g. a pinned numbered list), say so before building and ask, don't improvise a variant.
