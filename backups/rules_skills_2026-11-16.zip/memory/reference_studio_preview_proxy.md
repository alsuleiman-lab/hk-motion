---
name: reference-studio-preview-proxy
description: Studio stutters/audio cuts on heavy cuts → permanent fix: src/studioProxy.ts swaps light _prev copies for every video/audio element in Studio; stage check auto-builds them; renders keep full files
metadata:
  type: reference
---

Studio played the full 1.7 GB 16 Mbps cut several times at once and `<Audio>` read the same mp4 → choppy picture and audio (2026-11-09, gaza_floods). The user ordered it permanent («بدي التعديلات دائمة، ما بدي تقطيع في المستقبل»).

**How to apply:** `src/studioProxy.ts` (imported in `src/index.ts`) patches `HTMLMediaElement.src` / `setAttribute` in Studio only (never when `isRendering`) → any `<video>/<audio>` whose file is in `data/preview_proxies.json` ({rel: version}) plays `<name>_prev_<v>.mp4` / `.m4a` (version = source mtime, so a rebuilt proxy is a new URL — an in-place rebuild once left the user's tab silent, 2026-11-09). `node tools/make_preview_proxy.mjs --auto <project>` builds them (>100 MB, skips `_src`/`_cut`, refreshes when the source is newer); `stage.mjs check` runs it automatically; run it by hand before sending a Studio link for a new cut. Rule written in PREFERENCES.md (§ comps naming line) + MONTAGE_BRIEF.md. Related: [[project_gaza_floods_video]].
