---
name: style-references
description: STYLE_REFERENCES.md holds studied reference videos (e.g. عبدالله الشريف ولاد حابي) and how to adapt them to the user's constraints
metadata:
  type: reference
---

`S:\AI_Tools\Remotion_Workspace\STYLE_REFERENCES.md` records the editing style of reference videos the user asked me to study (first one: عبدالله الشريف, ولاد حابي, episode 28). It lists measured facts (a hard cut about every 9 s) and visual observations (hanging wooden photo boards, dark arrow keyword tags, date badges, cartoon stickers, themed virtual sets), then which parts fit the user's rules (no women, no music, no black, face never covered).

**How to apply:** read it when choosing a design, and apply the constraints in [[preferences-file]] first. Add new references there.
