---
name: reference-broll-lib-distorters
description: "User's own B-roll folder public/broll_lib/religion_distorters (3 images): B-roll/source images (no isolation since 2026-10-27) when he speaks of the campaign to demolish religion / distorters / deniers of Sunnah; alternate between them"
metadata:
  type: reference
---

(2026-10-21) الصور: `distorters_1` (لافتة «تكوين لتغيير صحيح الدين»)، `distorters_2`، `distorters_podcast`؛ وجوه النساء مطموسة أصلاً. تُستعمل خلفية (بالتبديل لا الثلاث معاً) عند «الحملة لهدم الدين» و«الذين يحرّفون/يبدّلون الدين/ينكرون السنة»، وبدل المخطوطة في أول المقدمة. طُبّقت في فيديو اليهودية (`src/YhScenes.tsx` `BG_SCHEDULE`: dist1 في أول المقدمة، dist2 ثم distPod عند «الحملة لتغيير أحكام الدين»). النسخة السابقة من الملف: `scratch/YhScenes.before_distorters.txt`.
