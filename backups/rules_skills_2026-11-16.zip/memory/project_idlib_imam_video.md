---
name: project-idlib-imam-video
description: "«إدلب» (عزل إمام مسجد في سوريا لأنه تكلم عن هموم الشعب): approved + published + purged 2026-11-15; lessons only remain"
metadata:
  node_type: memory
  type: project
  originSessionId: c6ff7eea-afb3-4289-b29b-b076c4771fc1
  modified: 2026-11-15T17:43:40.403Z
---

Approved and published 2026-11-15: landscape → YouTube main channel (public, video id 5JvcWTTP53g, end screen + card for «ماهر الهندي شيخ أم شبيح» at 9:31, title ends `#سوريا #محمد_بن_شمس_الدين`), portrait → Drive «انستا وفيس» (folder 1tjE5DVDGULTwc0US-6lXWid0PdDpv_-b, size verified), landscape → ok.ru published. Code/spec/package deleted by `montage_guard end`; rendered files + source recycled. Commit 43c1e17.

**Lessons (also in MONTAGE_BRIEF «الرندر الأسود» and critical-rules):**
- A Root.tsx wrapper with an opaque backgroundColor (colour-grade wrapper) blacked out the whole GPU render, then only split-screen spans (layers `below`): background must be undefined in HY modes top/below/under, and no CSS filter when neutral.
- Always render one mid-video frame and one frame inside the first split-screen, LOOK at them, and scan the output for dark spans before saying «rendered».
- Another session rendering on the GPU fills VRAM (decode errors, «no painted frame» timeouts): wait until no other gpu_render runs (twice in a row); electron_worker paint wait raised to 60 s.
- judder_check with a fixed face crop fails on videos where every second has an element/split (no free span): look at frames, do not let it block a publish the user ordered.
- ok.ru upload can stall at a % (resume loop): open a NEW tab, re-attach the same file — it resumes from the server's partial. Drive/ok.ru/YouTube uploads at once share upstream (≈25 min each).
- guard `end` can leave a broken Root.tsx when a custom wrapper component was added by hand: delete the leftovers manually, tsc, re-run guard.
- Frame numbers the user sent mid-task were for another session: ask-by-message when unsure whose they are.
