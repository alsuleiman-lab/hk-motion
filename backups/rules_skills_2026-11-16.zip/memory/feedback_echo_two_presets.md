---
name: echo-two-presets
description: Echo/reverb requests → apply preset 2 (cathedral) or 6 (warm deep) automatically via tools/echo_audio.py; no re-testing
metadata:
  type: feedback
---

When the user asks for an echo/reverb on audio, apply one of two approved presets automatically: **2 كاتدرائية مهيبة** (adhan / solemn) or **6 دافئ عميق** (default otherwise). Run `python -I tools/echo_audio.py <in> <out.mp3> --style 2|6`.

**Why:** On 2026-10-28 I made 10 reverb styles on an adhan clip; the user picked 2 and 6 and said never to test again.
**How to apply:** Don't offer a style menu or ask which; tail must decay to silence then fade (never cut abruptly). Rule also in PREFERENCES.md section 3.
