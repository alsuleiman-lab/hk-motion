---
name: feedback-no-captions-ever
description: "STRICT (2026-11-16): never add his-speech captions to any video; the word-by-word pill caption was removed everywhere"
metadata:
  node_type: memory
  type: feedback
---

User order 2026-11-16: «الكابشن سيء جداً، أزله من كل الفيديوهات، كلماته غير دقيقة ليست كما أقول، ولا تضع الكابشن مرة أخرى».
- Removed: `src/Captions.tsx` (PillCaptions), `tools/captions_fill.mjs`, spec field `captions` (7 specs), gallery entry, pick_triggers check, rule lines in PREFERENCES/MONTAGE_BRIEF.
- Cartoon keeps its own caption (from its written script, not transcription) — untouched.

**Why:** transcription-based words were inaccurate, not what he said.

**How to apply:** never build, fill or propose a speech caption for talking videos; portrait elements live in PORT_ZONE (y 1400–1880) with nothing above them for a caption. Supersedes the 2026-11-15 caption order.

Related: [[feedback-portrait-bands]].
