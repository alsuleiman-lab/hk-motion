---
name: feedback-youtube-publish-routine
description: "every video gets a YouTube package (data/youtube/<p>.md); landscape → «الردود العلمية» scheduled with ads, suitability always «لا شيء مما سبق» without asking; portrait → Drive انستا وفيس; all → ok.ru (2026-11-13)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 8aad214f-24e6-49f3-8c41-890ac93a0ba4
  modified: 2026-11-13T07:57:02.956Z
---

User 2026-11-13: «اعتباراً من الآن المقاطع اللي تعملها… تكتب لها فصول ووصف يوتيوب»، ثم ارفع العرضي على «الردود العلمية» مجدولاً مع الإعلانات «وحط كل شيء»، والطولي على درايف «انستا وفيس/جاهز طويل انستا وفيس»، والكل على أوك. وعن استبيان «الملاءمة للإعلانات»: «دائماً لا شيء مما سبق، لا تحتاج أن تسأل».

**Why:** he wants each finished video ready to publish without extra questions.

**How to apply:**
- Package `data/youtube/<p>.md` (title, description, chapters at final-file times after the 5 s bumper shift, tags) written with the build (rule in PREFERENCES §2 / MONTAGE_BRIEF §7).
- «الردود العلمية لمحمد بن شمس الدين» = Google account mshmsdin5@gmail.com → open `https://studio.youtube.com/?authuser=3` (UCiu_Wwm_NCows_g4TEPA8Dg); the channel switcher on youtube.com does not change Studio.
- Upload: `python tools/stream/upload_server.py 8791 "<جاهز>"`, inject a button that `window.open`s `http://127.0.0.1:8791/up.html` (a real click), postMessage `{cmd:'send',names:[file]}` → File; patch `HTMLInputElement.prototype.click`, click «تحميل فيديوهات» then `#select-files-button`.
- Fill: title/description via execCommand insertText per line; thumbnail 1280×720 JPG (<2 MB) via file_upload on the dialog's file input; «ليس للأطفال»; AI disclosure «لا»; tags — the channel adds ~15 default tags, trim defaults from the end to ≤480 chars keeping the video's own.
- Monetization: «تفعيل» → «تم»; suitability: tick «لا شيء ممّا سبق» then «إرسال التقييم» (no asking); end screen template «فيديو واحد، اشتراك واحد»; schedule date via the calendar (typing the date fails), time typed «4:00 م», zone GMT+1 auto.
- Collaborator ALWAYS (user 2026-11-13): on each الردود العلمية video → «عرض المزيد» → «دعوة متعاون» → search @MShmsDin → «إنشاء رابط» → close the share box → dialog «حفظ»; then accept as the main channel: `https://studio.youtube.com/channel/UCNQR1yu8BLrSihTabql3rVQ/videos/upload?d=acd&v=<videoId>&inviterChannelId=UCiu_Wwm_NCows_g4TEPA8Dg&authuser=1` → «قبول» (retry if «حدث خطأ»), verify «متعاون نشط» via «إدارة المتعاونين». I accept it MYSELF and do NOT send him the invite link (user 2026-11-13: «طالما تقبلها ما يلزم ترسل لي الرابط، تصرّف من عندك»; he had thought I couldn't accept).
Related: [[reference_youtube_upload_via_chrome_and_wording]], [[reference_drive_upload_via_chrome]], [[feedback_streams_lessons_upload_drive_and_okru]].
- Previous clips he mentions («تكلمت في مقطع سابق عن كذا», data/episode_refs/<p>.json) → a YouTube CARD at that moment of the final file (+5 s bumper shift) AND the link in the description («مقاطع ذُكرت في الفيديو»); package section «# البطاقات» (user 2026-11-13).
- YouTube Studio links (invite links etc.) always in a copyable code block, one per block (user 2026-11-13).

- Which channel (user 2026-11-13, after I published the general-topic Syria video on «الردود العلمية» by assumption): ASK it with the opening questions (4th question «أين يُرفع»: الأساسية @MShmsDin vs الردود العلمية). Default thinking: general topic → الأساسية, reply to someone → الردود العلمية — but never assume. Main channel Studio = `authuser=1` (UCNQR1yu8BLrSihTabql3rVQ). He said «نشر مباشر» → public immediately, not scheduled, when he says so. Classifier blocked my click on «إنشاء رابط» for the collaborator invite (2026-11-13) — do not work around; tell him.

**Update 2026-11-15:** the upload question («أين يُرفع») is asked for the landscape version only; portrait/reels always go to the Drive folder «انستا وفيس» without asking (user: when I tick portrait it asks again where to upload). Merged into the rule files the same turn.
