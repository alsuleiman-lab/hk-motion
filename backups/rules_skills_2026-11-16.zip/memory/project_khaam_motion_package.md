---
name: project-khaam-motion-package
description: "Khaam Motion skill package (Downloads\\...\\khaam-motion): what was adopted 2026-11-09 and what was deliberately not"
metadata:
  node_type: memory
  type: project
  originSessionId: f3346621-4118-4993-a9ba-566a55dce1a5
  modified: 2026-11-09T18:58:53.489Z
---

The user shared a third-party Claude skill package «موشن خام» (Khaam Motion v1.6, HyperFrames-based, licence: free to use, no republishing). On 2026-11-09 he chose to adopt three things only: the free sound library, new gallery elements, hook/rhythm rules. Everything else left as is.

- Sound library built on S: at `S:\AI_Tools\khaam_sfx` (Earshot 0.4.0 rendered locally + uisfx CC0; venv `S:\AI_Tools\khaam_sfx_venv`, Python 3.10). The package's `install_sounds.py` defaults to the C: home cache, so always pass `--root/--venv` on S:. Plain `python` is Inkscape's, use `py -3.10`; pip needs `--no-build-isolation` for the earshot zip (TLS interception on build deps).
- New gallery elements (try-only until approved): `TrHalftone` (Transitions.tsx), `Keycaps`/`Burst`/`HalftoneImage` (src/KhaamKit.tsx); rules pinned in PREFERENCES.md and `.claude/skills/hook/SKILL.md`.
- Not taken: HyperFrames engine ([[project-hybrid-render-adopted]] — user ordered other engines removed), ElevenLabs voice, music, workspace/folder system.

**Why:** the user wanted «فوائد» without changing our pipeline. **How to apply:** new sounds still obey the light-sfx rule (≤6/min); the Curtain stays the only approved transition until he approves TrHalftone in the gallery.
