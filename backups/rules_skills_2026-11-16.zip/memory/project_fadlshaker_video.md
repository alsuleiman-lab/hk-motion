---
name: project-fadlshaker-video
description: "«فضل شاكر: الحقيقة كاملة» landscape-only montage (2026-11-10) — in-recording orders, cut-gate lessons, tools added"
metadata:
  node_type: memory
  type: project
  originSessionId: b5ff9b15-7354-4b98-ac3c-e2b1c730e1f0
  modified: 2026-11-10T12:58:02.384Z
---

Project id `FadlShaker`, composition `FadlShaker-L`, spec built by `.tmp/FadlShaker/build_spec.mjs` (+ `post_build.sh` keeps mattes). Source 37 min → 19:30 cut. User left home and said finish it as best I can; answers: title «فضل شاكر: الحقيقة كاملة», B-roll yes, formats عرضي only.

**In-recording orders (montage_notes 1–8):** comments of the Aseer episode (none real exist → I refused to fabricate; card only), Syrian-protest clip behind him, Jeddah singing clip behind him muted, replay of the «سبب التحول» clip, hide the two name-only clips, keep the Al-Jadeed clip whole, sheikh-in-mosque pictures, ending = hold 1 s → horror + slow-mo → CRT off (new `tvoff` item in GazaFx/MontageSpec, tail built into `FadlShaker_cutx_s.mp4`).

**Why:** the stage cut gate (0 pauses > 0.40 s) and `onset_check` (no clipped onsets) fight each other on hard-onset words; fixing by `--rem` ranges aligned to the 1/30 s grid, cut in true silence (< −41 dB), ≥0.07 s before the onset. Only the user-ordered silent clip is exempt through `--keep`; `audio_gate.mjs` now clamps keep-span edges (Edit 2026-11-10).

**How to apply:** for a hard-to-cut pause, compute the quiet frames of `.tmp/<p>/cut.wav`, remove just enough, grid-align, re-run `stage.mjs cut`; never exempt pauses on my own. See [[feedback_cover_via_chatgpt]] (cover downloaded via in-page fetch→anchor download because the arrow button did not save).
