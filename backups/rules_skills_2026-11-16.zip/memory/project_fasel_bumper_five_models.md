---
name: project-fasel-bumper-five-models
description: 5-s paper bumper «كتبي وقنواتي» — five radical paper models built 2026-11-11, awaiting user's pick + render permission
metadata:
  type: project
---

خمسة فواصل (5ث، عرضي) في `src/FaselModels.tsx` + `src/FaselKit.tsx`: Fasel-Wall / -Notebook / -Tear / -Shelf / -Press (عناوين Studio «فاصل ١…٥»). أصولها في `public/fasel/` (books/، tex/، sfx/، شعارات القنوات). التصدير المتفق عليه: `G:\ملفاتي\فواصل`، صوت ورق خفيف، عرضي فقط.

**Why:** المستخدم رفض أول فاصل («لا يظهر أنه ورقي، أصوات سيئة ومتكررة، الخلفية سادة، كتب أكثر، عبارات») وطلب 5 نماذج مختلفة جذرياً بعد مراجعة المهارات والفيديو المرجعي.
**How to apply:** بعد اختيار المستخدم نموذجاً: رندر بإذنه فقط؛ احذف الباقي عند الاعتماد. See [[reference_paper_desk_style_omar]] and [[project_paper_montage_skill]].
