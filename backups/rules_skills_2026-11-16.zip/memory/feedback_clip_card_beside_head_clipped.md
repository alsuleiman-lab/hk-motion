---
name: clip-card-beside-head-clipped
description: "Reel clip card sits BESIDE the head (not above), edges clipped off-frame left and tucked behind head/shoulder right; measure once"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 7f584406-3221-4cc2-8971-86400a5f9aad
  modified: 2026-11-02T11:16:18.134Z
---

Reel replied-to clip card: place it beside his head at ear/chin level (`card {left -50, top 600, rot -4, innerH 240}` in the 1080×1920 reel), never above the head. Its left edges go off the frame edge (negative left) and its right edge hides ~40px behind head/beard/shoulder via the matte window; the caption under it stays readable.

**Why:** user (2026-11-02) said twice that the card's edges must disappear (some outside the frame, some behind the shoulder) and asked why I don't measure once and be done.
**How to apply:** set the card once from this measurement, render one still, eyeball, done — don't iterate positions. See [[feedback-reel-text-pictures-sources]] and [[feedback-matte-windows-clean]].
