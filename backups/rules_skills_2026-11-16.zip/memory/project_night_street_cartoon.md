---
name: night-street-cartoon-approved
description: «ليلة الشارع» cartoon approved 2026-11-11; everything built was deleted at the user's order and the lessons live in the cartoon skill
metadata:
  type: project
---

Rendered (hybrid route) and approved 2026-11-11: `C:\Users\mshms\Videos\جاهز\ليلة الشارع.mp4` (Abu Khatt, handheld camera, original audio uncut, 63.8 s, 1080×1920, judder gate passed with `--animation`). User order «اعتمد واحذف الكل وأبق ما تعلمتَه»: composition, kit code (Acting/Spatial, FilmKit additions), pose tools and venv, the downloaded Stickman repo, the source mp4 (Recycle Bin) were ALL deleted; the knowledge stays in `.claude/skills/cartoon-animation/references/action-contracts.md` (method, rig facts, bike/strike/lying formulas, tolerances, experiments cancelled, research findings) and the «قواعد الفعل» section of the skill.

**Why:** the user wants one approved film and a clean tree; learnings are the asset.
**How to apply:** for a new filmed-video cartoon rebuild the contract system from the reference doc (do not look for deleted files); final-review ✘ items accepted last time: audio_gate (cut pipeline, N/A) and two silences kept on the user's order «لا تقطع السكتات». See [[feedback_do_not_change_approved_cast_look]], [[feedback_study_source_video_before_cartoon]], [[reference_pose_capture_rtmlib]].
