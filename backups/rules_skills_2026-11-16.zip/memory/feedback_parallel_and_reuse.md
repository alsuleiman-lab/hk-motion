---
name: feedback-parallel-and-reuse
description: Run independent checks together, reuse mattes/images, never a full rebuild for a local fix — the user asked twice why it is slow (2026-11-11)
metadata:
  type: feedback
---
User (2026-11-11): «هل أنت تعمل بالطريقة اللي علمتك إياها، تشغل أكثر من شغلة بنفس الوقت؟… طولت».

**Why:** I ran finalize → mattes → proxy → full check one after another, and every rebuild dropped the matte fields so all 12 windows were re-matted (~10 min a round). After the fix: rebuild 11 s, all checks in parallel 11 s.

**How to apply:** launch verse_audit, requirements --check, coverage_check, writing_sync, mg_usage_audit (on the spec json), grid_plan land/port, spec_normalize --dry together (one shell, `&` + `wait`); matte_windows now reuses existing `mt/w_<from>_<to>.mp4`; keep manual spec decisions in the build script (tools rewrite the spec). See [[feedback_edit_is_one_block]], [[feedback_questions_first_and_background_work]].
