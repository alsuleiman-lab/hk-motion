---
name: channel-thumbnail-style
description: Sheikh's channel thumbnail style analysed from 30 thumbnails; skill + reference sheets live in .claude/skills/thumbnail-design
metadata:
  type: reference
---

youtube.com/@MShmsDin thumbnails: Sheikh cut-out on the right, opposing speaker/topic scene on the left, cinematic warm golden background from the topic, 2-5 word bold Kufi headline (gold/white + red subline bar), question hooks. Analysis + 3 reference sheets saved in `.claude/skills/thumbnail-design/` (SKILL.md section "أسلوب قناة الشيخ"). Open conflict: channel thumbnails use dark warm backgrounds vs the "no dark backgrounds" rule (video scenes) — awaiting user decision. See [[feedback-backgrounds-current]].
