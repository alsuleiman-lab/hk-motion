---
name: project-five-reels-hybrid-port
description: Five reels (Jafri, English proverb, Atfal, Azka, Qiss) approved 2026-11-11; hybrid render now supports portrait splits/card/psplits/hclip; final steps and what stays in the kit
metadata:
  type: project
---

Approved and cleaned 2026-11-11 (exports in جاهز; originals recycled; compositions/specs/titles removed).

**Kept in the kit:** `src/MontageSpec.tsx` hybrid port (CropPolaroid via VSlot drawn as a frame, PortPanel transparent, hclip via VSlot in GazaFx, portrait splits/psplits allowed in HY), `reelCardSchema/withCard/ReelFromSpec` (manual card placement from Studio props), `tools/grid_plan.mjs` `faceTol`, `tools/cut_safe_rem.py` first-segment onset fix. Rules: critical-rules 76–80 + MONTAGE_BRIEF §9.

**Final steps that worked:** extract JPEG frames of cut_s and matte (`public/fr/<name>/`, pad 10 frames) → `hybrid_any.mjs --comp <Id> --fr <cut>,<matte> --out …` one reel at a time (≈4–6 min each) → `judder_check` with face crop (windows away from zooms; low-motion windows can fail on noise, check frame series by hand) → `final_review --name` (user-ordered long silence: `--max-gap`) → user approval → `montage_guard end` + remove comps/titles/specs.

**Why:** the user ordered «دائماً مختلط» when the hybrid refused portrait specs; he also said «معاشةً» vs «معاشاً» is an ASR error, not his reading.
**How to apply:** see [[feedback_reel_always_card_grid_lessons]] and [[project_reel_card_manual_placement]]; hybrid history in [[project_hybrid_render_adopted]].
