---
name: feedback-matte-windows-clean
description: "Background isolation must look clean — use tools/matte_windows.mjs (raw RVM 0.25 + curve per window) and eyeball a frame; matte_cache's default clean-up cut him into blocks"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 2e63e4d2-4ae8-45ff-93ce-d349ea248930
  modified: 2026-10-31T21:20:04.758Z
---

Isolation (matte) for B-roll behind him / maps: `node tools/matte_windows.mjs data/specs/<p>.json` — per `behind`/`mini` window, raw RVM `--no-clean --ratio 0.25` + a curve (alpha <0.45→0, >0.8→1). Look at one frame of each window before showing the preview.

**Why:** 2026-10-31 (Halloween video) the whole-video `matte_cache` matte with its default clean-up (face-column/row-run heuristics for another framing) produced rectangular blocks over his robe and beard; the user was furious («هذا يسمى عزل خلفية؟»). It also took 31 min vs ~5 min for 23 windows.
**How to apply:** never ship a matte without viewing it composited; never rely on matte_cache's CLEAN for this studio framing. Related: [[feedback_no_background_isolation]].
