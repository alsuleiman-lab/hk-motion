---
name: feedback-never-fill-disk-s
description: S: filled up repeatedly (frame extraction + 1.6 GB per-still temp folders); user is angry — measure free space before big writes, keep ≥25 GB, never delete others' files without asking
metadata:
  type: feedback
---

2026-11-09 (Gaza floods): I extracted 25k frames + grid_sheet stills (each still left a ~1.6 GB remotion-assets folder until exit = 58 GB) and S: hit 0 bytes, breaking stage check twice; the user: «مليون مرة قلت لك لا تفعل ذلك، ولا تزال تفعل نفس الخطأ» — answer was «ملء القرص S».

**Why:** a full S: kills renders/stills for every session and corrupts files being written.
**How to apply:** `df -h /s` before any big write (frames, stills, downloads, renders) and estimate the size; keep free ≥ 25 GB; stills.mjs now deletes per-still assets and refuses under 15 GB; free only my own temp first, ask by click before deleting anything of another session. Rule in PREFERENCES القرص + MONTAGE_BRIEF. Related: [[feedback-cleanup-deletes-idle-project-files]].
