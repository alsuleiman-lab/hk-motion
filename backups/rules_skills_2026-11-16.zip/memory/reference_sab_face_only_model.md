---
name: reference-sab-face-only-model
description: "Reference «سب الدين أسهل كفر» (face-only portrait, 58s): CornerTags, NeonWord keyword with glitch swap, BrushX, HeatFlash topic-change transition; built into src/MG.tsx and tested on real footage"
metadata:
  type: reference
---

نموذج المستخدم (2026-10-21) لمونتاج الوجه الواحد الطولي: وسما زاويتين دائمان، كلمة موضوع نيون حمراء سفلية تتبدل بتشويش إلى الحكم، شطب فرشاة حمراء، وهج انتقال حار عند تغيير الموضوع مع تقريب، استعارة بصرية سفلية، آية كلمة بكلمة، وختام = الغلاف. بُني: `HeatFlash`/`NeonWord`/`BrushX`/`CornerTags` في `src/MG.tsx` وتجربتها `Sab-Demo` (تسجيل حقيقي، نجح face_check في 7 لقطات بعد نقل النيون إلى y≥1500). التفاصيل والضوابط في مهارة motion-graphics القسم 20. لا يُنقل منه: كابتشن مستمر، ولا شطب على الوجه. انظر [[feedback-use-new-motion-kit-mandatory]].
