---
name: feedback-no-windows-or-browser-popups
description: "Never let a console window flash or a ComfyUI browser tab open while working: tools/env.sh preloads hide_windows.mjs (windowsHide for all Node children); ComfyUI starts with --disable-auto-launch and NOT detached"
metadata:
  type: feedback
---

شكوى المستخدم (2026-10-22): أثناء المونتاج الورقي تفتح الطرفية 4 مرات وتختفي، ويُفتح له تبويب ComfyUI في المتصفح؛ لا يريد أن يرى شيئاً لأنه يعمل على الجهاز بأشياء أخرى.

**الأسباب:** (1) `spawnSync`/`spawn` لـffmpeg وpython وtaskkill بلا `windowsHide`؛ (2) ComfyUI يفتح المتصفح افتراضياً ما لم يُمرَّر `--disable-auto-launch`؛ (3) `detached: true` على ويندوز مع Windows Terminal يُظهر نافذة `python.exe` رغم `windowsHide`.

**الحل المُجرَّب:** `tools/hide_windows.mjs` يُحمَّل عبر `NODE_OPTIONS` من `tools/env.sh` (كل أمر عمل يبدأ بـ`source tools/env.sh`)، و`comfy_still.mjs` بـ`--disable-auto-launch` وبلا `detached`؛ راقبتُ النوافذ أثناء توليد حقيقي فلم تظهر نافذة ولا تبويب. **How to apply:** لا تشغّل أي أداة Node دون `source tools/env.sh`؛ لأي عملية ثقيلة جديدة استعمل `windowsHide: true` وبلا `detached`، وأطلق التطبيقات بعلم تعطيل فتح المتصفح؛ وتحقق بمراقبة `MainWindowHandle` للعمليات. انظر [[feedback-heavy-tools-hidden-background-and-closed]].
