---
name: session-errors-log
description: Pointer to the errors-and-workarounds log (ffmpeg long select, python -, Root.tsx edits, Studio stale) kept in WORKFLOW_CHECKLIST.md section و
metadata:
  type: reference
---

Errors from the Musk-video session and their fixes are in WORKFLOW_CHECKLIST.md section «و». Add new ones there. Also: verify a preview link in the browser before sending it, and send a one-line status when anything is slow. See [[reference-technical-lessons]].
