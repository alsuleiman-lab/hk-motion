---
name: stream-cut-by-call-and-user-pictures
description: streams are cut by context — one phone call = one whole clip, written question from reading to answer; sheikh cover pictures only from public/cov/sheikh_poses; output to جاهز\بثوث (2026-11-11, user very angry)
metadata:
  type: feedback
---

The user rejected and deleted the whole qa2 delivery: «تقطيعك غلط… الكلام يبدأ من نصف المداخلة… المكالمة واحدة قطعتها مدري كم مرة». The 22-minute Shia call had been split into 4 clips (q2_06–09), a Christian caller's clip started mid-call, one girl's call was split into two, one answer was split into two clips. He also said I ignore his folder of isolated PNG pictures (`public/cov/sheikh_poses` = S:\AI_Tools\covers\sheikh_poses) and use my own pictures, and that the streams output folder is `C:\Users\mshms\Videos\جاهز\بثوث\{طولي,عرضي}` — I had used جاهز\طولي\مباشر.

**Why:** I segmented from a plan written by topic keywords instead of reading the speaker-labelled transcript; old wording (sheikh_gallery, مباشر folders) stayed in skills and won over newer rules.

**How to apply:** PREFERENCES «منع تكرار فشل البثوث» items 10–11, lessons-and-streams step 0; rules_lint now blocks the old wording. Read `.tmp/<p>_turns.txt`-style speaker turns of the whole stream first, write a segment table with start/end sentences and speakers, then cut. Related: [[stream-failure-study-2026-11-11]], [[cover-photos-poses-folder-and-title-only]].
