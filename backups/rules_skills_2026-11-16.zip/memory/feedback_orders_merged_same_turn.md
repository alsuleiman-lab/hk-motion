---
name: feedback-orders-merged-same-turn
description: Every order of the user is merged into the binding rule files in the same turn; rules_pending.mjs blocks montage while a draft/proposal is unmerged (2026-11-12)
metadata:
  type: feedback
---
The user found his instructions "disappearing": decisions written as rules_registry drafts/proposals were never merged into PREFERENCES.md / MONTAGE_BRIEF.md / skills (the only files read before a video), so I asked him again about the Companions' pictures.

**Why:** a rule that is not in the binding files does not exist for the next session.
**How to apply:** merge his order immediately (PREFERENCES + BRIEF + skill), mark the proposal «مدمج <date> في …»; conflicts with a newer rule → ask by click. `node tools/rules_pending.mjs` must print ✔ before any stage. Supersedes [[rule-files-via-proposal]] and [[rules-owner-session-proposals]].

**Second lesson (same day):** my first audit read only the first lines of each proposal and marked files «merged» — rule 4 of the Nawawi file (split-screen pictures go in the GAP between the clip card and his card, never over the clip) was missed and the user caught it again. An audit reads EVERY item of every file; the item-by-item log is rules_registry/audit_2026-11-12.md. Also: a tool I add (gallery_geometry) must respect every existing placement rule (split windows), not override it.
