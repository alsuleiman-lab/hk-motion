---
name: one-write-per-file
description: "All corrections of a turn go in ONE approval: list them all, then apply every file change in a single node script (one Bash call), never Edit by Edit"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 92bce295-3f54-410d-8fa5-ee0eb73ecb97
  modified: 2026-11-10T09:55:16.576Z
---

The guard hook asks the user before every edit to a rule, skill or tool file. Many small Edits = many approval prompts, and he hates it.

**Why:** «لا تطلب صلاحية لكل سطر، خذ صلاحية كاملة» (2026-10-25), and again 2026-10-29: «لما تكتب التصحيحات وتطلب مني الإذن اكتبها كلها مرة واطلب إذن واحد… كل شوي أوافق» — I had made ~25 separate Edits across PREFERENCES, the brief, skills and tools.

Repeated 2026-11-10 («اعمل كل التعديلات مرة واحدة واطلب مني مرة واحدة أن أوافق عليها») after I made six separate Edits to the cartoon skill.

**How to apply:** first investigate and decide every change (read only). Then write ONE scratchpad node script that applies all replacements across all files (rule files + skills + tools) and fails loudly if a target string is missing; run it in a single Bash call = one approval. State the full list of changes in that same message. Keep rule text free of dates and story ([[preferences-file]]).
