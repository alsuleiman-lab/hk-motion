---
name: preferences-file
description: "Video rules live in MONTAGE_BRIEF.md (read first) and PREFERENCES.md (full, grep it); per-rule memories were archived because they duplicated these files"
metadata:
  node_type: memory
  type: reference
  originSessionId: 92bce295-3f54-410d-8fa5-ee0eb73ecb97
  modified: 2026-10-25T16:46:53.845Z
---

Before any video work read `S:\AI_Tools\Remotion_Workspace\MONTAGE_BRIEF.md` (binding summary); grep `PREFERENCES.md` for a specific rule; `WORKFLOW_CHECKLIST.md` at the final review. Stages run as one command each: `tools/stage.mjs prep|cut|check`.

**Why:** reading the 88 KB PREFERENCES.md + checklist + skills in full (~60k tokens carried through every call) made a 2-minute reel take 2 hours. The ~130 per-rule memories that repeated these files were moved to `S:\AI_Tools\Remotion_Backups\memory_archive_2026-10-25\` (still readable there).

**How to apply:** a new preference goes into PREFERENCES.md (or a proposal), then into the brief, then `node tools/brief_check.mjs --stamp`; do not write a new memory for a video rule. Rule text says what to do, without dates or the story behind it. Related: [[one-write-per-file]].

**Main folder only (2026-10-27):** sessions run in git worktrees whose copies can be older than master; read every rule/skill file from `S:/AI_Tools/Remotion_Workspace/...` (the guard hook denies reading worktree copies), run tools from there, and merge any rule edit made in a worktree into master in the same turn.
