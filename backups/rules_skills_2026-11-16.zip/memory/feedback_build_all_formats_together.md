---
name: feedback-build-all-formats-together
description: "Landscape and portrait (and reel) are built in ONE pass on one spec, each element placed at its gallery position per orientation at the same moment; reel is always portrait 9:16; render stays sequential"
metadata:
  node_type: memory
  type: feedback
  originSessionId: aeb26639-f5c9-4e60-b9d9-804d2691fa9e
  modified: 2026-11-16T10:08:16.595Z
---

2026-11-16 user order: «ريل = طولي دائماً»، ومن الغلط أن أبني العرضي ثم أبني الطولي: أبنيهما معاً لأن الكود نفسه والموضع نفسه، وعندي كود الطولي وكود العرضي في المعرض فأضع هذا وهذا في اللحظة نفسها.

**Why:** the two-pass order (landscape first, then redo portrait) wasted time; the gallery already has both placements per element.
**How to apply:** one spec per video holds both orientations (`only` / `land` overrides); place each item for both at once, run the grid/gallery checks for both in the same command; the reel (kind reel) is its own portrait 9:16 spec built in the same pass. Only the final render stays sequential (landscape then portrait). Rules updated in MONTAGE_BRIEF, PREFERENCES §formats, workflow-plan, critical-rules, AGENTS. See [[feedback-clip-edge-measure-and-reel-portrait]].
