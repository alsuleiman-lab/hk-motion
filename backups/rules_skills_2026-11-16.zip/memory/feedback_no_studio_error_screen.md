---
name: feedback-no-studio-error-screen
description: لا تظهر شاشة خطأ Studio للمستخدم؛ الحارس SafeComposition + إصلاح في الخلفية (2026-11-15)
metadata:
  type: feedback
---

المستخدم يشاهد المعاينة على الجوال، وظهر له خطأ Studio الأحمر (`playbackRate` صغير في تجميد الفيديو) فأمر: «أمنع ظهورها، وخلي العلاج والمشاكل في الخلفية».

**Why:** الشاشة الحمراء تقطع مشاهدته وتشغله بأخطاء الأداة.
**How to apply:** `Root.tsx` يستورد `Composition` من `src/SafeComposition.tsx` (حارس يحتوي الخطأ ويعيد المحاولة كل ثانيتين)؛ بعد كل تعديل أفحص الأنواع ولقطات وسجل المتصفح بنفسي؛ تجميد الفيديو بـ`<Freeze frame>` لا `playbackRate` أقل من 0.0625؛ أخطاء أمثلها لا أذكرها له إلا بسطر. متصل بـ[[feedback-fix-failures-never-stop]].
