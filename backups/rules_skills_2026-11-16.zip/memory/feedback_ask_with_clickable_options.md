---
name: feedback_ask_with_clickable_options
description: "Ask the user questions with the clickable-options tool (AskUserQuestion), never as a typed list of questions"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 0497a3b9-f309-451f-91eb-c7f3b5c22a12
  modified: 2026-10-16T18:11:37.806Z
---

Every question to the user — the three pre-video questions (title, landscape/portrait, B-roll) and any choice between alternatives — must be asked with the AskUserQuestion tool so he can click options, not as a written list he must answer in text.

**Why:** user instruction 2026-10-16.
**How to apply:** use AskUserQuestion (1–4 questions, 2–4 options each, recommended option first). Related: [[feedback_work_live_ask_first]].
