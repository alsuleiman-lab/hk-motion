---
name: reference_technical_lessons
description: "Technical lessons from the Tirmidhi and Azerbaijan videos (memory exhaustion, python3, matte path, hybrid geometry, font downloads, bundler gotchas)"
metadata:
  node_type: memory
  type: reference
  originSessionId: 0497a3b9-f309-451f-91eb-c7f3b5c22a12
  modified: 2026-10-16T18:11:37.911Z
---

Full list lives in WORKFLOW_CHECKLIST.md section «دروس تقنية». Key points: Windows virtual-memory exhaustion breaks cutting (close the memory-hungry app); `python3` in bash is a Store stub; run matte_rvm.py from the project root; ExplainerScene card width is 760 not 876 and hybrid output must be parity-checked against Remotion stills; Google-font loading at import time slows every render (archive is lazily required via ArchiveComps); deleting a JSON that any component imports breaks the whole bundle; never kill processes with a pattern that matches your own command; Studio "second repeats" is Studio slowness, not the render.

**Why:** these cost hours; the user asked on 2026-10-16 that they be recorded.
**How to apply:** read the checklist section before any render/cut.

- (2026-10-22) Hibernate after a render batch silently failed: Git Bash rewrote `shutdown.exe /h` into a drive path (`H:/`). Run `shutdown /h` from PowerShell (or `//h`, or `MSYS_NO_PATHCONV=1`) and log its success; same trap for any Windows tool with `/option` flags (powercfg, robocopy…).

- (2026-10-22) «الفيديو يرتجف»: the Sheikh's screen recordings contain irregular duplicate frames (30 fps container over a slower capture) → judder in every montage. Fix = `tools/smooth_dups.py` (blend neighbours of each duplicate) before building, measure with `.tmp/judder.py`, and render with OffthreadVideo (`RV` in PortraitKit). Also: after any ffmpeg `scale` that changes the aspect add `setsar=1` (Chrome honours SAR → stretched/cropped faces), and PhoneChips needs `notch={false}` (it covered the clip speaker's forehead).

- (2026-11-09 gaza_floods) `grid_plan` reserves every slot time with a ±0.15 s margin: two items of the writing slot need ≥ 0.15 s between them (the first minute needs ≤ 0.3 s: use 0.2), a subscribe/name-tag hole swallows the items that START inside it, hook `iso` windows accept only key kinds (no photo/verse: write the verse as scraps), new element types must be added to `data/layout_grids.json` kinds. `writing_sync --fix` moves `at` later than the first scraps word (re-set at = times[0] only if the sync check allows). Verse cards in portrait full mode: x 40, w 1000, size 30, y 1440 (beard reaches y≈1415). Whisper-large dialect words («ليش») must stay as spoken in scraps or `scraps_times` fails to match. cut_edl needs free disk (S: hit 0 B once during another session's render: wait, don't delete other projects' files); `words_cut_large.py` needs `torch/lib` on PATH (not python -I).
