---
name: export-name-landscape-dash
description: "Export file names — portrait is the plain title, landscape is the title with \"-\" appended"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 834fa5b6-7544-4851-b9c3-52d754a763cd
  modified: 2026-10-29T18:57:47.374Z
---

Name the exported files `<العنوان>.mp4` for portrait and `<العنوان>-.mp4` for landscape (a trailing "-"), both directly in `C:\Users\mshms\Videos\جاهز` with no subfolders.

**Why:** the two orientations share one title; the user wanted a short fixed rule to tell them apart (2026-10-29, zaynab_shrine).

**How to apply:** pass `--title "<العنوان>-"` to render_chunked for the landscape composition; for a render already started under the plain title, rename the exported file afterwards. Written into PREFERENCES.md and MONTAGE_BRIEF.md §7. See [[reference-preferences-file]].

**Update 2026-11-03:** every regular (non-cartoon) video file name ends with ` #محمد_بن_شمس_الدين` (space before it) so the user need not type it when uploading: portrait/reel `<العنوان> #محمد_بن_شمس_الدين.mp4`, landscape `<العنوان> #محمد_بن_شمس_الدين-.mp4` (the dash stays last). Cartoons get no tag. Pass the full string as `--title`/`--out` to render_chunked.
