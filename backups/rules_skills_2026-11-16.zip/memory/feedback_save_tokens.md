---
name: save-tokens
description: User asked (2026-10-19) to reduce token consumption: shorter replies, fewer/lighter file and image reads, no repeated long explanations
metadata:
  type: feedback
---

خفّف استهلاك التوكنز: ردود أقصر (الخلاصة أولاً)، لا أعيد قراءة ملف قرأتُه ولا أقرأ الملفات الكبيرة كاملة (أستعمل offset/limit أو Grep)، لقطات الفحص بحجم صغير وعددها أقل (شبكة واحدة مصغّرة بدل عدة)، لا أكرّر الجداول والشروح الطويلة، وأجمع الأوامر المتعاقبة في استدعاء واحد.

**Why:** طلب المستخدم 2026-10-19 أثناء جلسة طويلة بلغت مئات الآلاف من التوكنز.

**How to apply:** قبل أي قراءة: هل أحتاجها فعلاً؟ بعد كل إنجاز سطران لا صفحة؛ وأكتب مرة واحدة ما يمكن كتابته مرة واحدة (ملف واحد مجمَّع بدل تعديلات كثيرة). مرتبط: [[feedback_plain_language]].
