---
name: feedback-reference-comps-hidden-in-studio
description: "reference/library/demo/trial compositions must not show in Studio's list; flag SHOW_REFERENCE in src/archive.ts (false by default)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: f3cde5e1-d3eb-4c09-be71-9a5dae9b84b6
  modified: 2026-11-08T21:36:33.869Z
---

Everything that is reference material (character-library casts FamilyStickCast/DodoFamilyCast, the whole `Demos` folder incl. ElementsLab, KhAlphaTrial) is hidden from Remotion Studio's sidebar. (2026-11-08, user's screenshot of the two cast entries: «كل شيء مرجعي يجب أن يكون مخفي».)

**Why:** the sidebar should list only active projects; reference items clutter it.

**How to apply:** `SHOW_REFERENCE=false` in `src/archive.ts` gates them in `src/Root.tsx`. Flip to true only to work on them (e.g. `node tools/stills.mjs ElementsLab …` for tools/elements_page.mjs), then back to false. Any NEW reference/demo/trial composition goes behind the same flag. The Hybrid* comps in the `hybrid-hidden` folder stay registered because tools/hybrid_render.mjs needs them. Same idea as SHOW_ARCHIVE. Related: [[feedback-cancelled-means-deleted]].
