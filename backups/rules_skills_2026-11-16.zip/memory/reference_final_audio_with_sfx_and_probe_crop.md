---
name: reference-final-audio-with-sfx-and-probe-crop
description: "render_chunked --audio-file ignores spec sfx, so mix cut audio + spec.sfx into public/<p>_audio.wav first; judder probe needs --crop on the face; hook wants a fresh probe after any src/ edit (2026-11-06)"
metadata:
  node_type: memory
  type: reference
  originSessionId: c55085ef-1d7c-433b-9e41-f4d4c4bacfd1
  modified: 2026-11-06T16:27:17.234Z
---

For spec-based montages the final render uses `--audio-file public/<p>_audio.wav`, which bypasses the `<Audio>` sfx in MontageSpec. Run `node tools/sfx_bind.mjs data/specs/<p>.json` (spec may have no `sfx` yet), then mix: speech ×0.8 + each sfx (trim 1.5 s, `vol`, `adelay`) with ffmpeg amix `normalize=0` (script pattern: `.tmp/masaj_syria/mix_audio.mjs`, deleted with the project).

`judder_probe`/`judder_check` fail on whole frames with moving overlays: pass `--crop` (+ `--src-crop`) on his face; portrait crop = face box × 1.78 relative to the cam centre, and `--avoid` zoom/split windows. Any edit in `src/` (even another session's) makes the hook demand a new probe as a separate earlier command. `final_review --name` reads judder.ok by name, so run judder_check for each orientation with the same `--name` right before its review.

**Why:** hit all of this finishing «مساج رباعي؟!» renders.
**How to apply:** before the final render of any spec montage. See [[feedback_judder_probe_before_full_render]].
