---
name: feedback-multi-video-order-all-in-parallel
description: "When the user orders N videos in one message, launch all N in parallel at once (forks per project) and never stop or report with only the first finished"
metadata:
  node_type: memory
  type: feedback
  originSessionId: aeb26639-f5c9-4e60-b9d9-804d2691fa9e
  modified: 2026-11-16T10:31:48.315Z
---

2026-11-16: the user ordered four videos; I polished the first one through many correction rounds, left the other three only cut, and reported with one link and a one-minute reel. He asked «لماذا أخطأت ولم تنفذ أوامري».

**Why:** I treated the four as a queue (finish the first perfectly, then the next) and let a gate failure (hadra cut) or a long correction round on video 1 consume the whole session instead of working the rest at the same time.
**How to apply:** one message ordering several videos = start every project at once (one fork per project, each owning its own spec/Root lines), keep working while any is unfinished, report only when all are done or truly blocked (name the blocker), and never say a deliverable is done when it is one of N. Reel = portrait; build formats together ([[feedback-build-all-formats-together]]).
