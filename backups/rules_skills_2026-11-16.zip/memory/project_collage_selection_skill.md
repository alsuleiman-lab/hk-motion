---
name: project-collage-selection-skill
description: "collage-selection skill (2026-10-22): I choose which sentences get paper collages, the metaphor, colours and timing myself with NO approval gates; show the decision in the plan + preview; log every user correction in the skill's table"
metadata:
  type: project
---

أمر المستخدم: «أنت تختار بنفسك، أنشئ مهارة خاصة بالاختيار وطوّرها كلما أمرتك بالتعديل». المهارة `.claude/skills/collage-selection/SKILL.md` فيها: معيار الجمل (فكرة مجردة/حدث بحركة، بلا شخص/كتاب/بلد/خبر مصوَّر، ≥3ث، استعارة لم تُستعمل)، جدول الاستعارات (معتمدة ومقترحة غير مجرَّبة)، القرارات الفنية، وسجل تصحيحات المستخدم. `collage-broll-local` لم تعد تفرض بوابات إلا عند طلب قصاصة مستقلة بالاسم. **عند أي تصحيح من المستخدم:** أنفّذ ثم أضيف سطراً في سجل التصحيحات وأحدّث الجدول. انظر [[feedback-paper-motion-for-events]] و[[project-paper-montage-skill]].
