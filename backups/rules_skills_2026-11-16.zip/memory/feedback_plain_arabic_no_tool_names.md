---
name: plain-arabic-no-tool-names
description: never show the user English tool/command/file names or ask him to run anything; speak plain Arabic about results only (2026-11-11, strict)
metadata:
  type: feedback
---

The user snapped at replies full of tool names and commands («مدري ايش قبله وبعده… ما افهمها وما اريدها… كلمة رن ما اريدها اد ما اريدها، ممنوع منعاً باتاً»).

**Why:** he is not technical and does not want implementation detail; he wants outcomes in words he understands.

**How to apply:** in every reply to him: plain Arabic, short; say what was done, what was not, and one question if needed. No tool or script names, no commands, no file paths, no English words, never the word «رن»/run, never ask him to run something. Technical names live only in rule files, skills and memory. See also [[arabic-short-and-fix-into-skill]].
