---
name: feedback-hadith-notecard-gallery-only
description: "Hadith = the gallery NoteCard (spec type \"note\"), never a full-screen box or anything of mine; use only gallery elements unless explicitly ordered (2026-11-10)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: b5ff9b15-7354-4b98-ac3c-e2b1c730e1f0
  modified: 2026-11-10T13:32:50.404Z
---

User (mid-turn, FadlShaker video): «بالنسبة للحديث النبوي عندنا بطاقة خاصة بالحديث، لا تستعمل شيء من عندك إلا بأمر صريح؛ إن لم آمرك اذهب إلى المعرض واستعمل العناصر الموجودة».

**Why:** I had used the `hadith` full-screen box with the sheikh's own paraphrase; the gallery note for NoteCard says «كل حديث يُروى» (card from the first word, verified matn + book + number).

**How to apply:** every narrated hadith → `{t:"note", at, until, title: verified matn, tag: "الكتاب (الرقم)"}`; verify with shamela (`search_hadith`, numbers only if seen in a takhrij footnote). Anything not in `data/gallery_notes.json`/gallery → ask first (exception: effects the user orders inside the recording, e.g. `tvoff`). Cover for a person-topic video must also include that person's photos (user 2026-11-10: religious photo → arrow → singing photo, via Google Images/SerpAPI, then ChatGPT). See [[project_fadlshaker_video]] [[feedback_cover_via_chatgpt]].
