---
name: project-paper-montage-skill
description: «مونتاج ورقي» = skill paper-montage (audio-only + animated paper collage, portrait, faceless silhouettes)
metadata:
  type: project
---

عندما يقول المستخدم «مونتاج ورقي» أنفّذ المهارة `.claude/skills/paper-montage/SKILL.md` (القالب `template.tsx.txt`). أُنشئت 2026-10-22 بعد فيديو «لا نقاش بين مقلد ومستدل».

**Why:** طلب المستخدم أن تُفهم العبارة وحدها دون شرح.
**How to apply:** اقرأ المهارة أولاً؛ طولي فقط، صوت فقط، قص السكتات، ظلال بلا وجوه. See [[feedback_ai_images_faceless_and_cut_silences]].
