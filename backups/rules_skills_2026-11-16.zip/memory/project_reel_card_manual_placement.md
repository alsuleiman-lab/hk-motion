---
name: project-reel-card-manual-placement
description: Reels' replied-to clip card is editable by hand in Studio props panel (cardLeft/cardTop/cardRot/cardH → defaultProps in src/ReelsComps.tsx); card default top 330 = beside the head (2026-11-11)
metadata:
  type: project
---

User asked (2026-11-11) to be able to move the displayed clip in reels by hand. Done: `reelCardSchema` + `withCard` + `ReelFromSpec` in src/MontageSpec.tsx; each reel Composition in src/ReelsComps.tsx has `schema={reelCardSchema} defaultProps={CARD0}` (CARD0 = left −50, top 330, rot −4, H 480). Studio → Props panel edits the numbers; Save rewrites defaultProps; render reads the same defaults.

**Why:** the card at top 600 sat under the shoulder in «المثل الإنجليزي» («متى ستفهم الموضع، جانب الرأس مع اختفاء أطراف الفيديو خلف الرأس والكتف»); with his body shifted right (cams cx−100) top ≈ 330 puts it beside the head with its right edge behind head/shoulder.
**How to apply:** new reels register with the same schema/defaults; pictures in reels are doubled (user: «ولو مست أطراف اللحية») via spec `faceTol` (tools/grid_plan.mjs) — post-step after grid_plan --write. Date mention → `date` element even in half mode (place it manually). See [[feedback_reel_always_card_grid_lessons]].
