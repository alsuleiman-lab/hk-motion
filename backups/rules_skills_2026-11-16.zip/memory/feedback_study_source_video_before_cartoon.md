---
name: study-source-video-before-cartoon
description: "When a cartoon imitates a filmed video, study it second by second, fix who speaks, and animate with key poses before showing anything"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 38e5bbfb-8df1-4424-92aa-dffd550508d6
  modified: 2026-11-10T22:41:50.093Z
---

On «ليلة الشارع» (2026-11-10) I built four cartoon cuts from a 12-frame sheet and guessed the story and the speakers; the user called it trivial and said I used nothing from the new skill, did not know who speaks, and could not do the motorbike or natural motion.

**Why:** the story was different from my guess (B rides off and returns, A is thrown, takes a stone and hits B, child's voice on the phone, apology, verses, B rides away), and library poses (talk/walk/sit) made static, unnatural acting.

**How to apply:** before drawing, make a 1-fps timestamped sheet of the whole source, a per-shot table in `docs/` (who, clothes, speaker, action, camera), and use key-pose acting (`act()` in `src/cartoon/NightStory.tsx`) with anticipation → contact → rebound. Show uncertain speakers/words as estimates. Check motion with a 0.2 s strip, not one still. Never claim a skill was applied unless the frames show it. See [[feedback_one_write_per_file]] for batching rule edits.
