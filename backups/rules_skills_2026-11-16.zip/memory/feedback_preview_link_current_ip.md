---
name: preview-link-current-ip
description: Preview links must use the PC's current LAN IP (it changes), never localhost and never a remembered IP
metadata:
  type: feedback
---

Send Studio links as `http://<current LAN IPv4>:3100/<CompositionId>` (user opens from the phone sometimes). The IP is DHCP and changes: it was 192.168.1.10 on 2026-10-28 and 192.168.1.106 on 2026-10-30 (the old link timed out).

**Why:** a stale IP made the link unreachable from the phone; localhost never works there.
**How to apply:** read the Wi-Fi address right before giving a link (`Get-NetIPAddress -AddressFamily IPv4`, skip 169.* and 127.*), curl it once to confirm 200, then send it. See [[feedback_ask_with_clickable_options]] for the usual closing format.
