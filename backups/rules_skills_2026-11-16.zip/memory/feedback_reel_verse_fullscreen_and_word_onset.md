---
name: feedback-reel-verse-fullscreen-and-word-onset
description: "reels write every recited verse FULL SCREEN (verse full:true); the cut must never clip a word's first syllable (vad_onset_fix); reels need showTitleBar true; writing starts at the first spoken content word"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 7f584406-3221-4cc2-8971-86400a5f9aad
  modified: 2026-11-06T08:40:10.750Z
---

User orders 2026-11-06 on the reel «الإنجيل في مساجد الصوفية؟»:
1. **In reels every verse is full screen** (`{"t":"verse", …, "full":true}` → ReelVerseFull, his picture hidden, word by word). I had used the verse card (the 11-01 rule for speech videos) and he called it a mistake; the card stays only for landscape / full-portrait.
2. **«تتركون» lost its first letters in the AUDIO** (user: «رايح أول حرف»): Silero-VAD started the segment after the word's soft onset and the cut landed inside the word. Fix: `tools/vad_onset_fix.py` (runs inside `stage.mjs cut`, extends starts back while level > −40 dB, ≤ 0.5 s; `vad.raw.json` keeps the original). Re-cut the video after it; all cut-time anchors shift, so regenerate the spec.
3. Other things found the same day: ordinary reels need `"showTitleBar": true` in the spec (default is no bar since lessons/streams), nameTag cannot appear when the clip card covers the whole video (coverage_check), `torn` ≤ 50 % of the writing (rest `scraps`, run `scraps_times.mjs`), writing must start at the first spoken content word (`writing_sync`).
4. Word anchors: large-v3 spells right but inflates the first word of every segment by up to 1 s → `words_cut_large.py` + `merge_words_large.mjs` (aligned times for matching words) make `cut_words.json` the single timeline.

3b. **Covers of replies must show a picture from the replied-to video** (2026-11-06): `duel` cutout of the speaker or `evidence` framed frame of the clip; never a cover with only the sheikh + generated art.

**Why:** he watches the final audio/writing closely and repeats a correction only once.
**How to apply:** after every `stage cut` read the onset-fix line in the log; for reels build verses with `full:true`; run `writing_sync` before `stage check`. See [[feedback-reel-text-pictures-sources]], [[feedback-clip-card-beside-head-clipped]].
