---
name: project-gaza-floods-video
description: "«أين الله من فيضانات غزة؟» (2026-11-09): spec montage with in-recording «مونتاج…انتهى مونتاج» orders, new GazaFx layers (bgclip/hclip/wm/zoomblend/horror), reel from the Abu Dawud hadith"
metadata:
  node_type: memory
  type: project
  originSessionId: b11981ed-fa4d-4649-b06a-09491dcc233b
  modified: 2026-11-09T03:28:42.254Z
---

Project `gaza_floods` (14:13 after cut): source recording had 16 embedded «مونتاج … انتهى مونتاج» blocks (rain-clip background with isolation + faint «يمنع الاقتصاص» watermark, strong zoom/dissolve transition, half-screen clips of Eileen/the doctor/Abdulrahman, horror grade on the opponent's words, deletions). Built as `data/specs/gaza_floods.json` (ids GazaFloods portrait + GazaFloods-L) and `gaza_floods_reel.json` (GazaFloods-Reel, hadith of the station, 2:31).

**Why:** the user's own recorded instructions are the montage brief; the new layers live in `src/GazaFx.tsx` (+ cases in MontageSpec.tsx, kinds in data/layout_grids.json: hclip=source, bgclip/wm/zoomblend/horror=ignore).
**How to apply:** `.tmp/gaza_floods/build_spec.mjs` + `finalize.sh` regenerate the spec (build → writing_sync --fix → scraps_times → sfx_bind → grid_plan --write port & land); `build_reel.mjs` builds the reel from `main_noholes.json` (NOHOLES=1). Hybrid render is NOT possible for this spec (MontageFromSpec throws on behind/portrait/shifts/psplits; fx filters need Remotion) → chunked NVENC render, or hybrid only for ranges without fx.
Related: [[reference_technical_lessons]], [[feedback_cover_via_chatgpt]].
