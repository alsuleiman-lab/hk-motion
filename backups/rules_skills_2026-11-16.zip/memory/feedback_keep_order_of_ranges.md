---
name: feedback-keep-order-of-ranges
description: When the user lists time ranges to keep, the output follows THEIR listed order, not chronological order
metadata:
  type: feedback
---

When the user lists ranges to keep (e.g. «من 3:48 الى 4:05 ثم 8:29 الى 14:18 5:03 الى 8:03 14:30 الى الآخر»), build the cut in exactly that order, even when it is not chronological. I sorted them chronologically once (zaynab_shrines, 2026-10-30) and had to rebuild the cut, spec and renders.

**Why:** the order is part of the user's editing plan; re-sorting changes the story. «أنا اعطيتك ترتيبا معينا لكنك اخللت به».

**How to apply:** write the segment list in the stated order before cutting; check `.tmp/<p>_segments.json` against the message; items derived from an earlier cut must be re-mapped by old time through the segment map (derive/fix pattern), and mattes' `start` follows each window's own `from`, never a hardcoded time. See [[feedback-apply-rules-before-user-asks]].
