---
name: feedback-no-opacity-transitions-gallery-only
description: No opacity/dissolve/flash transitions, nothing outside the gallery; only Curtain/TrSection/PushIn/HandheldShake/slide; new element codes must render (empty box = banned)
metadata:
  type: feedback
---

User (2026-11-09, «نبهتك مراراً»): frame 2389 of the Gaza video showed an opacity fade of a side clip; also an empty small bordered box at frame 5569 (flag code "ps" not drawn by `Flag`).

**Why:** the montage must use only gallery elements/transitions (Curtain, TrSection, PushIn, HandheldShake, the shifts/PortPanel slide); user-ordered dissolves in a recording become the nearest approved transition.
**How to apply:** never use `opacity` ramps for scene/clip hand-over (GazaFx now slides + Curtain); look at one still for every new element type/code before showing (grep spec codes vs the component's supported list). Rule also added to critical-rules.md. Related: [[project_gaza_floods_video]], [[feedback_gallery_elements_default_look]].

**2026-11-11:** no Curtain when an isolation (behind window, moved or not) starts/ends or a bgclip ends — the user: «شيل العزل بشكل عادي»; the engine no longer adds those curtains. Curtains stay for baked splits.
