---
name: four-videos-state-2026-11-16
description: "State of the four speech videos in progress (individual-religiosity landscape done+checked, reel pending; sufi-baath/ahmed-abdo-maher cut only; hadra-khatib not cut) and what blocks each"
metadata:
  node_type: memory
  type: project
  originSessionId: aeb26639-f5c9-4e60-b9d9-804d2691fa9e
  modified: 2026-11-16T01:18:47.550Z
---

2026-11-16 session: user ordered four montages (formats: landscape + full portrait for the three new ones; landscape + reel-from-intro for the first), **no final render, hibernate when I stop**.

- **individual-religiosity** (هل التدين الفردي…): landscape spec `data/specs/individual-religiosity.json`, comp `Individual-Religiosity-L`, `stage.mjs check` PASSED; both covers made in ChatGPT (`public/individual-religiosity/cover_gpt*.png`). Reel from the intro (cut 0–~70 s, kind reel, captions, separate spec) NOT built. Nu'man ibn Qawqal has no calligraphy image (waived in skipRequired). guard plan items p1–p22 not closed with frame evidence. Upload: landscape → الردود العلمية, reel → Drive انستا وفيس.
- **sufi-baath** (title «صوفي يعترف: نعم دعمنا حزب البعث وقدّسنا الشيوخ!», formats landscape+portrait, upload main channel): cut OK (≈6:39, audio clips kept via --keep-sound + `.tmp/<p>/noise_edges_extra.json`), draft spec only; requirements.md lists ~24 pictures/maps (Rajab Deeb, Kuftaro, Sibai, Riyad al-Maliki, Adi ibn Hatim = Companion calligraphy…); 2 in-recording orders registered (picture of Rajab Deeb with audio-clip indicator; remove «مانع روحي» span — my guess drop 524.8–540).
- **ahmed-abdo-maher** (title «لماذا يحقد أحمد عبده ماهر على الصحابة؟», portrait+landscape, upload الردود العلمية): cut OK, draft spec only; 3 orders registered (person picture every mention, famous person picture, pictures for «سرقوا قصوراً»).
- **hadra-khatib** (title «حضرة عبد العزيز الخطيب», upload main channel): NOT cut; 9 in-recording orders registered, several need external clips (Tom&Jerry, Sabah Fakhri, dancer meme) I cannot source; cut fails: shown clip windows contain long no-voice pauses + clicks when --keep-sound whole windows; needs per-window handling.
- User said he has no clips of his own; B-roll answer was a misunderstanding («ما قصدك بمقاطعي؟»): proceed without added clips.

**Why:** the user went to sleep; machine hibernated when I stopped. **How to apply:** resume per project: assets (fetch_images/commons, scholar_images, calligraphy for Companions) → plan → spec → stage check → link; reel for the first video; never render without permission.
