---
name: feedback-render-then-hibernate
description: «render then hibernate» while the user sleeps — queue L then R, check outputs, then hibernate the PC (mandatory, 2026-11-11)
metadata:
  type: feedback
---
User (going to sleep): «بعد الانتهاء من التعديلات قم بالرندرة… حط الفيديوهات في الطابور طولي وعرضي، وبعد انتهاء الرندرة اعمل الجهاز في حالة السبات. هذه التعليمات إلزامية جداً… ما تقصر ولا تنساه».

**Why:** he relies on me to run the computer unattended overnight.

**How to apply:** finish the edits and all gates, close every order with proof, render_queue add L then R (jobs are keyed by project+orientation), run the worker in the background, start the progress page, and run .tmp/hibernate_after_queue.sh (waits for the queue, gives me 20 min to check the exported files — touch .tmp/hibernate_now when done, .tmp/no_hibernate only if something must be re-rendered, then hibernate myself after). Never leave the PC awake. Related: [[feedback_streams_never_stop_queue_workflow]], [[feedback_fix_before_render_use_render_queue]].

**Failed 2026-11-12:** he slept and woke up with the PC still on — the render only started at 07:25 (my pre-render fixes/proofs took hours) and the watcher was armed only when the queue started; the hybrid render then ran at ~2.7 fps (~2.5 h per orientation). Rule now: arm the hibernate watcher in the SAME message he says he is going to sleep; before ANY stop while he sleeps (a question, a blocker, an error I can't fix, work done without a queue) hibernate first (shutdown /h); if pre-render work exceeds ~2 h, hibernate and finish when he wakes. Goal: save electricity.
