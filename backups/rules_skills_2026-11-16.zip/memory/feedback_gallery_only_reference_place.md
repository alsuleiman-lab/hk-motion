---
name: feedback-gallery-only-reference-place
description: Gallery place/size edits must reach real videos — src/galleryPlace.ts TYPE_OF + withGallery; dropped elements deleted (2026-11-10)
metadata:
  node_type: memory
  type: feedback
  originSessionId: f3346621-4118-4993-a9ba-566a55dce1a5
  modified: 2026-11-10T21:16:33.562Z
---

User 2026-11-10: «المعرض هو المرجع الوحيد», «تأكد من دقة المقاسات». Until then the engine never read data/gallery_notes.json, so his drags/resizes never reached videos.

Now: `src/galleryPlace.ts` maps gallery id → spec item type (`TYPE_OF`), and `withGallery` in `MontageFromSpec` adds the gallery dx/dy/k to every item of that type (both orientations); the gallery's own scene sets `galleryOwn` so it is not added twice. `gallery_serve.mjs` normalizes every save (both orientations, whole px, scale 2 decimals; `--normalize` for the file). Proven by stills: gallery scene == real spec render.

**Why:** he edits in the gallery and expects every video to follow. **How to apply:** a new gallery element that is an engine item type goes into TYPE_OF; kit-only elements (PhotoFrame, BrowserFrame, VideoFrame…) have no engine item, so their place can't apply — say so. Elements marked «احذفه» are deleted at once ([[feedback-cancelled-means-deleted]]).

**Root fix 2026-11-11** (user: «حل المشكلة جذرياً»): my build + grid_plan --write gave cards their own x/y/w/h (date w 179 vs gallery 380, no land), so gallery offsets landed on a different base; and the phone preview measured the element on screen and failed. Now: tools/gallery_geometry.mjs --write (last build step; stage check fails otherwise) copies the RealLab sample geometry onto every card (land fully; port x/w/h/size, y follows the beard band); GxLayer scale centre from boxCentre(). Never hand-size a card unless he ordered it (placeOwn).
