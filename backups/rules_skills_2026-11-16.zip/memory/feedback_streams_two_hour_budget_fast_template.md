---
name: feedback-streams-two-hour-budget-fast-template
description: "streams: whole job recording→rendered clips must fit 2 h (user order 2026-11-16); single-pass whole-stream cut, gate per slice, parallel slice/check/queue, auto template from start/end/title/cover (clip_autobuild)"
metadata:
  type: feedback
---

User 2026-11-16 («قم بتطوير برنامج ريموشن ليناسب عملك… التقطيع لا يستغرق أكثر من ساعتين حتى نهاية الرندر»; then chose «ضع لهم نقطة البداية والنهاية لكل مقطع واسماً وغلافاً وهو يقصّ الصوت»).

**Why:** the qe stream (83 min, 30 clips) took 5+ h in cut rounds: audio_gate on the 62-min cut failed → another full cut (2.5 min each ×many), plus a 23-min video build (disk at 98 % because old .tmp/cache/*/cutgroups piled up), research/requirements on the whole stream.

**How to apply:** tools/stream/fast_run.mjs (start/status/slice/checks/queue, budgets cut 8 · words 12 · smooth 15 · slice 12 · build 35 · checks 15 · render 45); cut_smart.sh = SKIP_GATE=1 + STREAM_WHOLE=1, ≤3 rounds; gate runs per slice (clip_slice); cut_edl workers 4; fast_run start purges cutgroups >12 h and wants ≥40 GB free; clip_cut_all --jobs 4; clip_autobuild.mjs builds each clip from plan.json + titles.json (rows/scraps/torn/pick tiling, waivers written in spec). Measured on qe: cut 28 min (budget 8), words 13, slice 20 (qe_12 alone 12 min), build+check ≈ 25. Landscape long clips (>~6 min) and 20–30 s clips still need hand work; mg_usage_audit kind counts are the limit.
