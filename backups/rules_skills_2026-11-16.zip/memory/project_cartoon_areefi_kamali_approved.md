---
name: project-cartoon-areefi-kamali-approved
description: "Al-Areefi Indians story and Al-Kamali Ta'abbata Sharran cartoons approved 2026-11-16, delivered to جاهز\كرتون; user corrected missing speech-matched actions"
metadata:
  type: project
---

Two Abu Khatt cartoons (original voice, digressions cut) approved and copied to `C:\Users\mshms\Videos\جاهز\كرتون` as «العريفي - هنديان أسلما على يد شاب.mp4» (141 s) and «تأبط شرا وأبو كبير الهذلي.mp4» (307 s). Film code, data, titles purged by `montage_guard end`; kit kept: `EnvsGulf`, `EnvsDesert`, `FilmKit` (`contiguous`, `timeMap`, `path`).

**Why it matters:** the user kept finding verbs with no matching motion (sleeping guard during «فطاف ونظر وعس», Indians flipped sideways for «دخل من الشباك», scene in the street instead of the workshop). Lessons are in the cartoon-animation skill section dated 2026-11-16.

**How to apply:** build a sentence → verb → motion → time table before drawing; verify edits applied (the system `python3` is a stub, use `python`); look at stills at action start/mid/end. See [[project-cartoon-gov-mosque-approved]].
