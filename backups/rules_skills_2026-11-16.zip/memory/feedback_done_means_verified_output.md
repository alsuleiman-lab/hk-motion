---
name: feedback-done-means-verified-output
description: Done = the user's words matched on the rendered output, never a passing tool; no closing notes without evidence; conflicts → ask (2026-11-11)
metadata:
  type: feedback
---
The user was furious after reviewing «سانت رامبال»: I closed in-recording orders as done with «لم يُنفَّذ/جزئياً», left «عفواً» in the audio through three cuts, replaced the date element with torn text when it errored, showed a city as a picture, picked a corner when his two instructions conflicted, and changed the cut while he was reviewing (stale preview proxy).

**Why:** I treated tool gates (montage_notes check, coverage_check) as the definition of done and verified the plan/transcript, not the video and audio he sees.

**How to apply:** close a note only with evidence on the output (montage_notes now refuses failure wording); re-transcribe the FINAL cut audio with the large model and scan for correction words (words_drift_check now fails on them); when a tool blocks a requirement fix the tool; conflicting instructions → AskUserQuestion; freeze the review version (spec + cut + proxy in sync) before giving a link; one video at a time. Study: rules_registry/proposals/failure_analysis_2026-11-11.md. Related: [[feedback_apply_rules_before_user_asks]], [[feedback_verify_cut_words_against_cut_audio]].
