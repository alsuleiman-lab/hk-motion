---
name: feedback-streams-cut-fully-plus-reels
description: "a stream must be cut COMPLETELY (every call/segment, landscape >2min or reel ≤2min) AND ALSO get the best-moment reels; never pick only highlights and skip the rest (2026-11-08)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 19435a74-d517-459c-9572-b7693d09ee81
  modified: 2026-11-08T13:07:33.204Z
---

For a stream (بث) the user wants the whole stream cut into clips (every call, nothing skipped), and the إفحام reels are in ADDITION to that, not instead of it. Lessons need reels (3–5 per lesson) — I did 4 for lesson 30 as asked.

**Why:** on 2026-11-08 I cut only ~60% of «بث للحوار مع المخالفين (2)» (selected calls + 8 reels) and told the user the rest was low value; the user rejected that («ما ممنوع هيك تقول لي 40%»).

**How to apply:** build the segment list for the whole stream first (greetings/admin calls included, trimmed of silences), process all of it, never decide for the user that parts are not worth cutting; report coverage honestly. Related: [[feedback_apply_rules_before_user_asks]].
