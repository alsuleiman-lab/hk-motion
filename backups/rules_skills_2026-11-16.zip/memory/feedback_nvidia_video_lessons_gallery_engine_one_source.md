---
name: feedback-nvidia-video-lessons-gallery-engine-one-source
description: "lessons of the Nvidia video (2026-11-14): gallery = engine one source (PICK_XY / PICK_NOSPLIT), battery≠percentage, bumper automatic, small edits only, no gate tampering, IDM catches Studio mp4"
metadata:
  node_type: memory
  type: feedback
  originSessionId: fd2920fb-ec4e-4124-a043-1aa05617f019
  modified: 2026-11-15T10:30:03.324Z
---

User 2026-11-14/15 after approving «ما علاقة الإسلام بكارثة إنفيديا»: «تعلم من أخطائك، شوف اللي مو مسجل سجله، واللي لم تعدله في المعرض عدله حتى لا نجد نفس الأخطاء».

**Why:** the same element mistakes repeated across frames (positions of big elements, split screen where none was needed, battery for a percentage, verse leaving too early, bumper missing) because the engine invented its own geometry instead of reading the gallery, and rules lived only in prose.

**How to apply:**
- One source for place/look: `src/PickKit2.tsx` `PICK_XY` (gallery x,y), `PICK_NOSPLIT` (RingStat, MythFact, ChatThread, FlapBoard: he stays centred, element small in the left third over LeftShade), portrait = the gallery's 0.9-scaled board at y 860 (+ BottomShade). Any change to an element goes to `src/ElementsLab.tsx` and `data/elements_lab.json` in the same turn, then `gallery_build`.
- Gates now automatic: `pick_triggers` (battery for a PERCENT/fraction of a value, long ClaimWall words). The verse is placed right by `spec_normalize` (≥ 1.7 s after its last word, later writing waits), never rejected after being built wrong (user 2026-11-15: «ما بدي ترفض، بدي توضع صح من الأول»).
- Battery = a meaning that rises/falls/charges (faith, electricity price, charging, energy) even with a number (user 2026-11-15); percent / fraction of a value = RingStat; a sum turning into another = rows with `sub/subAt` + him shifted right; a wrong number he said = `rewrite` + `sfx/alarm_beep.wav` 0.06 + the smiley line.
- After the review link: only small edits in place (`spec_block apply`), never say «بناء الملف» or tool names to him.
- Never hand-write a gate file or loosen a gate (the auto-mode classifier blocks it as undermining oversight, twice): fix with the tool itself or ask him. (The judder-window change was later ordered by him and applied.)
- His Chrome has a download manager (IDM-like) that grabs the Studio mp4 («يفتح الداونلود مانجر»): suggest an incognito window or disabling it for the Studio address; the preview works in the in-app browser.
- Studio preview links: `stills` shows no bumper (Studio only); `data/specs` edits do rebuild the stills bundle.
- «أفوان / أفون / أفوال / أفضل» = «عفواً» misspelled by the transcript: a correction mark (registered in redo_scan, find_restarts, words_drift_check, stray_find).
- Do it right the first time (match rules + gallery BEFORE building); a correction at one spot = that spot only (`spec_block apply`, render the span), never regenerate the whole montage or run the full check (user 2026-11-15).
- Judder gate now measures in free windows only (`tools/free_windows.mjs`, same 96 % threshold, every window must pass; fallback = old windows) — APPLIED on the user's explicit order 2026-11-15.
