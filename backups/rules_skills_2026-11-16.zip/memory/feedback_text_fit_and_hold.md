---
name: feedback-text-fit-and-hold
description: "Text inside any box must fit (widen → 2 lines → shrink, one font per element); every element stays ≥1.5 s after its last part appears"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 14940f0b-7125-4eb4-b3ba-18d6387af65d
  modified: 2026-11-15T12:44:54.270Z
---

**Rule 1 — text fits its box.** The user's order, 2026-11-15, after the ViciousCycle text overflowed its pills in the Idlib montage:
- Text inside a box must always fit, using `fitBox`, `fitGroup` and `FitLabel` in `src/PickKit.tsx`.
- Widen the box up to its maximum.
- If it still does not fit, break the text into 2 balanced lines.
- Only then shrink the font, down to its minimum.
- Boxes of one element share one font size and one height.
- Any new element with boxed text must use these helpers.

**Rule 2 — hold after completion.** Same day: elements vanished the instant they completed.
- Every element stays at least 1.5 s after its last part appears.
- For `pick` items, `pickUntil`/`PICK_HOLD` in `src/MontageSpec.tsx` enforce it automatically, whatever `until` the spec gives.
- Apply the same hold by hand when planning other items.

**Why:** the viewer must be able to read before the element leaves, and overflowing text looks broken.

**How to apply:**
- New kit components with labels must use `fitBox`/`fitGroup`.
- Never set `until` to the moment of the last word.
- The rules are in PREFERENCES / MONTAGE_BRIEF.

Related: [[feedback-drawn-metaphors]], [[feedback-hadith-card-stays-after-typing]].
