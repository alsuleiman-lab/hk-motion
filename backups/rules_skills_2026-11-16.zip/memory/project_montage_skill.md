---
name: project_montage_skill
description: The video-montage skill (.claude/skills/video-montage/SKILL.md) is the up-to-date workflow; AGENTS.md/CHECKLIST stay for other agents
metadata:
  node_type: memory
  type: project
  originSessionId: 0497a3b9-f309-451f-91eb-c7f3b5c22a12
  modified: 2026-10-16T18:46:56.140Z
---

Created 2026-10-16 at the user's request ("convert instructions to a skill?" → yes). The skill holds the full ordered workflow (questions by click, cutting 0.10/0.18, fonts, layout rules, mandatory styles, pre-render checks, GPU render, export straight into جاهز, cleanup after approval). AGENTS.md and WORKFLOW_CHECKLIST.md were kept (not slimmed) because Codex/Antigravity read them and cannot use Claude skills; a pointer to the skill was added.

**Why:** the long files were being skipped/forgotten.
**How to apply:** invoke `video-montage` whenever asked to edit a video; when a new rule arrives, update the skill AND PREFERENCES/CHECKLIST. Related: [[feedback_ask_with_clickable_options]], [[reference_preferences_file]].
