---
name: always-fast-render
description: "every final render must use the fast method (pre-extracted JPEG frames + --audio-file), never plain render_chunked"
metadata:
  node_type: memory
  type: feedback
  originSessionId: a6cd9fbe-2d90-48d8-b0c4-30f955c83073
  modified: 2026-10-25T18:35:47.044Z
---

Always use the fast render for every final render: extract frames to `public/<p>/fr` (ffmpeg -hwaccel cuda -frame_pts 1 -q:v 3), build a ready `final_audio.wav` (speech + clips + sfx), then `RENDER_PROPS='{"frames":true}' node tools/render_chunked.mjs ... --chunk 3000 --audio-file <wav>`.

**Why:** On the Siraj video I launched plain render_chunked first (about 50 min estimate); the user asked "did you use the fast render?" and then said "always use it". It is already the default in PREFERENCES.md R-RENDER-SPEED.4.

**How to apply:** Before launching any render, check that frames exist and an audio file is prepared; check the frame count matches the composition (numbering starts at f_000000, clamp to the last file).
