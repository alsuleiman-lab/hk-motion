---
name: edit-is-one-block
description: "after any edit, treat the edited frame span A→B as ONE block — check and re-render only that span, nothing else"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 228a84a9-6709-410e-9b22-3a05db96f613
  modified: 2026-10-26T19:26:08.059Z
---

When I edit a video, the changed span (frame A to B) is one block: face_check, frame_audit and re-render run ONLY on that span; the rest of the video is never re-checked or re-rendered.

**Why:** the user (2026-10-26) hit ~20-minute full re-checks after every small edit on the Siraj video and asked for a smart way to cut it; his answer was "treat the edit location as one block from frame A to B, you have no business with anything else".

**How to apply:** use `node tools/edit_block.mjs <CompId> <A sec> <B sec> --props '{"frames":true}'` (face_check on the span only, frame_audit with the outside skipped, deletes only the overlapping `part_*.mp4` chunks so re-running the same `render_chunked` command re-renders just those). Do not launch the whole-video check after a local edit. A full check stays only for the very first pass before first delivery. See [[feedback_always_fast_render]].

**Repeated 2026-11-11 (the build too):** I kept regenerating the whole spec (build script + finalize + grid --write) for each small correction, so items far from the edit moved. Now: `node tools/spec_block.mjs freeze <p>` when giving the link; every correction → edit the build script, then `spec_block.mjs apply <p> fA fB` (only what intersects [A,B] is taken from the rebuild, everything else stays byte-identical); `stage.mjs check` runs `spec_block diff` and fails on any change outside an applied block. Also: run independent checks in parallel; matte_windows reuses existing window files.
