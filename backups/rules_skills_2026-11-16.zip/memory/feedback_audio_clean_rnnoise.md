---
name: feedback-audio-clean-rnnoise
description: Voice denoise = RNNoise (FFmpeg arnndn) via tools/audio_clean.mjs, chosen by ear 2026-11-13 over DeepFilterNet/Demucs/MossFormer
metadata:
  type: feedback
---
User picked by ear (2026-11-13, sample of «مكافحة المحتوى الهابط») «الشبكة الصغيرة لإزالة الضجيج» = RNNoise: `node tools/audio_clean.mjs <in> [out]`, model data/audio_models/rnnoise_sh.rnnn. Other five tried and deleted (afftdn, DeepFilterNet3, Demucs vocals, MossFormer2 48K, MossFormerGAN).
**Why:** he wants one tool used on every video from now on.
**How to apply:** clean his voice track after the cut, before sfx/bumper mix; never another denoiser unless he orders. Wired into the cut step after the audio gate (cut video built from the cleaned wav); rule in PREFERENCES sec 3 + MONTAGE_BRIEF sec 2.
