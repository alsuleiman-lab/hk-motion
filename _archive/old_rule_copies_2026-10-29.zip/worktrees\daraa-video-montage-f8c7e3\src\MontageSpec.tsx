import React from "react";
import { AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { Gfx, HandheldShake, NeonWord, SourceWalk, BlurRise, RewriteWindow, FlashCut, ScholarPolaroid, useT } from "./MG";
import { KeyChip, VerseWords, ReelVerseFull } from "./MGExtras";
import { TitleBar } from "./TitleBar";
import type { BarTheme } from "./TitleBar";
import { NameTag, Banner, StatRow, Pic, Subscribe } from "./EuKit";
import { FONT_TITLE, FONT_TEXT } from "./localFonts";
import { BAR_WARM, WarmBase, TopicBg, Swap, Only, Word, PersonCard, PhoneWin, SheikhLayers, CollageBg, PaperScene, CropCard, PopCard, FullImage, CreditLine, Marker, RV, LANDSCAPE, clamp } from "./PortraitKit";
import { CoverKit, COVER_PALETTES, PaperCoverKit, PAPER_COVER_END } from "./CoverKit";
import type { CoverProps } from "./CoverKit";

/**
 * MontageSpec — a montage as DATA (idea of the user, 2026-10-26: «write each element once, copy it from a database, change one place and everything follows»).
 * A video is a JSON object (`data/specs/<id>.json`); this file is the ONE renderer: it maps every item type to the shared kit components (MG.tsx / PortraitKit.tsx).
 *   - change a kit component → every video made from specs changes;  change a number in the JSON → only that element moves.
 *   - to add a new element type: add one `case` below + one line in the SpecItem type; nothing else.
 * ONE spec serves BOTH orientations: the composition's size decides (1080×1920 = portrait, 1920×1080 = landscape). Same items, same seconds; the renderer places each item by the
 * orientation's layout (PORTRAIT / LANDSCAPE in PortraitKit). Item numbers (x, y, w, h) are the PORTRAIT ones; `land` overrides them for landscape (or `skip`), `only` pins an item to one orientation.
 * All times are seconds on the CUT timeline. Portrait layer order (fixed): warm base → hook background → hook collage → [shake] his video → full-screen sources → <Gfx> (title bar, items, cover).
 * Landscape: his whole frame (+ push-ins) → full-screen sources → <Gfx>; no hook background/collage/isolation.
 */
type Mark = { x: number; y: number; w: number; h: number; at: number };
/** landscape override of one item (any field of the item that is a position/size, plus skip) */
export type Land = { x?: number; y?: number; w?: number; h?: number; photoH?: number; size?: number; origin?: string; marker?: Mark; skip?: boolean };
type Common = { only?: "port" | "land"; land?: Land };
export type SpecItem = Common & (
  | { t: "word"; text: string; at: number; until: number; x: number; y: number; size?: number; tone?: "gold" | "cream"; flag?: string }
  | { t: "blur"; text: string; at: number; until: number; y: number; size?: number; accentWords?: number[] }
  | { t: "neon"; text: string; at: number; until?: number; y: number; x?: number; w?: number; size?: number; swapTo?: string; swapAt?: number }
  | { t: "nameTag"; at: number; x: number; y: number; dur?: number }
  | { t: "phone"; at: number; to: number; src: string; dur: number; cx?: number; cy?: number; w?: number; h?: number }
  | { t: "person"; src: string; name: string; at: number; until: number; x: number; y: number; w: number; photoH: number; pos?: string }
  | { t: "crop"; src: string; nat: { w: number; h: number }; crop: { x: number; y: number; w: number; h: number }; name: string; at: number; until: number; x: number; y: number; w: number; walk?: boolean }
  | { t: "pic"; src: string; at: number; until: number; x: number; y: number; w: number; h: number; marker?: Mark }
  | { t: "scene"; at: number; until: number; x: number; y: number; w: number; h: number; pieces: { src: string; x: number; y: number; w: number; at: number; rot?: number; from?: "left" | "right" | "top" | "bottom" }[] }
  | { t: "full"; src: string; from: number; to: number; origin?: string; marker?: Mark }
  | { t: "rewrite"; x: number; y: number; w: number; h?: number; oldText: string; newText: string; oldAt: number; strikeAt: number; newAt: number; extra?: string; until?: number }
  | { t: "flash"; src: string; name?: string; at: number; until: number; x: number; y: number; w: number; h: number; crops: { fx: number; fy: number; zoom: number }[]; beats: number[] }
  | { t: "credit"; text: string; from?: number; to?: number }
  /** a verse written word by word at the second he recites it (text copied from data/quran by tools/quran_ayah.mjs, never typed) */
  | { t: "subscribe"; at: number; x: number; y: number; dur?: number }
  | { t: "verse"; words: string[]; times: number[]; title: string; refText: string; x: number; y: number; w: number; size?: number; until?: number }
  /** a column of written cards (EU-Protests style): dark `Banner` title + one `StatRow` card per spoken item; placed by the orientation's layout (no x/y) */
  | { t: "rows"; from: number; to: number; y0?: number; step?: number; rowH?: number; title?: { at: number; text: string }; rows: { at: number; label: string; sub?: string; icon?: string; photo?: string }[] }
  /** a scholar he quotes: polaroid with the name in the white band (empty side of his frame; portrait: below the beard) */
  | { t: "scholar"; src: string; name: string; sub?: string; at: number; until?: number; x?: number; y?: number; w?: number; h?: number; pos?: string }
  /** the cover drawn over everything at the start (skill thumbnail-design). DEFAULT style "paper" (user 2026-10-27) = PaperCoverKit: newsprint sheet, 3 still frames, then the
   *  elements fly out and the sheet tears off in stop-motion until frame 51 (`tearOrder` overrides the face-first strip order). style "kit" = the old CoverKit for `frames` (default 3). `kitLand` overrides `kit` in landscape */
  | { t: "cover"; style?: "paper" | "kit"; tearOrder?: number[]; frames?: number; palette?: keyof typeof COVER_PALETTES; kit: Omit<CoverProps, "format" | "palette">; kitLand?: Partial<Omit<CoverProps, "format" | "palette">> }
);

export type MontageSpec = {
  id: string; title: string; frames: number; fps?: number;
  cut?: string;                       // public/<cut>.mp4 — his video (also the audio)
  iso?: string;                       // alpha webm for the hook (portrait only; needs hookEnd)
  hookEnd?: number;
  bar?: BarTheme;                     // title-bar / key-chip colours (default BAR_WARM)
  cams?: { from: number; to: number; cx: number }[];
  zooms?: { from: number; to: number; amt?: number }[];
  shake?: { from: number; to: number }[];
  hookBg?: { src: string; from: number; to: number; pos?: string; dim?: number }[];
  collage?: { from?: number; until: number; pieces: { src: string; at: number; x: number; y: number; w: number; rot?: number; from?: "left" | "right" | "top" | "bottom" }[] }[];
  items: SpecItem[];
};

type Orient = "port" | "land";
const ROWS = {
  port: { x: 40, w: 1000, bannerY: 1440, rowY: (i: number, t: boolean) => (t ? 1515 : 1445) + i * 122, rowH: 112, bannerSize: 32 },
  land: { x: 40, w: 600, bannerY: 150, rowY: (i: number, t: boolean) => (t ? 285 : 150) + i * 185, rowH: 160, bannerSize: 38 },
};

const renderItem = (it: SpecItem, i: number, o: Orient, bar: BarTheme): React.ReactNode => {
  if (it.only && it.only !== o) return null;
  const L = o === "land", ov: Land = it.land ?? {}, G = LANDSCAPE.left;
  if (L && ov.skip) return null;
  switch (it.t) {
    case "word":
      return L
        ? <KeyChip key={i} phrases={[{ text: it.text, at: it.at }]} until={it.until} x={ov.x} y={ov.y} size={ov.size ?? 54} theme={bar} />
        : <Word key={i} text={it.text} at={it.at} until={it.until} x={it.x} y={it.y} size={it.size} tone={it.tone} flag={it.flag} />;
    case "blur":
      return L
        ? <KeyChip key={i} phrases={[{ text: it.text, at: it.at }]} until={it.until} x={ov.x} y={ov.y} size={ov.size ?? 54} theme={bar} />
        : <Only key={i} from={it.at} to={it.until}><BlurRise at={it.at} times={[it.at, it.at + 0.4]} text={it.text} x={40} w={1000} y={it.y} size={it.size ?? 58} color="#fff" accentColor="#f3c34a" accentWords={it.accentWords ?? []} canvasW={1080} /></Only>;
    case "neon":
      return L
        ? <NeonWord key={i} at={it.at} text={it.text} x={0} y={ov.y ?? LANDSCAPE.keyY} w={LANDSCAPE.W} size={ov.size ?? 130} swapTo={it.swapTo} swapAt={it.swapAt} until={it.until} />
        : <NeonWord key={i} at={it.at} text={it.text} x={it.x} y={it.y} w={it.w} size={it.size} swapTo={it.swapTo} swapAt={it.swapAt} until={it.until} />;
    case "nameTag": return <NameTag key={i} at={it.at} x={L ? ov.x ?? LANDSCAPE.W / 2 : it.x} y={L ? ov.y ?? LANDSCAPE.nameY : it.y} dur={it.dur} />;
    case "phone": return L ? null : <PhoneWin key={i} at={it.at} to={it.to} src={it.src} dur={it.dur} cx={it.cx} cy={it.cy} w={it.w} h={it.h} />;
    case "person": {
      const x = L ? ov.x ?? G.x : it.x, y = L ? ov.y ?? G.y : it.y, w = L ? ov.w ?? 520 : it.w, photoH = L ? ov.photoH ?? 520 : it.photoH;
      return (
        <Only key={i} from={it.at} to={it.until}>
          <SourceWalk at={it.at} w={w} h={photoH + 58} from={{ x: x - w - 40, y }} mid={{ x: x - 30, y: y + 5 }} to={{ x, y }} switchAt={0.2} sprint={0.55} impact={false}>
            <PersonCard src={it.src} name={it.name} w={w} photoH={photoH} pos={it.pos} />
          </SourceWalk>
        </Only>
      );
    }
    case "crop": {
      const x = L ? ov.x ?? G.x : it.x, y = L ? ov.y ?? G.y : it.y, w = L ? ov.w ?? G.w : it.w;
      const card = <CropCard src={it.src} nat={it.nat} crop={it.crop} w={w} name={it.name} />;
      if (!it.walk) return <Only key={i} from={it.at} to={it.until}><PopCard at={it.at} x={x} y={y}>{card}</PopCard></Only>;
      const h = Math.round((it.crop.h * w) / it.crop.w) + 58;   // picture + 5px frame ×2 + the 48px name strip
      return (
        <Only key={i} from={it.at} to={it.until}>
          <SourceWalk at={it.at} w={w} h={h} from={{ x: -w - 40, y }} mid={{ x: x - 30, y: y + 5 }} to={{ x, y }} switchAt={0.2} sprint={0.55} impact={false}>{card}</SourceWalk>
        </Only>
      );
    }
    case "pic": {
      const x = L ? ov.x ?? G.x : it.x, y = L ? ov.y ?? G.y : it.y, w = L ? ov.w ?? G.w : it.w, h = L ? ov.h ?? Math.round((it.h * w) / it.w) : it.h;
      const mk = L ? ov.marker ?? it.marker : it.marker;
      return (
        <Only key={i} from={it.at} to={it.until}>
          <SourceWalk at={it.at} w={w} h={h} from={{ x: -w - 40, y }} mid={{ x: x - 30, y: y + 5 }} to={{ x, y }} switchAt={0.2} sprint={0.55} impact={false}>
            <div style={{ position: "relative", width: w, height: h, borderRadius: 14, overflow: "hidden", border: "5px solid #f6efe0", boxSizing: "border-box" }}>
              <Pic src={it.src} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              {mk ? <Marker at={mk.at - it.at} x={mk.x} y={mk.y} w={mk.w} h={mk.h} /> : null}
            </div>
          </SourceWalk>
        </Only>
      );
    }
    case "scene": {
      const w = L ? ov.w ?? G.w : it.w, k = w / it.w, h = L ? ov.h ?? Math.round(it.h * k) : it.h;
      const pieces = L ? it.pieces.map((p) => ({ ...p, x: p.x * k, y: p.y * k, w: p.w * k })) : it.pieces;
      return <PaperScene key={i} at={it.at} until={it.until} x={L ? ov.x ?? G.x : it.x} y={L ? ov.y ?? G.y : it.y} w={w} h={h} pieces={pieces} />;
    }
    case "rewrite": return <Only key={i} from={it.oldAt - 0.4} to={it.until ?? it.newAt + 8}><RewriteWindow x={L ? ov.x ?? G.x : it.x} y={L ? ov.y ?? G.y : it.y} w={L ? ov.w ?? 640 : it.w} h={L ? ov.h ?? it.h : it.h} oldText={it.oldText} newText={it.newText} oldAt={it.oldAt} strikeAt={it.strikeAt} newAt={it.newAt} extra={it.extra} until={it.until} /></Only>;
    case "flash": {
      const w = L ? ov.w ?? G.w : it.w, h = L ? ov.h ?? Math.round((it.h * w) / it.w) : it.h;
      return (
        <Only key={i} from={it.at} to={it.until}>
          <FlashCut at={it.at} x={L ? ov.x ?? G.x : it.x} y={L ? ov.y ?? G.y : it.y} w={w} h={h} beats={it.beats} crops={it.crops}>
            <Pic src={it.src} style={{ width: w, height: h, objectFit: "cover" }} />
          </FlashCut>
          {it.name ? <div style={{ position: "absolute", left: L ? ov.x ?? G.x : it.x, top: (L ? ov.y ?? G.y : it.y) + h, width: w, height: 48, background: "#0f2a47", color: "#fff", fontFamily: "Noto Kufi Arabic", fontSize: 30, textAlign: "center", direction: "rtl", lineHeight: "48px", whiteSpace: "nowrap", borderRadius: "0 0 10px 10px" }}>{it.name}</div> : null}
        </Only>
      );
    }
    case "subscribe": return <Subscribe key={i} at={it.at} x={L ? ov.x ?? 330 : it.x} y={L ? ov.y ?? 720 : it.y} dur={it.dur} />;
    case "verse":
      // portrait: the verse fills the screen, his picture hidden while he recites (PREFERENCES §6); landscape: a card on the empty side
      return L ? <VerseWords key={i} words={it.words} times={it.times} x={ov.x ?? it.x} y={ov.y ?? it.y} w={ov.w ?? it.w} size={ov.size ?? it.size} title={it.title} refText={it.refText} until={it.until} />
        : <ReelVerseFull key={i} to={it.until ?? it.times[it.times.length - 1] + 1.2} refName={`${it.title} — ${it.refText}`} lines={[{ words: it.words, times: it.times }]} />;
    case "credit": return <CreditLine key={i} text={it.text} from={it.from} to={it.to} />;
    case "rows": {
      const g = ROWS[o], titled = !!it.title && (L || it.rows.length < 3);
      // `y0/step/rowH` (portrait) pack a long list under the beard: first row top, row pitch, row height
      const rowY = (n: number) => (!L && it.y0 !== undefined ? it.y0 + n * (it.step ?? 112) : g.rowY(n, titled)), rowH = !L && it.rowH ? it.rowH : g.rowH;
      return (
        <Only key={i} from={it.from} to={it.to}>
          {titled && it.title ? <Banner at={it.title.at} x={g.x} y={g.bannerY} w={g.w} text={it.title.text} size={g.bannerSize} /> : null}
          {it.rows.map((r, n) => <StatRow key={n} at={r.at} x={g.x} y={rowY(n)} w={g.w} h={rowH} icon={r.icon ?? "Quote"} label={r.label} sub={r.sub} photo={r.photo} rot={n % 2 ? 1 : -1} />)}
        </Only>
      );
    }
    case "scholar": return <ScholarPolaroid key={i} at={it.at} until={it.until} src={it.src} name={it.name} sub={it.sub} x={L ? ov.x ?? LANDSCAPE.right.x : it.x ?? 40} y={L ? ov.y ?? LANDSCAPE.right.y : it.y ?? 1360} w={it.w} h={it.h} pos={it.pos} />;
    default: return null; // "full" is a base-layer item and "cover" a top-layer item (below)
  }
};

/** landscape footage: his whole 1920×1080 frame with the occasional push-in on his face (same easing as SheikhLayers) */
const LandFootage: React.FC<{ cut: string; zooms?: { from: number; to: number; amt?: number }[] }> = ({ cut, zooms = [] }) => {
  const t = useT(0);
  const zz = zooms.find((z) => t >= z.from - 0.01 && t <= z.to + 0.5);
  const z = zz ? 1 + (zz.amt ?? 0.08) * Math.min(clamp((t - zz.from) / 0.35), clamp((zz.to + 0.5 - t) / 0.45)) : 1;
  return (
    <AbsoluteFill style={{ background: "#1b2330", transform: `scale(${z})`, transformOrigin: LANDSCAPE.faceOrigin }}>
      <RV src={staticFile(cut)} style={{ position: "absolute", left: 0, top: 0, width: LANDSCAPE.W, height: LANDSCAPE.H }} />
    </AbsoluteFill>
  );
};

export const MontageFromSpec: React.FC<{ spec: MontageSpec }> = ({ spec }) => {
  const f = useCurrentFrame();
  const { width, height } = useVideoConfig();
  const o: Orient = width > height ? "land" : "port";
  FONT_TITLE(); FONT_TEXT();
  const bar = spec.bar ?? BAR_WARM;
  const fulls = spec.items.filter((i): i is Extract<SpecItem, { t: "full" }> => i.t === "full" && (!i.only || i.only === o));
  const cover = spec.items.find((i): i is Extract<SpecItem, { t: "cover" }> => i.t === "cover" && (!i.only || i.only === o));
  const hookEnd = spec.hookEnd ?? 0;
  const body = o === "land"
    ? (spec.cut ? <LandFootage cut={spec.cut} zooms={spec.zooms} /> : null)
    : (spec.cut ? <SheikhLayers cut={spec.cut} iso={spec.iso} hookEnd={hookEnd} cams={spec.cams ?? [{ from: 0, to: 9999, cx: 990 }]} zooms={spec.zooms} /> : null);
  return (
    <AbsoluteFill style={{ background: "#ad9068" }}>
      {spec.cut ? <Audio src={staticFile(spec.cut)} volume={0.8} /> : null}
      {o === "port" || !spec.cut ? <WarmBase /> : null}
      {o === "port" ? (spec.hookBg ?? []).map((b, i) => <Swap key={i} from={b.from} to={b.to}><TopicBg src={b.src} until={9999} dim={b.dim ?? 0.14} pos={b.pos} /></Swap>) : null}
      {o === "port" ? (spec.collage ?? []).map((c, i) => <CollageBg key={i} from={c.from} until={c.until} pieces={c.pieces} />) : null}
      {spec.shake?.length ? <HandheldShake windows={spec.shake} amp={6} rot={0.4}>{body}</HandheldShake> : body}
      {fulls.map((x, i) => <FullImage key={i} src={x.src} from={x.from} to={x.to} origin={o === "land" ? x.land?.origin ?? x.origin : x.origin} marker={o === "land" ? x.land?.marker : x.marker} />)}
      <Gfx>
        <TitleBar title={spec.title} theme={bar} bottomHalf={o === "port"} />
        {spec.items.map((it, i) => renderItem(it, i, o, bar))}
      </Gfx>
      {cover && (cover.style ?? "paper") === "paper" && f < PAPER_COVER_END ? <PaperCoverKit format={o === "land" ? "landscape" : "portrait"} palette={COVER_PALETTES[cover.palette ?? "steel"]} tearOrder={cover.tearOrder} {...cover.kit} {...(o === "land" ? cover.kitLand : {})} /> : null}
      {cover && cover.style === "kit" && f < (cover.frames ?? 3) ? <CoverKit format={o === "land" ? "landscape" : "portrait"} palette={COVER_PALETTES[cover.palette ?? "steel"]} {...cover.kit} {...(o === "land" ? cover.kitLand : {})} /> : null}
    </AbsoluteFill>
  );
};
