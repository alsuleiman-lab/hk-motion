---
name: reference-external-skill-repos
description: "External GitHub skills the user asked me to learn from (gbro-collage-broll MIT, onetake noncommercial); downloaded to scratch/ext_repos, never executed"
metadata:
  type: reference
---

- `gbro-collage-broll` (MIT, github.com/pyang5166/gbro-collage-broll): paper-collage B-roll workflow with 3 approval gates. **Installed AS IS (user order 2026-10-20, replacing my adaptation `collage-broll`/effect #15)** in `.claude/skills/gbro-collage-broll` + `.agents/skills/gbro-collage-broll`; needs GEMINI_API_KEY (not set here) and an image_gen-capable env; nothing from it executed yet. My old adaptation is backed up in `scratch/backup_my_collage/`; `CollageAssemble` stays in src/MG.tsx unused.
- `scratch/ext_repos/onetake` (PolyForm Noncommercial, github.com/feitangyuan/onetake): ideas only (carry between beats, deconstruct reference by numbers, 3 concepts) → recorded in motion-graphics SKILL §19; do not copy its code.
- Repos were cloned (user's explicit order 2026-10-20) but nothing from them was executed. See [[feedback-reference-links-where-to-use]].

**تحديث 2026-10-20 (الدمج):** قُرئت أيضاً `MegaTroll222/VOX-COLLAGE-BROLL` (تعتمد MaxFusion المدفوع؛ لم تُنزَّل كمهارة، قُرئ نصها في scratchpad) و`YIAN6557/eian-collage-broll` (MIT؛ لا تولّد فيديو، تسلّم إطاراً أول فارغاً وآخر وملف prompt؛ فيها استخراج مقاطع من النص ولوحات ألوان). المفيد منها دُمج في مهارة `collage-broll-local` (مجانية: ComfyUI + CollageAssemble + `tools/comfy_still.mjs` + `tools/collage_qa.mjs`)، وهي المعتمدة؛ `gbro-collage-broll` الأصلية باقية كما نُزّلت. تحذير: رابط تثبيت VOX ينزّل SKILL.md من فرع main بلا إصدار ثابت.
